
// This file exports all image upload functions from profileUtils.js
// Keeping this file for backward compatibility

export {
  isValidImageFile,
  uploadProfileImage,
  uploadToImgBB,
  saveUserProfile,
  getUserProfile,
  getCurrentUserProfileImage,
  getUniversalProfileImage,
  getInitialsFromName,
  isUserOwner,
  getUserDisplayName,
  clearUserProfile,
  getGlobalAdminProfile,
  saveProfileToFirestore,
  getProfileFromFirestore,
  subscribeToProfileUpdates,
  getCommentAuthorProfileImage,
  cleanupProfiles,
  initializeGlobalAdminAccess
} from './profileUtils.js';

// Legacy support for uploadPostImage
export const uploadPostImage = async (file) => {
  const { uploadToImgBB } = await import('./profileUtils.js');
  return await uploadToImgBB(file);
};
