
// IMGBB API key - Get from https://api.imgbb.com/
const IMGBB_API_KEY = 'beee436d41b56268574bab6acdde4aa9'; // Replace with your REAL ImgBB API key

// Global state for real-time admin profile
let globalAdminProfile = null;
let firestoreListeners = new Map();

// CRASH FIX: Centralized event system to prevent flooding
const EventManager = {
  pendingEvents: new Map(),
  activeComponents: new Set(),
  
  // Register component to prevent duplicate listeners
  registerComponent(componentName) {
    this.activeComponents.add(componentName);
  },
  
  // Unregister component
  unregisterComponent(componentName) {
    this.activeComponents.delete(componentName);
    // Clear any pending events for this component
    if (this.pendingEvents.has(componentName)) {
      clearTimeout(this.pendingEvents.get(componentName));
      this.pendingEvents.delete(componentName);
    }
  },
  
  // Safe event dispatch with heavy debouncing
  safeDispatch(eventType, detail, delay = 1500) {
    const eventKey = `${eventType}_global`;
    
    // Clear any existing pending event
    if (this.pendingEvents.has(eventKey)) {
      clearTimeout(this.pendingEvents.get(eventKey));
    }
    
    // Set new debounced event
    this.pendingEvents.set(eventKey, setTimeout(() => {
      try {
        window.dispatchEvent(new CustomEvent(eventType, { detail }));
        console.log(`✅ Safe event dispatched: ${eventType}`);
      } catch (error) {
        console.warn('Event dispatch error (non-critical):', error);
      } finally {
        this.pendingEvents.delete(eventKey);
      }
    }, delay));
  },
  
  // Clear all pending events
  clearAll() {
    this.pendingEvents.forEach((timeoutId) => {
      clearTimeout(timeoutId);
    });
    this.pendingEvents.clear();
    this.activeComponents.clear();
  }
};

// Global cleanup function
const globalCleanup = () => {
  try {
    EventManager.clearAll();
    
    // Clear any window-level pending events
    const windowEventKeys = [
      'pendingProfileEvent',
      'pendingProfileSaveEvent', 
      'pendingFirebaseEvent',
      'pendingRefreshEvent',
      'pendingGlobalSyncEvent'
    ];
    
    windowEventKeys.forEach(key => {
      if (window[key]) {
        clearTimeout(window[key]);
        window[key] = null;
      }
    });
    
    console.log('🧹 Global cleanup completed');
  } catch (error) {
    console.warn('Cleanup error (non-critical):', error);
  }
};

// Validate image file
export const isValidImageFile = (file) => {
  if (!file) return false;
  const validTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'];
  const maxSize = 32 * 1024 * 1024; // 32MB
  return validTypes.includes(file.type) && file.size <= maxSize;
};

// Upload to ImgBB with fallback
export const uploadToImgBB = async (file) => {
  if (!isValidImageFile(file)) {
    throw new Error('Invalid image file');
  }

  // First try ImgBB
  const formData = new FormData();
  formData.append('image', file);

  try {
    const response = await fetch(`https://api.imgbb.com/1/upload?key=${IMGBB_API_KEY}`, {
      method: 'POST',
      body: formData
    });

    const result = await response.json();

    if (result.success) {
      return {
        success: true,
        data: result.data,
        url: result.data.url
      };
    } else {
      throw new Error(result.error?.message || 'ImgBB upload failed');
    }
  } catch (error) {
    console.error('ImgBB upload error:', error);

    // Fallback to Base64 conversion for now
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        // For now, just use the current default image
        // In production, you'd want to upload to a working service
        resolve({
          success: true,
          data: {
            url: 'https://i.ibb.co/zH5KTH4n/IMG-20250811-194616-255.jpg',
            fallback: true
          },
          url: 'https://i.ibb.co/zH5KTH4n/IMG-20250811-194616-255.jpg'
        });
      };
      reader.onerror = () => reject(new Error('File reading failed'));
      reader.readAsDataURL(file);
    });
  }
};

// Upload profile image
export const uploadProfileImage = async (file) => {
  return await uploadToImgBB(file);
};

// Save user profile
export const saveUserProfile = (profile) => {
  try {
    const profileData = {
      ...profile,
      lastUpdated: Date.now()
    };
    localStorage.setItem('lushivie-user-profile', JSON.stringify(profileData));
    return true;
  } catch (error) {
    console.error('Error saving user profile:', error);
    return false;
  }
};

// Get user profile
export const getUserProfile = () => {
  try {
    const profile = localStorage.getItem('lushivie-user-profile');
    return profile ? JSON.parse(profile) : null;
  } catch (error) {
    console.error('Error getting user profile:', error);
    return null;
  }
};

// Get current user profile image
export const getCurrentUserProfileImage = () => {
  const profile = getUserProfile();
  return profile?.profileImage || 'https://i.ibb.co/zH5KTH4n/IMG-20250811-194616-255.jpg';
};

// Initialize Firebase real-time listener for admin profile - CRASH FREE VERSION
export const initializeAdminProfileListener = async () => {
  try {
    const { db } = await import('../firebase');
    const { doc, onSnapshot } = await import('firebase/firestore');

    const adminEmails = ['help@lushivie.com', 'glamour.bymaanya@gmail.com'];

    adminEmails.forEach(email => {
      if (!firestoreListeners.has(email)) {
        const userDocRef = doc(db, 'userProfiles', email);

        const unsubscribe = onSnapshot(userDocRef, (docSnap) => {
          if (docSnap.exists()) {
            const profile = docSnap.data();

            // Update global admin profile immediately
            globalAdminProfile = {
              ...profile,
              lastUpdated: Date.now(),
              source: 'firebase-realtime'
            };

            // Save to ALL possible storage locations for maximum coverage
            const storageKeys = [
              'lushivie-global-admin-profile',
              'lushivie-user-profile',
              `lushivie-user-profile-${email}`,
              `lushivie-admin-profile-${email}`,
              'lushivie-admin-profile-help@lushivie.com',
              'lushivie-admin-profile-glamour.bymaanya@gmail.com'
            ];

            storageKeys.forEach(key => {
              localStorage.setItem(key, JSON.stringify(globalAdminProfile));
            });

            // CRASH FIX: Use centralized event system with heavy debouncing
            EventManager.safeDispatch('adminProfileUpdated', {
              profile: globalAdminProfile,
              profileImage: profile.profileImage,
              timestamp: Date.now(),
              source: 'firebase-realtime-safe',
              forceUpdate: true,
              adminUpdate: true
            }, 2000); // 2 second debounce for Firebase events
          }
        }, (error) => {
          console.error('Firebase listener error for', email, ':', error);
        });

        firestoreListeners.set(email, unsubscribe);
      }
    });

  } catch (error) {
    console.error('Error initializing Firebase admin profile listener:', error);
  }
};

// Get universal profile image with enhanced Firebase real-time support
export const getUniversalProfileImage = (userEmail, authorName, fallbackName) => {
  try {
    // Normalize email
    const email = userEmail ? userEmail.toLowerCase().trim() : null;
    const name = authorName || fallbackName || '';

    // Enhanced admin detection
    const isAdmin = name === 'Maanya Arora' || 
                   email === 'help@lushivie.com' || 
                   email === 'glamour.bymaanya@gmail.com' ||
                   name.toLowerCase().includes('maanya') ||
                   (name && (name.toLowerCase() === 'maanya arora' || name.toLowerCase() === 'admin'));

    if (isAdmin) {
      // PRIORITY 1: Check global admin profile from Firebase listener (highest priority)
      if (globalAdminProfile && globalAdminProfile.profileImage) {
        const firebaseImage = globalAdminProfile.profileImage;
        // Accept ANY valid image URL from Firebase - including the default if it's the only one
        if (firebaseImage && firebaseImage.trim() !== '') {
          return firebaseImage;
        }
      }

      // Enhanced admin profile search with prioritized storage locations including visitor cache
      const adminStorageKeys = [
        // Highest priority keys first
        'lushivie-global-admin-profile',
        'lushivie-visitor-admin-profile',
        'lushivie-public-admin-profile',
        'lushivie-cached-admin-profile',
        'lushivie-user-profile',
        'lushivie-user-profile-help@lushivie.com',
        'lushivie-user-profile-glamour.bymaanya@gmail.com',
        'lushivie-admin-profile-help@lushivie.com',
        'lushivie-admin-profile-glamour.bymaanya@gmail.com'
      ];

      let latestProfile = null;
      let latestTimestamp = 0;
      let bestProfile = null;
      let hasAnyCustomImage = false;

      adminStorageKeys.forEach(key => {
        try {
          const profileStr = localStorage.getItem(key);
          if (profileStr) {
            const profile = JSON.parse(profileStr);
            const timestamp = profile.lastUpdated || profile.timestamp || 0;

            // Check for ANY valid profile image
            if (profile.profileImage && profile.profileImage.trim() !== '') {

              // Mark if we found any custom (non-default) image
              if (profile.profileImage !== 'https://i.ibb.co/zH5KTH4n/IMG-20250811-194616-255.jpg') {
                hasAnyCustomImage = true;
              }

              // Prioritization logic
              const isFirebaseSource = profile.source === 'firebase-realtime' || profile.syncedToFirestore;
              const isImgBBImage = profile.imageSource === 'imgbb' || profile.imgbbData || profile.profileImage.includes('imgbb');
              const isCustomImage = profile.profileImage !== 'https://i.ibb.co/zH5KTH4n/IMG-20250811-194616-255.jpg';
              const isRecentUpdate = timestamp > latestTimestamp;

              // Best profile selection criteria - prioritize custom images, Firebase, and ImgBB
              if (!bestProfile || 
                  (isCustomImage && bestProfile.profileImage === 'https://i.ibb.co/zH5KTH4n/IMG-20250811-194616-255.jpg') ||
                  (isFirebaseSource && !bestProfile.source?.includes('firebase')) ||
                  (isImgBBImage && !bestProfile.imageSource?.includes('imgbb')) ||
                  (isRecentUpdate && (isFirebaseSource || isImgBBImage || isCustomImage))) {
                bestProfile = profile;
                latestProfile = profile;
                latestTimestamp = timestamp;
              }
            }
          }
        } catch (e) {
          console.warn(`Error parsing profile for key ${key}:`, e);
        }
      });

      // Return the best admin profile image if available
      if (bestProfile && bestProfile.profileImage) {
        return bestProfile.profileImage;
      }

      // Check if Firebase has any updated image even if it's the same URL
      if (globalAdminProfile && globalAdminProfile.profileImage) {
        return globalAdminProfile.profileImage;
      }

      // ENHANCED FALLBACK: Try to fetch from Firestore directly for visitors, then API fallback
      if (!hasAnyCustomImage) {
        // Attempt to load from Firestore asynchronously and update cache
        const adminEmails = ['help@lushivie.com', 'glamour.bymaanya@gmail.com'];
        adminEmails.forEach(async (adminEmail) => {
          try {
            const profile = await getProfileFromFirestore(adminEmail);
            if (profile && profile.profileImage && profile.profileImage !== 'https://i.ibb.co/zH5KTH4n/IMG-20250811-194616-255.jpg') {

              // Update local storage for visitors
              const visitorCacheKeys = [
                'lushivie-global-admin-profile',
                'lushivie-visitor-admin-profile',
                'lushivie-public-admin-profile',
                'lushivie-cached-admin-profile'
              ];

              const cachedProfile = {
                ...profile,
                publicAccess: true,
                cachedForVisitors: true,
                lastUpdated: Date.now()
              };

              visitorCacheKeys.forEach(key => {
                localStorage.setItem(key, JSON.stringify(cachedProfile));
              });

              // CRASH FIX: Use centralized event system
              EventManager.safeDispatch('visitorProfileRefresh', {
                profileImage: profile.profileImage,
                source: 'firestore-visitor-fetch'
              }, 1000);
            }
          } catch (error) {
            // API fallback for visitors when Firebase is not accessible
            try {
              const response = await fetch(`/api/admin-profile/${adminEmail}`);
              if (response.ok) {
                const data = await response.json();
                if (data.success && data.profile && data.profile.profileImage) {

                  const visitorCacheKeys = [
                    'lushivie-global-admin-profile',
                    'lushivie-visitor-admin-profile',
                    'lushivie-public-admin-profile',
                    'lushivie-cached-admin-profile'
                  ];

                  const cachedProfile = {
                    ...data.profile,
                    publicAccess: true,
                    apiSource: true,
                    lastUpdated: Date.now()
                  };

                  visitorCacheKeys.forEach(key => {
                    localStorage.setItem(key, JSON.stringify(cachedProfile));
                  });

                  // CRASH FIX: Use centralized event system
                  EventManager.safeDispatch('visitorProfileRefresh', {
                    profileImage: data.profile.profileImage,
                    source: 'api-fallback'
                  }, 1200);
                }
              }
            } catch (apiError) {
              // Silently handle API fallback failure
            }
          }
        });
      }

      // For admin, always return the default admin image as last resort
      return 'https://i.ibb.co/zH5KTH4n/IMG-20250811-194616-255.jpg';
    } else {
      // For regular users, check their specific profile
      if (email) {
        const userProfile = localStorage.getItem(`lushivie-user-profile-${email}`);
        if (userProfile) {
          try {
            const profile = JSON.parse(userProfile);
            if (profile.profileImage) {
              return profile.profileImage;
            }
          } catch (e) {
            // Silently handle parsing error
          }
        }
      }

      // No profile image found for regular users
      return null;
    }
  } catch (error) {
    console.error('Error in getUniversalProfileImage:', error);

    // Enhanced error fallback - still check if admin
    const isAdminFallback = (authorName && authorName === 'Maanya Arora') || 
                           (userEmail && ['help@lushivie.com', 'glamour.bymaanya@gmail.com'].includes(userEmail.toLowerCase()));

    return isAdminFallback ? 'https://i.ibb.co/zH5KTH4n/IMG-20250811-194616-255.jpg' : null;
  }
};

// Get comment author profile image
export const getCommentAuthorProfileImage = (authorEmail, authorName) => {
  return getUniversalProfileImage(authorEmail, authorName, null);
};

// Get initials from name
export const getInitialsFromName = (name) => {
  if (!name) return 'A';
  return name.split(' ').map(word => word.charAt(0)).join('').toUpperCase().slice(0, 2);
};

// Check if user is owner
export const isUserOwner = (userEmail) => {
  const ownerEmails = ['help@lushivie.com', 'glamour.bymaanya@gmail.com'];
  return ownerEmails.includes(userEmail);
};

// Get user display name
export const getUserDisplayName = (userEmail, defaultName) => {
  try {
    // Check global admin profile first
    if (globalAdminProfile && (userEmail === 'help@lushivie.com' || userEmail === 'glamour.bymaanya@gmail.com' || defaultName === 'Maanya Arora')) {
      return globalAdminProfile.displayName || defaultName;
    }

    const userProfile = localStorage.getItem(`lushivie-user-profile-${userEmail}`);
    if (userProfile) {
      const profile = JSON.parse(userProfile);
      return profile.displayName || defaultName;
    }

    // Fallback for Maanya Arora
    const adminEmails = ['help@lushivie.com', 'glamour.bymaanya@gmail.com'];
    for (const email of adminEmails) {
      const adminProfile = localStorage.getItem(`lushivie-user-profile-${email}`);
      if (adminProfile) {
        const profile = JSON.parse(adminProfile);
        if (profile.displayName) return profile.displayName;
      }
    }
  } catch (error) {
    console.error('Error getting user display name:', error);
  }
  return defaultName;
};

// Clear user profile
export const clearUserProfile = () => {
  try {
    localStorage.removeItem('lushivie-user-profile');
    return true;
  } catch (error) {
    console.error('Error clearing user profile:', error);
    return false;
  }
};

// Get global admin profile
export const getGlobalAdminProfile = () => {
  return globalAdminProfile || getUserProfile();
};

// Save profile to Firestore with ImgBB integration and real-time sync - CRASH FREE VERSION
export const saveProfileToFirestore = async (userEmail, profile) => {
  try {
    // Import Firebase dynamically to avoid circular imports
    const { db } = await import('../firebase');
    const { doc, setDoc, serverTimestamp } = await import('firebase/firestore');

    const userDocRef = doc(db, 'userProfiles', userEmail);
    const profileData = {
      ...profile,
      lastUpdated: serverTimestamp(),
      syncedAt: new Date(),
      imageSource: profile.imageSource || 'imgbb',
      imgbbData: profile.imgbbData || null,
      syncedToFirestore: true,
      source: 'manual-save'
    };

    await setDoc(userDocRef, profileData, { merge: true });
    console.log('✅ Profile saved to Firestore with real-time sync enabled');

    // Update global admin profile immediately if this is an admin
    const adminEmails = ['help@lushivie.com', 'glamour.bymaanya@gmail.com'];
    if (adminEmails.includes(userEmail)) {
      globalAdminProfile = {
        ...profileData,
        lastUpdated: Date.now(),
        source: 'firebase-immediate'
      };

      // Also update server cache for visitors
      try {
        const response = await fetch(`/api/admin-profile/${userEmail}`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(profileData)
        });

        if (response.ok) {
          console.log('✅ Server cache updated for visitors');
        }
      } catch (error) {
        console.warn('Failed to update server cache:', error);
      }

      // CRASH FIX: Use centralized event system for immediate update
      setTimeout(() => {
        EventManager.safeDispatch('adminProfileSaved', {
          profile: globalAdminProfile,
          timestamp: Date.now(),
          source: 'firestore-save'
        }, 500);
      }, 100);
    }

    return true;
  } catch (error) {
    console.error('❌ Error saving to Firestore:', error);
    return false;
  }
};

// Get profile from Firestore with ImgBB support
export const getProfileFromFirestore = async (userEmail) => {
  try {
    const { db } = await import('../firebase');
    const { doc, getDoc } = await import('firebase/firestore');

    const userDocRef = doc(db, 'userProfiles', userEmail);
    const docSnap = await getDoc(userDocRef);

    if (docSnap.exists()) {
      const profile = docSnap.data();
      console.log('✅ Profile loaded from Firestore with real-time sync');

      // Update global admin profile if this is an admin
      const adminEmails = ['help@lushivie.com', 'glamour.bymaanya@gmail.com'];
      if (adminEmails.includes(userEmail)) {
        globalAdminProfile = profile;

        // Cache for visitors with enhanced keys
        const visitorProfile = {
          ...profile,
          publicAccess: true,
          fromFirestore: true,
          lastUpdated: Date.now()
        };

        const visitorKeys = [
          'lushivie-global-admin-profile',
          'lushivie-visitor-admin-profile',
          'lushivie-public-admin-profile',
          'lushivie-cached-admin-profile',
          'lushivie-user-profile' // Also update main profile key
        ];

        visitorKeys.forEach(key => {
          localStorage.setItem(key, JSON.stringify(visitorProfile));
        });

        console.log('🌐 Admin profile cached for visitors:', profile.profileImage);
      }

      return profile;
    }

    return null;
  } catch (error) {
    console.error('❌ Error loading from Firestore:', error);

    // Enhanced fallback for visitors when Firebase access is denied
    if (error.code === 'permission-denied') {
      console.log('🔄 Firebase permission denied - using cached profile for visitors');

      // Try to get cached admin profile from visitor cache
      const adminEmails = ['help@lushivie.com', 'glamour.bymaanya@gmail.com'];
      if (adminEmails.includes(userEmail)) {
        const visitorKeys = [
          'lushivie-global-admin-profile',
          'lushivie-visitor-admin-profile',
          'lushivie-public-admin-profile',
          'lushivie-cached-admin-profile'
        ];

        for (const key of visitorKeys) {
          try {
            const cachedProfile = localStorage.getItem(key);
            if (cachedProfile) {
              const profile = JSON.parse(cachedProfile);
              if (profile.profileImage && profile.profileImage !== 'https://i.ibb.co/zH5KTH4n/IMG-20250811-194616-255.jpg') {
                console.log('✅ Using cached admin profile for visitors:', profile.profileImage);
                return profile;
              }
            }
          } catch (e) {
            console.warn('Error reading cached profile:', e);
          }
        }
      }
    }

    return null;
  }
};

// Subscribe to profile updates with real-time Firebase integration - CRASH FREE VERSION
export const subscribeToProfileUpdates = (userEmail, callback) => {
  try {
    // Import Firebase dynamically
    import('../firebase').then(({ db }) => {
      import('firebase/firestore').then(({ doc, onSnapshot }) => {
        const userDocRef = doc(db, 'userProfiles', userEmail);

        const unsubscribe = onSnapshot(userDocRef, (docSnap) => {
          if (docSnap.exists()) {
            const profile = docSnap.data();
            console.log('🔄 Real-time profile update from Firestore for', userEmail);

            // Update global admin profile if this is an admin
            const adminEmails = ['help@lushivie.com', 'glamour.bymaanya@gmail.com'];
            if (adminEmails.includes(userEmail)) {
              globalAdminProfile = profile;
            }

            callback(profile);

            // CRASH FIX: Use centralized event system
            EventManager.safeDispatch('firestoreProfileUpdated', profile, 800);
            
            if (adminEmails.includes(userEmail)) {
              EventManager.safeDispatch('firebaseAdminProfileUpdated', profile, 1000);
            }
          }
        });

        return unsubscribe;
      });
    });
  } catch (error) {
    console.error('Error setting up Firestore subscription:', error);
    return () => console.log('Unsubscribed from profile updates');
  }

  return () => console.log('Unsubscribed from profile updates');
};

// Force refresh admin profile across all components - SUPER CRASH FREE VERSION
export const forceRefreshAdminProfile = () => {
  try {
    const latestProfileImage = getLatestAdminProfileImage();

    // CRASH FIX: Use centralized event system with heavy debouncing
    EventManager.safeDispatch('adminProfileRefresh', {
      forceRefresh: true, 
      timestamp: Date.now(),
      profileImage: latestProfileImage,
      source: 'centralized-safe-refresh'
    }, 2000); // 2 second debounce for stability

    console.log('✅ Admin profile refresh queued safely (centralized)');
  } catch (error) {
    console.warn('Profile refresh error (non-critical):', error);
  }
};

// Get the latest admin profile image from all storage sources
const getLatestAdminProfileImage = () => {
  try {
    // First check global admin profile from Firebase
    if (globalAdminProfile && globalAdminProfile.profileImage && 
        globalAdminProfile.profileImage !== 'https://i.ibb.co/zH5KTH4n/IMG-20250811-194616-255.jpg') {
      return globalAdminProfile.profileImage;
    }

    const adminStorageKeys = [
      'lushivie-global-admin-profile',
      'lushivie-user-profile',
      'lushivie-admin-profile-help@lushivie.com',
      'lushivie-admin-profile-glamour.bymaanya@gmail.com',
      'lushivie-user-profile-help@lushivie.com',
      'lushivie-user-profile-glamour.bymaanya@gmail.com'
    ];

    let latestProfile = null;
    let latestTimestamp = 0;

    adminStorageKeys.forEach(key => {
      try {
        const profileStr = localStorage.getItem(key);
        if (profileStr) {
          const profile = JSON.parse(profileStr);
          const timestamp = profile.lastUpdated || profile.timestamp || 0;

          if (profile.profileImage && 
              profile.profileImage !== 'https://i.ibb.co/zH5KTH4n/IMG-20250811-194616-255.jpg' &&
              timestamp > latestTimestamp) {
            latestProfile = profile;
            latestTimestamp = timestamp;
          }
        }
      } catch (e) {
        console.warn(`Error parsing profile for key ${key}:`, e);
      }
    });

    return latestProfile ? latestProfile.profileImage : 'https://i.ibb.co/zH5KTH4n/IMG-20250811-194616-255.jpg';
  } catch (error) {
    console.error('Error getting latest admin profile image:', error);
    return 'https://i.ibb.co/zH5KTH4n/IMG-20250811-194616-255.jpg';
  }
};

// Clean up profiles - ENHANCED VERSION
export const cleanupProfiles = () => {
  // Clean up Firebase listeners
  firestoreListeners.forEach((unsubscribe, email) => {
    unsubscribe();
    console.log('🧹 Cleaned up Firebase listener for', email);
  });
  firestoreListeners.clear();
  
  // Clean up centralized event system
  globalCleanup();
  
  console.log('Profile cleanup completed');
};

// Initialize global admin access with Firebase real-time listeners - CRASH FREE VERSION
export const initializeGlobalAdminAccess = () => {
  // Check if already initialized to prevent multiple initializations
  if (window.lushivieAdminInitialized) {
    return;
  }
  window.lushivieAdminInitialized = true;

  // Initialize Firebase listeners with delay
  setTimeout(() => {
    initializeAdminProfileListener();
  }, 2000); // Increased delay

  // Single profile check with longer delay
  setTimeout(() => {
    forceRefreshAdminProfile();
  }, 4000); // Increased delay
};

// Sync admin profile globally for all visitors and users - CRASH FREE VERSION
export const syncAdminProfileGlobally = () => {
  try {
    const latestAdminImage = getLatestAdminProfileImage();

    if (latestAdminImage && latestAdminImage !== 'https://i.ibb.co/zH5KTH4n/IMG-20250811-194616-255.jpg') {
      // Update all possible storage locations to ensure visitors see the latest image
      const globalKeys = [
        'lushivie-global-admin-profile',
        'lushivie-visitor-admin-profile',
        'lushivie-public-admin-profile',
        'lushivie-cached-admin-profile'
      ];

      const adminProfile = {
        displayName: 'Maanya Arora',
        profileImage: latestAdminImage,
        email: 'help@lushivie.com',
        lastUpdated: Date.now(),
        source: 'global-sync',
        publicAccess: true
      };

      globalKeys.forEach(key => {
        localStorage.setItem(key, JSON.stringify(adminProfile));
      });

      // CRASH FIX: Use centralized event system for global sync
      EventManager.safeDispatch('globalAdminProfileSync', {
        profileImage: latestAdminImage,
        adminProfile: adminProfile,
        timestamp: Date.now(),
        source: 'centralized-sync'
      }, 1500);

      console.log('🌐 Admin profile synced globally (centralized)');
    }
  } catch (error) {
    console.error('Error syncing admin profile globally:', error);
  }
};

// Export event manager for components to use
export const ProfileEventManager = EventManager;

// Initialize on module load with crash protection
if (typeof window !== 'undefined') {
  // Cleanup any existing state first
  globalCleanup();
  
  // Initialize Firebase listeners immediately when the module loads
  initializeGlobalAdminAccess();

  // Also initialize when DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initializeGlobalAdminAccess);
  }
  
  // Global cleanup on page unload
  window.addEventListener('beforeunload', globalCleanup);
}
