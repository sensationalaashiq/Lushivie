
// Personalization Manager for Lushivie
class PersonalizationManager {
  constructor() {
    this.preferences = this.loadPreferences();
    this.analytics = this.loadAnalytics();
    this.startTime = null;
  }

  // Load user preferences from localStorage
  loadPreferences() {
    try {
      const saved = localStorage.getItem('lushivie-preferences');
      return saved ? JSON.parse(saved) : {
        contentType: 'all', // all, skincare, makeup, luxury
        difficulty: 'all', // beginner, intermediate, advanced, all
        theme: 'light', // light, dark, rose-gold
        notifications: true,
        autoplay: false,
        language: 'en',
        region: 'IN'
      };
    } catch (error) {
      console.error('Error loading preferences:', error);
      return {
        contentType: 'all',
        difficulty: 'all',
        theme: 'light',
        notifications: true,
        autoplay: false,
        language: 'en',
        region: 'IN'
      };
    }
  }

  // Load analytics data from localStorage
  loadAnalytics() {
    try {
      const saved = localStorage.getItem('lushivie-analytics');
      return saved ? JSON.parse(saved) : {
        pageViews: [],
        timeSpent: {},
        interactions: [],
        preferences: [],
        lastVisit: Date.now()
      };
    } catch (error) {
      console.error('Error loading analytics:', error);
      return {
        pageViews: [],
        timeSpent: {},
        interactions: [],
        preferences: [],
        lastVisit: Date.now()
      };
    }
  }

  // Save preferences to localStorage
  savePreferences(preferences) {
    try {
      this.preferences = { ...this.preferences, ...preferences };
      localStorage.setItem('lushivie-preferences', JSON.stringify(this.preferences));
      this.trackInteraction('preference_change', preferences);
    } catch (error) {
      console.error('Error saving preferences:', error);
    }
  }

  // Update preferences (alias for savePreferences)
  updatePreferences(preferences) {
    this.savePreferences(preferences);
  }

  // Time tracking methods
  startTimeTracking() {
    this.sessionStartTime = Date.now();
  }

  endTimeTracking() {
    if (this.sessionStartTime) {
      const sessionDuration = Date.now() - this.sessionStartTime;
      this.saveAnalytics('session_duration', sessionDuration);
      this.sessionStartTime = null;
    }
  }

  // Save analytics data to localStorage
  saveAnalytics() {
    try {
      localStorage.setItem('lushivie-analytics', JSON.stringify(this.analytics));
    } catch (error) {
      console.error('Error saving analytics:', error);
    }
  }

  // Track page view
  trackPageView(path, title) {
    try {
      const pageView = {
        path,
        title,
        timestamp: Date.now(),
        referrer: document.referrer,
        userAgent: navigator.userAgent
      };

      this.analytics.pageViews.push(pageView);
      
      // Keep only last 100 page views
      if (this.analytics.pageViews.length > 100) {
        this.analytics.pageViews = this.analytics.pageViews.slice(-100);
      }

      this.saveAnalytics();
    } catch (error) {
      console.error('Error tracking page view:', error);
    }
  }

  // Start time tracking for a page
  startTimeTracking(path) {
    try {
      this.startTime = Date.now();
      this.currentPath = path;
    } catch (error) {
      console.error('Error starting time tracking:', error);
    }
  }

  // End time tracking and save duration
  endTimeTracking() {
    try {
      if (this.startTime && this.currentPath) {
        const duration = Date.now() - this.startTime;
        
        if (!this.analytics.timeSpent[this.currentPath]) {
          this.analytics.timeSpent[this.currentPath] = [];
        }
        
        this.analytics.timeSpent[this.currentPath].push({
          duration,
          timestamp: Date.now()
        });

        // Keep only last 50 time records per path
        if (this.analytics.timeSpent[this.currentPath].length > 50) {
          this.analytics.timeSpent[this.currentPath] = this.analytics.timeSpent[this.currentPath].slice(-50);
        }

        this.saveAnalytics();
        this.startTime = null;
        this.currentPath = null;
      }
    } catch (error) {
      console.error('Error ending time tracking:', error);
    }
  }

  // Track user interactions
  trackInteraction(type, data) {
    try {
      const interaction = {
        type,
        data,
        timestamp: Date.now(),
        path: window.location.pathname
      };

      this.analytics.interactions.push(interaction);
      
      // Keep only last 200 interactions
      if (this.analytics.interactions.length > 200) {
        this.analytics.interactions = this.analytics.interactions.slice(-200);
      }

      this.saveAnalytics();
    } catch (error) {
      console.error('Error tracking interaction:', error);
    }
  }

  // Get personalized content based on user preferences and behavior
  getPersonalizedContent(posts, limit = 10) {
    try {
      if (!posts || posts.length === 0) return [];

      let filteredPosts = [...posts];

      // Filter by content type preference
      if (this.preferences.contentType && this.preferences.contentType !== 'all') {
        filteredPosts = filteredPosts.filter(post => {
          const content = (post.title + ' ' + post.description + ' ' + post.content).toLowerCase();
          return content.includes(this.preferences.contentType);
        });
      }

      // Sort by engagement and recency
      filteredPosts.sort((a, b) => {
        const aScore = this.calculateEngagementScore(a);
        const bScore = this.calculateEngagementScore(b);
        return bScore - aScore;
      });

      return filteredPosts.slice(0, limit);
    } catch (error) {
      console.error('Error getting personalized content:', error);
      return posts ? posts.slice(0, limit) : [];
    }
  }

  // Calculate engagement score for a post
  calculateEngagementScore(post) {
    try {
      let score = 0;

      // Recency score (newer posts get higher scores)
      const daysSincePublished = (Date.now() - new Date(post.publishedAt).getTime()) / (1000 * 60 * 60 * 24);
      score += Math.max(0, 30 - daysSincePublished) * 2;

      // View count score
      score += (post.views || 0) * 0.1;

      // User interaction history
      const interactions = this.analytics.interactions.filter(i => 
        i.data && (i.data.id === post.id || i.data.title === post.title)
      );
      score += interactions.length * 5;

      // Content type preference match
      if (this.preferences.contentType && this.preferences.contentType !== 'all') {
        const content = (post.title + ' ' + post.description).toLowerCase();
        if (content.includes(this.preferences.contentType)) {
          score += 10;
        }
      }

      return score;
    } catch (error) {
      console.error('Error calculating engagement score:', error);
      return 0;
    }
  }

  // Get user preferences
  getPreferences() {
    try {
      return this.preferences || {};
    } catch (error) {
      console.error('Error getting preferences:', error);
      return {};
    }
  }

  // Get analytics summary
  getAnalyticsSummary() {
    try {
      const totalPageViews = this.analytics.pageViews.length;
      const totalTimeSpent = Object.values(this.analytics.timeSpent)
        .flat()
        .reduce((total, session) => total + session.duration, 0);
      
      const avgTimePerSession = totalPageViews > 0 ? totalTimeSpent / totalPageViews : 0;
      
      const topPages = Object.entries(this.analytics.timeSpent)
        .map(([path, sessions]) => ({
          path,
          visits: sessions.length,
          totalTime: sessions.reduce((total, session) => total + session.duration, 0)
        }))
        .sort((a, b) => b.visits - a.visits)
        .slice(0, 5);

      return {
        totalPageViews,
        totalTimeSpent,
        avgTimePerSession,
        topPages,
        lastVisit: this.analytics.lastVisit
      };
    } catch (error) {
      console.error('Error getting analytics summary:', error);
      return {
        totalPageViews: 0,
        totalTimeSpent: 0,
        avgTimePerSession: 0,
        topPages: [],
        lastVisit: Date.now()
      };
    }
  }

  // Clear all data
  clearData() {
    try {
      localStorage.removeItem('lushivie-preferences');
      localStorage.removeItem('lushivie-analytics');
      this.preferences = this.loadPreferences();
      this.analytics = this.loadAnalytics();
    } catch (error) {
      console.error('Error clearing data:', error);
    }
  }
}

// Create singleton instance
const personalizationManager = new PersonalizationManager();

// Export functions for use in components
export { personalizationManager };

export const trackPageView = (path, title) => {
  personalizationManager.trackPageView(path, title);
};

export const trackInteraction = (type, data) => {
  personalizationManager.trackInteraction(type, data);
};

export const getPersonalizedContent = (posts, limit) => {
  return personalizationManager.getPersonalizedContent(posts, limit);
};

export const getPreferences = () => {
  try {
    return personalizationManager.getPreferences() || {};
  } catch (error) {
    console.error('Error getting preferences:', error);
    return {};
  }
};

export const savePreferences = (preferences) => {
  personalizationManager.savePreferences(preferences);
};

export const updatePreferences = (preferences) => {
  personalizationManager.updatePreferences(preferences);
};

export const startTimeTracking = () => {
  personalizationManager.startTimeTracking();
};

export const endTimeTracking = () => {
  personalizationManager.endTimeTracking();
};

export const getAnalyticsSummary = () => {
  return personalizationManager.getAnalyticsSummary();
};

export const clearData = () => {
  personalizationManager.clearData();
};

export default personalizationManager;
