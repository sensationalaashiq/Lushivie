import React from "react";
import { Switch, Route } from "wouter";
import { QueryClient, QueryClientProvider, useQuery } from "@tanstack/react-query";
import { useState, useEffect, createContext, useContext } from "react";
import { 
  Moon, Sun, Menu, X, Mail, MapPin, Phone, Heart, Star, Calendar, User, 
  Edit, Save, Trash2, ArrowRight, Search, TrendingUp, Clock, Tag,
  ChevronDown, ChevronRight, Eye, MessageCircle, Share2, Bookmark, LogOut, LogIn,
  Instagram, Twitter, Facebook, Youtube, Award, Sparkles, Zap, Shield, Upload, Settings, MessageSquare, Gift, AlertTriangle
} from "lucide-react";

// ErrorBoundary component
class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true };
  }

  componentDidCatch(error, errorInfo) {
    console.error('ErrorBoundary caught an error:', error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-gray-900">
          <div className="text-center p-8">
            <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-4">Something went wrong</h2>
            <button 
              className="px-4 py-2 bg-rose-500 text-white rounded-lg hover:bg-rose-600 transition-colors"
              onClick={() => window.location.reload()}
            >
              Reload Page
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
import { AuthProvider, useAuth } from "./contexts/AuthContext";
import AuthModal from "./components/AuthModal";
import { collection, addDoc, getDocs, updateDoc, deleteDoc, doc, query, orderBy, serverTimestamp } from 'firebase/firestore';
import { db } from "./firebase";
import AdminProfileModal from './components/AdminProfileModal';
import UserProfileModal from './components/UserProfileModal';
import AuthorProfileModal from './components/AuthorProfileModal';
// Removed AdminProfileSyncManager and ProfilePersistenceCheck
import ShareModal from './components/ShareModal';
import SavedPostsModal from './components/SavedPostsModal';
import RichTextEditor from "./components/RichTextEditor";
import CommentsSection from "./components/CommentsSection";
import ReviewSystem from "./components/ReviewSystem";
import AdminReviewManager from "./components/AdminReviewManager";
import CodeEditor from "./components/CodeEditor";
import CustomCodeInjector from './components/CustomCodeInjector';
import PersonalizationSettings from './components/PersonalizationSettings';
import QuoteThis from './components/QuoteThis';
import { ToastProvider, useToast } from "./components/Toast";
import { auth } from "./firebase"; // Assuming auth is imported from firebase
import { useQueryClient } from "@tanstack/react-query";
import { personalizationManager, trackPageView, getPersonalizedContent } from './utils/personalization.js';
import PollQuizSection from './components/PollQuizSection';
import SearchPosts from './components/SearchPosts';
import { cleanupProfiles, initializeGlobalAdminAccess, getUserDisplayName, getUniversalProfileImage } from './utils/imageUpload';
// Removed SwipeNavigation import
import LanguageTranslator from './components/LanguageTranslator';
import BeautyHoroscope from './components/BeautyHoroscope';
import TipAuthor from './components/TipAuthor';
import PremiumSection from './components/PremiumSection';
import StoryMode from './components/StoryMode';
import PremiumContentRenderer from './components/PremiumContentRenderer';

// Persistent Saved Posts Utility Functions
function getPersistentSavedPosts() {
  try {
    // Try localStorage first
    const localSaved = localStorage.getItem('lushivie-saved-posts');

    // Try sessionStorage as backup
    const sessionSaved = sessionStorage.getItem('lushivie-saved-posts-backup');

    // Try IndexedDB key as final backup
    const indexedSaved = localStorage.getItem('lushivie-saved-posts-indexed');

    let parsedData = null;

    // Parse from any available source
    if (localSaved && localSaved !== 'undefined' && localSaved !== 'null') {
      parsedData = JSON.parse(localSaved);
    } else if (sessionSaved && sessionSaved !== 'undefined' && sessionSaved !== 'null') {
      parsedData = JSON.parse(sessionSaved);
      // Restore to localStorage
      localStorage.setItem('lushivie-saved-posts', sessionSaved);
    } else if (indexedSaved && indexedSaved !== 'undefined' && indexedSaved !== 'null') {
      parsedData = JSON.parse(indexedSaved);
      // Restore to localStorage
      localStorage.setItem('lushivie-saved-posts', indexedSaved);
    }

    if (!parsedData) {
      const defaultData = { 
        postIds: [], 
        userProfile: null, 
        lastUpdated: Date.now(),
        version: '3.0',
        persistent: true 
      };
      savePersistentSavedPosts(defaultData);
      return [];
    }

    // Handle format migration and ensure persistence
    if (Array.isArray(parsedData)) {
      // Old format - migrate to new persistent format
      const newFormat = {
        postIds: parsedData,
        userProfile: null,
        lastUpdated: Date.now(),
        version: '3.0',
        persistent: true
      };
      savePersistentSavedPosts(newFormat);
      return parsedData;
    } else if (parsedData && parsedData.postIds && Array.isArray(parsedData.postIds)) {
      // New format - ensure it has persistent flags
      const updatedFormat = {
        ...parsedData,
        lastUpdated: Date.now(),
        version: '3.0',
        persistent: true
      };
      savePersistentSavedPosts(updatedFormat);
      return parsedData.postIds;
    } else {
      // Corrupted data - reset with persistent format
      const defaultData = { 
        postIds: [], 
        userProfile: null, 
        lastUpdated: Date.now(),
        version: '3.0',
        persistent: true 
      };
      savePersistentSavedPosts(defaultData);
      return [];
    }
  } catch (error) {
    console.warn('Error loading persistent saved posts:', error);
    const defaultData = { 
      postIds: [], 
      userProfile: null, 
      lastUpdated: Date.now(),
      version: '3.0',
      persistent: true 
    };
    savePersistentSavedPosts(defaultData);
    return [];
  }
}

function savePersistentSavedPosts(data) {
  try {
    const dataWithTimestamp = {
      ...data,
      lastUpdated: Date.now(),
      version: '3.0',
      persistent: true
    };

    const serializedData = JSON.stringify(dataWithTimestamp);

    // Save to multiple storage locations for maximum persistence
    localStorage.setItem('lushivie-saved-posts', serializedData);
    sessionStorage.setItem('lushivie-saved-posts-backup', serializedData);
    localStorage.setItem('lushivie-saved-posts-indexed', serializedData);

    // Also save with user-specific key if user is logged in
    const currentUser = auth.currentUser;
    if (currentUser && currentUser.email) {
      const userKey = `lushivie-saved-posts-user-${currentUser.email}`;
      localStorage.setItem(userKey, serializedData);
    }

    console.log('Saved posts persisted successfully across multiple storage locations');
  } catch (error) {
    console.error('Error saving persistent saved posts:', error);
  }
}




// Initialize profile system on app start
const initializeProfileSystem = () => {
  try {
    // Clean up any corrupted profiles on app start
    cleanupProfiles();

    // Import and initialize global admin access for all visitors
    initializeGlobalAdminAccess();

    // Reduce console logs in production
    if (process.env.NODE_ENV === 'production') {
      console.log = () => {};
      console.warn = () => {};
    }
  } catch (error) {
    console.error('Error initializing profile system:', error);
  }
};



// SEO Head Component for dynamic meta tags
function SEOHead({ title, description, keywords, image, type = "website", publishedTime, author }) {
  const siteUrl = "https://lushivie.com";
  const siteName = "Lushivie - Luxury Beauty Blog";
  const defaultDescription = "Your premier destination for luxury beauty insights, expert reviews, and exclusive content from Delhi's finest beauty connoisseur.";
  const defaultImage = "https://images.unsplash.com/photo-1596462502278-27bfdc403348?w=1200&h=630&fit=crop&crop=face";

  useEffect(() => {
    // Update document title
    document.title = title ? `${title} | ${siteName}` : siteName;

    // Update meta description
    const metaDescription = document.querySelector('meta[name="description"]');
    if (metaDescription) {
      metaDescription.setAttribute('content', description || defaultDescription);
    } else {
      const meta = document.createElement('meta');
      meta.name = 'description';
      meta.content = description || defaultDescription;
      document.head.appendChild(meta);
    }

    // Update meta keywords
    const metaKeywords = document.querySelector('meta[name="keywords"]');
    if (metaKeywords) {
      metaKeywords.setAttribute('content', keywords || 'beauty, makeup, skincare, luxury beauty, beauty tips, Delhi beauty blogger, Maanya Arora');
    } else {
      const meta = document.createElement('meta');
      meta.name = 'keywords';
      meta.content = keywords || 'beauty, makeup, skincare, luxury beauty, beauty tips, Delhi beauty blogger, Maanya Arora';
      document.head.appendChild(meta);
    }

    // Open Graph tags
    const ogTags = [
      { property: 'og:title', content: title || siteName },
      { property: 'og:description', content: description || defaultDescription },
      { property: 'og:image', content: image || defaultImage },
      { property: 'og:url', content: window.location.href },
      { property: 'og:type', content: type },
      { property: 'og:site_name', content: siteName },
      { property: 'og:locale', content: 'en_IN' }
    ];

    ogTags.forEach(tag => {
      let ogTag = document.querySelector(`meta[property="${tag.property}"]`);
      if (ogTag) {
        ogTag.setAttribute('content', tag.content);
      } else {
        const meta = document.createElement('meta');
        meta.setAttribute('property', tag.property);
        meta.content = tag.content;
        document.head.appendChild(meta);
      }
    });

    // Twitter Card tags
    const twitterTags = [
      { name: 'twitter:card', content: 'summary_large_image' },
      { name: 'twitter:title', content: title || siteName },
      { name: 'twitter:description', content: description || defaultDescription },
      { name: 'twitter:image', content: image || defaultImage },
      { name: 'twitter:site', content: '@lushivie' }
    ];

    twitterTags.forEach(tag => {
      let twitterTag = document.querySelector(`meta[name="${tag.name}"]`);
      if (twitterTag) {
        twitterTag.setAttribute('content', tag.content);
      } else {
        const meta = document.createElement('meta');
        meta.name = tag.name;
        meta.content = tag.content;
        document.head.appendChild(meta);
      }
    });

    // Structured data (JSON-LD) for blog posts
    if (type === 'article' && title && author) {
      const structuredData = {
        "@context": "https://schema.org",
        "@type": "BlogPosting",
        "headline": title,
        "description": description || defaultDescription,
        "image": image || defaultImage,
        "author": {
          "@type": "Person",
          "name": author,
          "url": siteUrl
        },
        "publisher": {
          "@type": "Organization",
          "name": siteName,
          "logo": {
            "@type": "ImageObject",
            "url": "https://i.ibb.co/zH5KTH4n/IMG-20250811-194616-255.jpg"
          }
        },
        "datePublished": publishedTime,
        "dateModified": publishedTime,
        "mainEntityOfPage": {
          "@type": "WebPage",
          "@id": window.location.href
        }
      };

      let existingScript = document.querySelector('script[type="application/ld+json"]');
      if (existingScript) {
        existingScript.textContent = JSON.stringify(structuredData);
      } else {
        const script = document.createElement('script');
        script.type = 'application/ld+json';
        script.textContent = JSON.stringify(structuredData);
        document.head.appendChild(script);
      }
    }

    // Add canonical URL
    let canonicalLink = document.querySelector('link[rel="canonical"]');
    if (canonicalLink) {
      canonicalLink.href = window.location.href;
    } else {
      const link = document.createElement('link');
      link.rel = 'canonical';
      link.href = window.location.href;
      document.head.appendChild(link);
    }

  }, [title, description, keywords, image, type, publishedTime, author]);

  return null;
}

// Enhanced Advertisement Component with async loading and better placement
function AdSenseAd({ slot, format = "auto", responsive = true, className = "", placement = "content", style = {} }) {
  const [adLoaded, setAdLoaded] = useState(false);
  const [adConfig, setAdConfig] = useState({});
  const toast = useToast();

  useEffect(() => {
    // Load AdSense configuration
    const savedConfig = localStorage.getItem('lushivie-adsense-config');
    if (savedConfig) {
      setAdConfig(JSON.parse(savedConfig));
    }
  }, []);

  useEffect(() => {
    if (slot && adConfig.clientId && window.adsbygoogle) {
      // Delay ad loading slightly to improve Core Web Vitals
      const timer = setTimeout(() => {
        try {
          (window.adsbygoogle = window.adsbygoogle || []).push({});
          setAdLoaded(true);
        } catch (error) {
          console.error('AdSense error:', error);
          toast.error(`AdSense error: ${error.message}`, 5000);
        }
      }, placement === 'sidebar' ? 0 : 100); // Load sidebar ads immediately, others with slight delay

      return () => clearTimeout(timer);
    }
  }, [slot, adConfig.clientId, placement, toast]);

  if (!slot || !adConfig.enabled || !adConfig.clientId) return null;

  // Different styling based on placement
  const getAdStyles = () => {
    const baseStyles = {
      minHeight: '100px',
      backgroundColor: '#f9f9f9',
      borderRadius: '8px',
      border: '1px solid #e5e5e5',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      ...style
    };

    switch (placement) {
      case 'sidebar':
        return { ...baseStyles, minWidth: '300px', maxWidth: '336px' };
      case 'header':
        return { ...baseStyles, minHeight: '90px', width: '100%' };
      case 'footer':
        return { ...baseStyles, minHeight: '90px', width: '100%' };
      case 'between-posts':
        return { ...baseStyles, minHeight: '250px', width: '100%', maxWidth: '728px', margin: '0 auto' };
      default:
        return baseStyles;
    }
  };

  return (
    <div className={`ad-container ${className} flex justify-center my-8`}>
      {/* Lushivie AdSense Ad - {placement} placement */}
      <div style={getAdStyles()}>
        <ins
          className="adsbygoogle"
          style={{ 
            display: "block",
            width: "100%",
            height: "100%"
          }}
          data-ad-client={adConfig.clientId}
          data-ad-slot={slot}
          data-ad-format={format}
          data-full-width-responsive={responsive ? "true" : "false"}
        />
        {!adLoaded && (
          <div className="text-gray-400 text-sm flex items-center justify-center">
            <div className="animate-spin w-4 h-4 border-2 border-gray-300 border-t-gray-600 rounded-full mr-2"></div>
            Loading ad...
          </div>
        )}
      </div>
      {/* End AdSense Ad */}
    </div>
  );
}



// Post Modal Component
function PostModal({ post, isOpen, onClose }) {
  if (!isOpen || !post) return null;

  const handleStoryMode = () => {
    // Get all posts for story mode
    const allPosts = JSON.parse(localStorage.getItem('lushivie-all-posts') || '[]');
    const currentIndex = allPosts.findIndex(p => p.id === post.id);

    // Dispatch custom event to open story mode
    window.dispatchEvent(new CustomEvent('openStoryMode', { 
      detail: { posts: allPosts, initialIndex: Math.max(0, currentIndex) }
    }));
  };

  return (
    <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-black/60" onClick={onClose}>
      <div className="relative w-full max-w-5xl max-h-[90vh] bg-white dark:bg-gray-900 rounded-3xl shadow-2xl overflow-hidden" onClick={(e) => e.stopPropagation()}>
        <button
          onClick={onClose}
          className="absolute top-6 right-6 z-10 p-3 bg-black/20 hover:bg-black/40 rounded-full transition-colors"
        >
          <X size={24} className="text-white" />
        </button>

        {/* Story Mode Button */}
        <button
          onClick={handleStoryMode}
          className="absolute top-6 right-20 z-10 p-3 bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 rounded-full transition-colors shadow-lg"
          title="Open Story Mode"
        >
          <svg className="w-6 h-6 text-white" fill="currentColor" viewBox="0 0 24 24">
            <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
          </svg>
        </button>

        <div className="overflow-y-auto max-h-[90vh]">
          {post.featuredImage && (
            <div className="aspect-video w-full">
              <img
                src={post.featuredImage}
                alt={post.title}
                className="w-full h-full object-cover"
                onError={(e) => {
                  e.target.style.display = 'none';
                }}
              />
            </div>
          )}

          <div className="p-8">
            <div className="mb-8">
              <h1 className="text-4xl md:text-5xl font-black mb-6 bg-gradient-to-r from-rose-600 via-pink-600 to-orange-500 bg-clip-text text-transparent font-playfair leading-tight">
                {post.title}
              </h1>

              <div className="flex flex-wrap items-center gap-6 text-base font-medium text-gray-600 dark:text-gray-300">
                <div className="flex items-center space-x-2">
                  <Calendar size={16} className="text-rose-500"/>
                  <span>{new Date(post.publishedAt).toLocaleDateString()}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <User size={16} className="text-rose-500"/>
                  <span>{post.author}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Clock size={16} className="text-rose-500"/>
                  <span>5 min read</span>
                </div>
              </div>
            </div>

            <div className="prose prose-lg dark:prose-invert max-w-none font-playfair text-gray-800 dark:text-gray-200 leading-relaxed mb-12">
              <PremiumContentRenderer content={post.content} />
            </div>

            <PollQuizSection postId={post.id} postTitle={post.title} />
            <CommentsSection postId={post.id} />
          </div>
        </div>
      </div>
    </div>
  );
}

// Query Client
const queryClient = new QueryClient();

// Theme Context
const ThemeContext = createContext();

// Theme Provider Component
function ThemeProvider({ children }) {
  const [theme, setTheme] = useState(() => {
    if (typeof window !== "undefined") {
      return localStorage.getItem("theme") || "light";
    }
    return "light";
  });

  useEffect(() => {
    const root = window.document.documentElement;
    root.classList.remove("light", "dark", "cyberpunk");
    root.classList.add(theme);
    localStorage.setItem("theme", theme);

    // Apply CyberPunk theme specific styles
    if (theme === "cyberpunk") {
      root.style.setProperty('--primary', 'hsl(180, 100%, 50%)');
      root.style.setProperty('--primary-foreground', 'hsl(240, 10%, 8%)');

      // Add cyberpunk glow effects to body
      document.body.style.textShadow = '0 0 10px var(--cyber-cyan)';
      document.body.style.background = 'var(--cyber-bg)';
    } else {
      // Remove cyberpunk effects for other themes
      document.body.style.textShadow = '';
      document.body.style.background = '';
    }
  }, [theme]);

  const toggleTheme = () => {
    const themes = ["light", "dark", "cyberpunk"];
    const currentIndex = themes.indexOf(theme);
    const nextIndex = (currentIndex + 1) % themes.length;
    setTheme(themes[nextIndex]);
  };

  return (
    <ThemeContext.Provider value={{ theme, toggleTheme }}>
      {children}
    </ThemeContext.Provider>
  );
}

// Ultra Premium Logo Component with your actual logo
function Logo({ className = "", footer = false }) {
  return (
    <a href="/" className={`flex items-center space-x-3 ${className} cursor-pointer group`}>
      <div className="relative group">
        <div className="absolute -inset-1 bg-gradient-to-r from-rose-400 via-pink-500 to-orange-400 rounded-full blur opacity-30 group-hover:opacity-60 transition-opacity duration-500"></div>
        <div className="relative w-16 h-16 rounded-full overflow-hidden shadow-2xl transform group-hover:scale-110 transition-all duration-300 border-3 border-white dark:border-gray-800 bg-white dark:bg-gray-800">
          <img
            src="https://i.ibb.co/zH5KTH4n/IMG-20250811-194616-255.jpg"
            alt="Lushivie Logo"
            className="w-full h-full object-cover"
            onError={(e) => {
              // Fallback if image fails to load
              e.target.style.display = 'none';
              e.target.parentElement.innerHTML = '<span class="text-2xl font-black text-white drop-shadow-lg font-playfair flex items-center justify-center w-full h-full bg-gradient-to-br from-amber-200 via-orange-300 to-rose-400">L</span>';
            }}
          />
        </div>
      </div>
      <div className="flex flex-col">
        <span className={`text-2xl font-black font-playfair tracking-tight drop-shadow-lg ${
          footer ? 'text-white' : 'text-gray-900 dark:text-white'
        }`} style={{
          textShadow: '2px 2px 4px rgba(0,0,0,0.3), 0 0 10px rgba(244,114,182,0.3)'
        }}>
          Lushivie
        </span>
        <span className="text-xs font-medium tracking-[0.15em] uppercase text-rose-600 dark:text-rose-400 drop-shadow-sm">
          Beauty & Luxury
        </span>
      </div>
    </a>
  );
}

// Ultra Modern Navbar with Glass Effect
function Navbar({ onAction, posts = [], onSave, onShare }) {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const { theme, toggleTheme } = useContext(ThemeContext);
  const { user, isOwner } = useAuth();
  const [savedPostsModalOpen, setSavedPostsModalOpen] = useState(false);
  const [shareModalOpen, setShareModalOpen] = useState(false);
  const [shareModalPost, setShareModalPost] = useState(null);
  const [authModalOpen, setAuthModalOpen] = useState(false); // State for Auth Modal
  const [profileModalOpen, setProfileModalOpen] = useState(false); // State for Profile Modal
  const [commentsCount, setCommentsCount] = useState({}); // State for comments count
  const [selectedPost, setSelectedPost] = useState(null);
  const [postModalOpen, setPostModalOpen] = useState(false);

  const toast = useToast();

  // Use the persistent storage for saved posts
  const [savedPosts, setSavedPosts] = useState(() => getPersistentSavedPosts());

  const handleRemoveSavedPost = async (postId) => {
    try {
      // Get user profile for persistence
      const userProfile = user ? {
        uid: user.uid,
        email: user.email,
        displayName: user.displayName,
        photoURL: user.photoURL
      } : null;

      const currentSavedPosts = Array.isArray(savedPosts) ? savedPosts : [];
      const newSavedPosts = currentSavedPosts.filter(id => id !== postId);
      setSavedPosts(newSavedPosts);

      // Save with persistent storage system
      const savedPostsData = {
        postIds: newSavedPosts,
        userProfile: userProfile,
        lastUpdated: Date.now(),
        version: '3.0',
        persistent: true
      };
      savePersistentSavedPosts(savedPostsData);

      // Dispatch custom event for real-time updates
      window.dispatchEvent(new CustomEvent('savedPostsUpdated'));

      // Call backend to track unsave
      if (user) {
        await fetch('/.netlify/functions/server/api/posts/' + postId + '/save', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ 
            userId: user.uid,
            userEmail: user.email,
            userProfile: userProfile,
            action: 'unsave'
          }),
        });
      }

      toast.success('Post removed from saved items');
    } catch (error) {
      console.error('Error removing saved post:', error);
      toast.error('Failed to remove saved post');
    }
  };

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleLogout = async () => {
    try {
      await auth.signOut();
    } catch (error) {
      console.error('Logout error:', error);
    }
  };

  // Handle navbar actions
  const handleNavbarAction = (action, data) => {
    if (action === 'showPost') {
      setSelectedPost(data);
      setPostModalOpen(true);
      // Track post view when opened
      try {
        fetch('/.netlify/functions/server/api/posts/' + data.id + '/views', {
          method: 'POST',
        });
      } catch (error) {
        console.error('Error tracking view:', error);
      }
    } else if (action === 'personalization') {
      setPersonalizationModalOpen(true);
    } else if (action === 'auth') {
      setAuthModalOpen(true);
    } else if (action === 'profile') {
      setProfileModalOpen(true);
    } else if (action === 'savedPosts') {
      setSavedPostsModalOpen(true);
    }
  };

  // Fetch comments count for each post
  useEffect(() => {
    const fetchCommentsCount = async () => {
      const counts = {};
      for (const post of posts) {
        try {
          const response = await fetch('/.netlify/functions/server/api/posts/' + post.id + '/comments');
          const commentsData = await response.json(); // Assuming the response is an array of comments
          counts[post.id] = commentsData.length;
        } catch (error) {
          console.error('Error fetching comments for post ' + post.id + ':', error);
          counts[post.id] = 0;
        }
      }
      setCommentsCount(counts);
    };

    if (posts.length > 0) {
      fetchCommentsCount();
    }
  }, [posts]);

  // Function to open post modal from navbar
  const handlePostClick = (post) => {
    setSelectedPost(post);
    setPostModalOpen(true);

    // Track post view when opened
    try {
      fetch('/.netlify/functions/server/api/posts/' + post.id + '/views', {
        method: 'POST',
      });
    } catch (error) {
      console.error('Error tracking view:', error);
    }
  };

  return (
    <>
      <nav className={`fixed top-0 left-0 right-0 z-[100] transition-all duration-500 ${
        scrolled 
          ? 'bg-white/80 dark:bg-gray-900/80 backdrop-blur-xl border-b border-rose-200/50 dark:border-rose-800/50 shadow-xl shadow-rose-500/10' 
          : 'bg-transparent'
      }`}>
        <div className="container mx-auto px-6">
          <div className="flex h-20 items-center justify-between">
            <Logo />

            {/* Admin and Sign In buttons - Always visible next to logo */}
            <div className="flex items-center space-x-1 ml-3">
              {/* Admin Button */}
              {isOwner && (
                <a
                  href="/admin"
                  className="p-1.5 text-purple-600 dark:text-purple-400 hover:text-purple-700 dark:hover:text-purple-300 transition-colors"
                  title="Admin Panel"
                >
                  <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M12 1L3 5V11C3 16.55 6.84 21.74 12 23C17.16 21.74 21 16.55 21 11V5L12 1M12 7C13.11 7 14 7.9 14 9C14 10.11 13.11 11 12 11C10.9 11 10 10.11 10 9C10 7.9 10.9 7 12 7M18 17H6V15.5C6 13.56 8.91 12.5 12 12.5C15.09 12.5 18 13.56 18 15.5V17Z"/>
                  </svg>
                </a>
              )}

              {user ? (
                <button
                  onClick={() => onAction && onAction('profile')}
                  className="p-1.5 text-gray-700 dark:text-gray-200 cyberpunk:text-cyan-100 hover:text-rose-600 dark:hover:text-rose-400 cyberpunk:hover:text-cyan-400 transition-colors"
                  title="Profile"
                >
                  <div className="w-4 h-4 rounded-full overflow-hidden">
                    {user.photoURL ? (
                      <img src={user.photoURL} alt={user.displayName} className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full bg-gradient-to-br from-rose-400 to-pink-600 cyberpunk:from-cyan-400 cyberpunk:to-purple-600 flex items-center justify-center">
                        <User size={10} className="text-white" />
                      </div>
                    )}
                  </div>
                </button>
              ) : (
                <button
                  onClick={() => onAction && onAction('auth')}
                  className="p-1.5 text-rose-600 dark:text-rose-400 cyberpunk:text-cyan-400 hover:text-rose-700 dark:hover:text-rose-300 cyberpunk:hover:text-cyan-300 transition-colors"
                  title="Sign In"
                >
                  <LogIn size={16} />
                </button>
              )}
            </div>

            {/* Desktop Navigation */}
            <div className="hidden lg:flex items-center space-x-4 ml-auto">
              <a href="/" className="nav-link-premium group">
                <span className="relative z-10 text-sm font-medium">Home</span>
                <div className="absolute inset-0 bg-gradient-to-r from-rose-500/20 to-pink-500/20 rounded-lg scale-0 group-hover:scale-100 transition-all duration-300"></div>
              </a>
              <a href="/about" className="nav-link-premium group">
                <span className="relative z-10 text-sm font-medium">About</span>
                <div className="absolute inset-0 bg-gradient-to-r from-rose-500/20 to-pink-500/20 rounded-lg scale-0 group-hover:scale-100 transition-all duration-300"></div>
              </a>
              <a href="/contact" className="nav-link-premium group">
                <span className="relative z-10 text-sm font-medium">Contact</span>
                <div className="absolute inset-0 bg-gradient-to-r from-rose-500/20 to-pink-500/20 rounded-lg scale-0 group-hover:scale-100 transition-all duration-300"></div>
              </a>

              <button
                onClick={() => setSavedPostsModalOpen(true)}
                className="text-gray-700 dark:text-gray-200 hover:text-rose-600 transition-colors flex items-center space-x-1 nav-link-premium group"
              >
                <span className="relative z-10 flex items-center space-x-1">
                  <Heart size={16} />
                  <span className="text-sm font-medium">Saved Posts</span>
                </span>
                <div className="absolute inset-0 bg-gradient-to-r from-rose-500/20 to-pink-500/20 rounded-lg scale-0 group-hover:scale-100 transition-all duration-300"></div>
              </button>
            </div>

            {/* Theme Toggle and Logout - Positioned together */}
            <div className="flex items-center space-x-1 ml-auto">
              <button
                onClick={toggleTheme}
                className="p-1.5 text-gray-700 dark:text-gray-200 cyberpunk:text-cyan-100 hover:text-rose-500 cyberpunk:hover:text-cyan-400 transition-colors"
                title={`Switch theme (Current: ${theme})`}
              >
                {theme === "light" ? (
                  <Moon size={16} />
                ) : theme === "dark" ? (
                  <Sun size={16} />
                ) : (
                  <Sparkles size={16} className="text-cyan-400" />
                )}
              </button>

              {user && (
                <button
                  onClick={handleLogout}
                  className="p-1.5 text-red-500 cyberpunk:text-red-400 hover:text-red-600 cyberpunk:hover:text-red-300 transition-colors"
                  title="Logout"
                >
                  <LogOut size={16} />
                </button>
              )}
            </div>

            {/* Right Side Actions */}
            <div className="hidden lg:flex items-center space-x-0.5 mr-1">
              <button className="p-1.5 text-gray-700 dark:text-gray-200 cyberpunk:text-cyan-100 hover:text-rose-500 cyberpunk:hover:text-cyan-400 transition-colors">
                <Search size={14} />
              </button>
              <button
                onClick={() => onAction && onAction('personalization')}
                className="p-1.5 text-gray-700 dark:text-gray-200 cyberpunk:text-cyan-100 hover:text-rose-500 cyberpunk:hover:text-cyan-400 transition-colors"
                title="Preferences Settings"
              >
                <Settings size={14} />
              </button>
            </div>

            {/* Mobile Menu Button - Positioned far right with proper spacing */}
            <button
              className="lg:hidden p-1.5 text-gray-700 dark:text-gray-200 cyberpunk:text-cyan-100 hover:text-rose-500 cyberpunk:hover:text-cyan-400 transition-colors ml-1 mr-2"
              onClick={() => setIsOpen(!isOpen)}
            >
              {isOpen ? <X size={18} /> : <Menu size={18} />}
            </button>
          </div>

          {/* Mobile Menu */}
          {isOpen && (
            <div className="lg:hidden absolute top-full left-0 right-0 mt-2 mx-6 bg-white/95 dark:bg-gray-900/95 backdrop-blur-xl rounded-2xl border border-rose-200/50 dark:border-rose-800/50 shadow-2xl overflow-hidden">
              <div className="p-6 space-y-3">

                <a href="/" className="block py-3 px-4 rounded-xl hover:bg-rose-50/80 dark:hover:bg-rose-900/20 transition-colors font-medium">Home</a>
                <a href="/about" className="block py-3 px-4 rounded-xl hover:bg-rose-50/80 dark:hover:bg-rose-900/20 transition-colors font-medium">About</a>
                <a href="/contact" className="block py-3 px-4 rounded-xl hover:bg-rose-50/80 dark:hover:bg-rose-900/20 transition-colors font-medium">Contact</a>

                <button
                  onClick={() => {
                    setSavedPostsModalOpen(true);
                    setIsOpen(false);
                  }}
                  className="w-full text-left py-3 px-4 rounded-xl hover:bg-rose-50/80 dark:hover:bg-rose-900/20 transition-colors font-medium flex items-center space-x-2"
                >
                  <Heart size={16} />
                  <span>Saved Posts</span>
                </button>

                <button
                  onClick={() => {
                    onAction && onAction('personalization');
                    setIsOpen(false);
                  }}
                  className="w-full text-left py-3 px-4 rounded-xl hover:bg-rose-50/80 dark:hover:bg-rose-900/20 transition-colors font-medium flex items-center space-x-2"
                >
                  <Settings size={16} />
                  <span>Preferences</span>
                </button>

                {/* Other Pages */}
                <div className="border-t border-rose-200/50 dark:border-rose-800/50 pt-3 mt-3">
                  <a href="/privacy-policy" className="block py-3 px-4 rounded-xl hover:bg-rose-50/80 dark:hover:bg-rose-900/20 transition-colors font-medium">Privacy Policy</a>
                  <a href="/terms" className="block py-3 px-4 rounded-xl hover:bg-rose-50/80 dark:hover:bg-rose-900/20 transition-colors font-medium">Terms of Service</a>
                </div>
              </div>
            </div>
          )}
        </div>
      </nav>

      <ShareModal 
        post={shareModalPost}
        isOpen={shareModalOpen}
        onClose={() => setShareModalOpen(false)}
      />

      <SavedPostsModal 
        posts={posts} // Pass all posts to filter saved ones inside the modal
        isOpen={savedPostsModalOpen}
        onClose={() => setSavedPostsModalOpen(false)}
        onPostClick={(post) => {
          console.log('Navbar SavedPostsModal onPostClick called with:', post);
          setSavedPostsModalOpen(false); // Close saved posts modal first
          // Trigger the same action as if clicked from navbar
          if (onAction) {
            onAction('showPost', post);
          }
        }}
        onRemovePost={handleRemoveSavedPost}
      />
       <AuthModal
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
      />
      {/* Role-based Profile Modals */}
      {isOwner ? (
        <AdminProfileModal
          isOpen={profileModalOpen}
          onClose={() => setProfileModalOpen(false)}
        />
      ) : (
        <UserProfileModal
          isOpen={profileModalOpen}
          onClose={() => setProfileModalOpen(false)}
        />
      )}
      <PostModal 
        post={selectedPost} 
        isOpen={postModalOpen} 
        onClose={() => {
          setPostModalOpen(false);
          setSelectedPost(null);
        }} 
      />
    </>
  );
}

// Hero Stats Component with Dynamic Data
function HeroStats() {
  const { data: posts = [] } = useQuery({
    queryKey: ["posts"],
    queryFn: async () => {
      const response = await fetch("/.netlify/functions/server/api/posts");
      if (!response.ok) throw new Error("Failed to fetch posts");
      return response.json();
    }
  });

  // Calculate dynamic stats
  const totalPosts = posts.length;
  const totalViews = posts.reduce((acc, post) => acc + (post.views || Math.floor(Math.random() * 500) + 100), 0);
  const estimatedVisitors = Math.max(totalViews * 1.2, 1000);

  const formatNumber = (num) => {
    if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
    if (num >= 1000) return `${(num / 1000).toFixed(1)}K`;
    return num.toString();
  };

  const heroStats = [
    { 
      number: formatNumber(Math.floor(estimatedVisitors)), 
      label: "Happy Readers", 
      icon: Heart 
    },
    { 
      number: totalPosts.toString(), 
      label: "Beauty Posts", 
      icon: Star 
    },
    { 
      number: formatNumber(Math.max(totalViews + 1000, 1200)), 
      label: "Visitors", 
      icon: Eye 
    },
    { 
      number: "24/7", 
      label: "Support", 
      icon: Shield 
    }
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-8 max-w-3xl mx-auto">
      {heroStats.map((stat, index) => (
        <div key={index} className="text-center group">
          <div className="w-12 h-12 bg-gradient-to-br from-rose-500 to-pink-600 rounded-xl flex items-center justify-center mx-auto mb-3 group-hover:scale-110 transition-transform duration-300 shadow-lg">
            <stat.icon className="text-white" size={20} />
          </div>
          <h3 className="text-2xl font-bold text-gray-800 dark:text-white mb-1 font-playfair">
            {stat.number}
          </h3>
          <p className="text-sm text-gray-600 dark:text-gray-400 font-medium">
            {stat.label}
          </p>
        </div>
      ))}
    </div>
  );
}

// Ultra Premium Hero Section
function HeroSection() {
  const { user } = useAuth();
  const toast = useToast();

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Ultra Premium Animated Background */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-gradient-to-br from-rose-50/90 via-pink-50/90 via-orange-50/90 to-amber-50/90 dark:from-rose-950/30 dark:via-pink-950/30 dark:via-orange-950/30 dark:to-amber-950/30"></div>

        {/* Floating Orbs */}
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-gradient-to-br from-rose-300/40 to-pink-400/40 rounded-full mix-blend-multiply filter blur-2xl animate-float-slow"></div>
        <div className="absolute top-1/3 right-1/4 w-80 h-80 bg-gradient-to-br from-pink-300/40 to-orange-400/40 rounded-full mix-blend-multiply filter blur-2xl animate-float-medium" style={{animationDelay: '2s'}}></div>
        <div className="absolute bottom-1/4 left-1/3 w-72 h-72 bg-gradient-to-br from-orange-300/40 to-amber-400/40 rounded-full mix-blend-multiply filter blur-2xl animate-float-fast" style={{animationDelay: '4s'}}></div>

        {/* Premium Particles */}
        <div className="absolute inset-0 opacity-30">
          {[...Array(50)].map((_, i) => (
            <div
              key={i}
              className="absolute w-1 h-1 bg-rose-400 rounded-full animate-sparkle"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 3}s`,
                animationDuration: `${2 + Math.random() * 2}s`
              }}
            />
          ))}
        </div>
      </div>

      <div className="container mx-auto px-6 relative z-10">
        <div className="text-center max-w-6xl mx-auto">
          <div className="animate-fade-in-up">
            {/* Ultra Premium Badge */}
            <div className="inline-flex items-center space-x-2 bg-white/20 dark:bg-gray-900/20 backdrop-blur-sm px-6 py-3 rounded-full border border-white/30 dark:border-gray-700/30 mb-8 shadow-lg">
              <Sparkles className="w-5 h-5 text-rose-500" />
              <span className="text-sm font-semibold bg-gradient-to-r from-rose-600 to-pink-600 bg-clip-text text-transparent">Premium Beauty Experience</span>
              <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
            </div>

            <h1 className="text-7xl md:text-9xl font-black mb-8 font-playfair leading-none">
              <span className="block bg-gradient-to-r from-rose-600 via-pink-600 to-orange-500 bg-clip-text text-transparent drop-shadow-sm">Discover</span>
              <span className="block bg-gradient-to-r from-orange-500 via-amber-500 to-rose-600 bg-clip-text text-transparent drop-shadow-sm">Luxury Beauty</span>
            </h1>

            <p className="text-xl md:text-2xl text-gray-600 dark:text-gray-300 mb-12 max-w-4xl mx-auto leading-relaxed font-medium">
              Expert reviews, premium insights, and exclusive beauty secrets from 
              <span className="font-bold text-rose-600"> Delhi's finest beauty connoisseur</span>
            </p>



            {/* Dynamic Premium Stats */}
            <HeroStats />
          </div>
        </div>
      </div>
    </section>
  );
}

// Enhanced Post Card with Ultra Premium Design
function PostCard({ post, featured = false, onReadMore, onAuthorClick, onSave, onShare, commentsCount = 0 }) {
  const queryClient = useQueryClient();

  const { data: postStatsData = {} } = useQuery({
    queryKey: ["post-stats", post.id],
    queryFn: () => fetch('/.netlify/functions/server/api/posts/' + post.id + '/stats').then(res => res.ok ? res.json() : { views: 0, rating: 0 }),
    initialData: { views: post.views || 0, rating: post.rating || 0 } // Fallback to post data
  });

  // Fetch comments count for this specific post
  const { data: postCommentsData = [] } = useQuery({
    queryKey: ["post-comments", post.id],
    queryFn: async () => {
      const response = await fetch('/.netlify/functions/server/api/posts/' + post.id + '/comments');
      if (!response.ok) return [];
      return response.json();
    }
  });

  const viewCount = postStatsData.views || 0;
  const actualCommentsCount = postCommentsData.length || commentsCount || 0;

  const [authorProfile, setAuthorProfile] = useState(null);
  const { user } = useAuth();

  // Use the savedPosts prop from parent component or get from localStorage as fallback
  const [isSaved, setIsSaved] = useState(() => {
    try {
      const saved = localStorage.getItem('lushivie-saved-posts');
      if (!saved || saved === 'undefined' || saved === 'null') {
        return false;
      }
      const parsedSaved = JSON.parse(saved);

      // Handle both old and new format
      if (Array.isArray(parsedSaved)) {
        return parsedSaved.includes(post.id); // Old format
      } else if (parsedSaved && parsedSaved.postIds && Array.isArray(parsedSaved.postIds)) {
        return parsedSaved.postIds.includes(post.id); // New format
      } else {
        return false;
      }
    } catch (error) {
      console.warn('Error parsing saved posts in PostCard:', error);
      return false;
    }
  });

  // Listen for localStorage changes to update save state
  useEffect(() => {
    const handleStorageChange = () => {
      try {
        const saved = localStorage.getItem('lushivie-saved-posts');
        if (!saved || saved === 'undefined' || saved === 'null') {
          setIsSaved(false);
          return;
        }
        const parsedSaved = JSON.parse(saved);

        // Handle both old and new format
        if (Array.isArray(parsedSaved)) {
          setIsSaved(parsedSaved.includes(post.id)); // Old format
        } else if (parsedSaved && parsedSaved.postIds && Array.isArray(parsedSaved.postIds)) {
          setIsSaved(parsedSaved.postIds.includes(post.id)); // New format
        } else {
          setIsSaved(false);
        }
      } catch (error) {
        console.warn('Error parsing saved posts in PostCard:', error);
        setIsSaved(false);
      }
    };

    window.addEventListener('storage', handleStorageChange);

    // Also listen for custom events for immediate updates
    window.addEventListener('savedPostsUpdated', handleStorageChange);

    return () => {
      window.removeEventListener('storage', handleStorageChange);
      window.removeEventListener('savedPostsUpdated', handleStorageChange);
    };
  }, [post.id]);

  // Helper function to get author profile image
  const getAuthorProfileImage = () => {
    return getUniversalProfileImage(post.authorEmail, post.author, post.authorImage) || post.authorImage;
  };

  // Load author profile data with real-time updates using universal utilities
  useEffect(() => {
    const loadAuthorProfile = () => {
      try {
        // Use universal utilities for consistency
        const displayName = getUserDisplayName(post.authorEmail, post.author);
        const profileImage = getUniversalProfileImage(
          post.authorEmail,
          post.author,
          post.author
        ) || getAuthorProfileImage();

        setAuthorProfile({
          displayName,
          profileImage
        });
      } catch (error) {
        console.error('Error loading author profile in PostCard:', error);
        setAuthorProfile({
          displayName: post.author || 'Unknown Author',
          profileImage: getAuthorProfileImage()
        });
      }
    };

    loadAuthorProfile();

    // Enhanced event listeners for real-time updates
    const handleProfileUpdate = (event) => {
      console.log('Profile update detected in PostCard:', event.type);
      setTimeout(() => {
        loadAuthorProfile();
        setAuthorProfile(prev => ({...prev, timestamp: Date.now()}));
      }, 50);
    };

    const eventTypes = [
      'profileUpdated', 'adminProfileUpdated', 'adminProfilePersisted',
      'userProfileUpdated', 'storage', 'lushivie-profile-changed', 'globalImageUpdate'
    ];

    eventTypes.forEach(eventType => {
      window.addEventListener(eventType, handleProfileUpdate);
    });

    return () => {
      eventTypes.forEach(eventType => {
        window.removeEventListener(eventType, handleProfileUpdate);
      });
    };
  }, [post.author, post.authorEmail, post.id]); // Added post.id for better refresh

  return (
    <article className={`group bg-white dark:bg-gray-900 rounded-3xl overflow-hidden shadow-xl hover:shadow-2xl transition-all duration-700 transform hover:-translate-y-2 border border-gray-100 dark:border-gray-800 hover:border-rose-200 dark:hover:border-rose-700 ${
      featured ? 'md:col-span-2 md:row-span-2' : ''
    }`}>
      <div className={`relative overflow-hidden ${featured ? 'aspect-[2/1]' : 'aspect-video'}`}>
        {post.featuredImage && (
          <img
            src={post.featuredImage}
            alt={post.title}
            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-1000"
          />
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>

        {/* Premium Badge */}
        <div className="absolute top-6 left-6">
          <span className="bg-gradient-to-r from-rose-500 to-pink-600 text-white px-4 py-2 rounded-full text-sm font-bold shadow-lg backdrop-blur-sm">
            Premium
          </span>
        </div>

        {/* Action Buttons */}
        <div className="absolute bottom-6 right-6 opacity-0 group-hover:opacity-100 transition-all duration-500 transform translate-y-4 group-hover:translate-y-0">
          <div className="flex space-x-3">
            <button 
              onClick={(e) => {
                e.stopPropagation();
                onSave && onSave(post);
              }} 
              className={`p-3 rounded-full transition-colors shadow-lg ${isSaved ? 'bg-rose-500 text-white' : 'bg-white/20 backdrop-blur-sm hover:bg-white/30 text-white'}`}
              title={isSaved ? 'Remove from saved' : 'Save post'}
            >
              <Heart size={18} className={isSaved ? 'fill-current' : ''} />
            </button>
            <button 
              onClick={(e) => {
                e.stopPropagation();
                onShare && onShare(post);
              }} 
              className="p-3 bg-white/20 backdrop-blur-sm rounded-full hover:bg-white/30 transition-colors shadow-lg"
              title="Share post"
            >
              <Share2 size={18} className="text-white" />
            </button>
            <button 
              onClick={(e) => {
                e.stopPropagation();
                // Open story mode with this post
                const allPosts = JSON.parse(localStorage.getItem('lushivie-all-posts') || '[]');
                const currentIndex = allPosts.findIndex(p => p.id === post.id);
                window.dispatchEvent(new CustomEvent('openStoryMode', { 
                  detail: { posts: allPosts, initialIndex: Math.max(0, currentIndex) }
                }));
              }} 
              className="p-3 bg-gradient-to-r from-purple-500/20 to-pink-500/20 backdrop-blur-sm rounded-full hover:from-purple-500/30 hover:to-pink-500/30 transition-colors shadow-lg"
              title="Story Mode"
            >
              <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
              </svg>
            </button>
            <button 
              onClick={(e) => {
                e.stopPropagation();
                // Open tip modal
                const event = new CustomEvent('openTipModal', { detail: post });
                window.dispatchEvent(event);
              }} 
              className="p-3 bg-gradient-to-r from-yellow-500/20 to-orange-500/20 backdrop-blur-sm rounded-full hover:from-yellow-500/30 hover:to-orange-500/30 transition-colors shadow-lg"
              title="Tip the author"
            >
              <Gift size={18} className="text-white" />
            </button>
          </div>
        </div>
      </div>

      <div className={`p-8 ${featured ? 'md:p-10' : ''}`}>
        <div className="flex items-center justify-between text-sm text-gray-600 dark:text-gray-400 mb-4">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-1">
              <Calendar size={14} />
              <span>{new Date(post.publishedAt).toLocaleDateString()}</span>
            </div>
            <div className="flex items-center space-x-1">
              <Eye size={14} />
              <span>{viewCount >= 1000 ? `${(viewCount/1000).toFixed(1)}k` : viewCount}</span>
            </div>
            <div className="flex items-center space-x-1">
              <MessageCircle size={14} />
              <span>{actualCommentsCount}</span>
            </div>
          </div>
          {/* Removed Star rating */}
        </div>

        <h3 className={`font-bold mb-4 line-clamp-2 group-hover:text-rose-600 transition-colors duration-300 cursor-pointer ${
          featured ? 'text-4xl md:text-5xl' : 'text-2xl'
        }`} onClick={async () => {
          // Track view when post is clicked and update UI immediately
          try {
            await fetch('/.netlify/functions/server/api/posts/' + post.id + '/views', {
              method: 'POST',
            });
            // Invalidate queries to refresh view counts in real-time
            queryClient.invalidateQueries(["post-stats", post.id]);
            queryClient.invalidateQueries(["posts"]);
          } catch (error) {
            console.error('Error tracking view:', error);
          }
          onReadMore && onReadMore(post);
        }}>
          <span className="font-playfair hover:text-rose-600 transition-colors">
            {post.title}
          </span>
        </h3>

        <p className={`text-gray-600 dark:text-gray-300 mb-8 ${
          featured ? 'text-lg' : 'text-base'
        }`}>
          {post.description || post.excerpt}
        </p>

        <div className="flex items-center justify-between">
          <button 
            onClick={() => onAuthorClick && onAuthorClick(post)} 
            className="flex items-center space-x-3 flex-1 text-left hover:bg-gray-50 dark:hover:bg-gray-800/50 rounded-lg p-2 transition-colors duration-200 group"
          >
            <div className="w-10 h-10 rounded-full flex items-center justify-center shadow-lg flex-shrink-0 overflow-hidden border-2 border-rose-200 dark:border-rose-700 group-hover:border-rose-400 transition-colors">
              {authorProfile?.profileImage ? (
                <img 
                  src={authorProfile.profileImage} 
                  alt={authorProfile.displayName || post.author}
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    e.target.style.display = 'none';
                    e.target.parentElement.innerHTML = '<div class="w-full h-full bg-gradient-to-br from-rose-400 to-pink-600 flex items-center justify-center"><span class="text-white font-bold text-sm">' + ((authorProfile?.displayName || post.author)?.charAt(0)?.toUpperCase() || 'A') + '</span></div>';
                  }}
                />
              ) : (
                <div className="w-full h-full bg-gradient-to-br from-rose-400 to-pink-600 flex items-center justify-center">
                  <span className="text-white font-bold text-sm">
                    {(authorProfile?.displayName || post.author)?.charAt(0)?.toUpperCase() || 'A'}
                  </span>
                </div>
              )}
            </div>
            <div className="min-w-0 flex-1">
              <p className="font-bold text-gray-800 dark:text-white text-sm truncate group-hover:text-rose-600 transition-colors">{authorProfile?.displayName || post.author}</p>
              <p className="text-xs text-gray-500 dark:text-gray-400">Beauty Expert • Click to view profile</p>
            </div>
          </button>

          <button onClick={async () => {
            // Track view when Read More is clicked and update UI immediately
            try {
              await fetch('/.netlify/functions/server/api/posts/' + post.id + '/views', {
                method: 'POST',
              });
              // Invalidate queries to refresh view counts in real-time
              queryClient.invalidateQueries(["post-stats", post.id]);
              queryClient.invalidateQueries(["posts"]);
            } catch (error) {
              console.error('Error tracking view:', error);
            }
            onReadMore && onReadMore(post);
          }} className="ml-4 flex-shrink-0 inline-flex items-center px-3 py-2 text-sm font-semibold text-rose-600 dark:text-rose-400 hover:text-rose-700 dark:hover:text-rose-300 transition-colors group cursor-pointer">
            Read More
            <ArrowRight className="ml-1 group-hover:translate-x-1 transition-transform" size={14} />
          </button>
        </div>
      </div>
    </article>
  );
}

// Featured Section Component
function FeaturedSection({ onPostClick, onAuthorClick, posts = [], onSave, onShare, commentsCount = {} }) {
  if (!posts || posts.length === 0) {
    return (
      <section className="py-20 bg-gradient-to-br from-rose-50 via-pink-50 to-orange-50 dark:from-rose-950/20 dark:via-pink-950/20 dark:to-orange-950/20">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-rose-500 to-pink-600 bg-clip-text text-transparent font-playfair">
              Featured Posts
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
              Discover the latest in luxury beauty
            </p>
          </div>

          <div className="text-center py-12 bg-white dark:bg-gray-900 rounded-3xl shadow-xl border border-gray-100 dark:border-gray-800 max-w-2xl mx-auto">
            <div className="w-24 h-24 bg-gradient-to-br from-rose-100 to-pink-100 rounded-full flex items-center justify-center mx-auto mb-6 shadow-lg">
              <Edit className="text-rose-600" size={32} />
            </div>
            <h3 className="text-3xl font-bold mb-4 text-gray-800 dark:text-white font-playfair">No Posts Yet</h3>
            <p className="text-gray-600 dark:text-gray-300 mb-8">
              Create your first beautiful post to get started!
            </p>
            <a href="/admin" className="btn-premium-gradient">Create First Post</a>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="py-20 bg-gradient-to-br from-rose-50 via-pink-50 to-orange-50 dark:from-rose-950/20 dark:via-pink-950/20 dark:to-orange-950/20">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-rose-500 to-pink-600 bg-clip-text text-transparent font-playfair">
            Featured Posts
          </h2>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
            Discover the latest in luxury beauty with our featured articles
          </p>
        </div>

        {/* Responsive Grid Layout */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {posts.slice(0, 6).map((post, index) => (
            <PostCard
              key={post.id}
              post={post}
              featured={index === 0}
              onReadMore={onPostClick}
              onAuthorClick={onAuthorClick}
              onSave={onSave}
              onShare={onShare}
              commentsCount={commentsCount[post.id] || 0}
            />
          ))}
        </div>
      </div>
    </section>
  );
}

// Newsletter Section with Modern Design
function Newsletter() {
  const [email, setEmail] = useState("");
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");

  const toast = useToast();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    setError("");

    try {
      const response = await fetch('/.netlify/functions/server/api/newsletter/subscribe', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || 'Subscription failed');
      }

      setIsSubmitted(true);
      setEmail("");
      toast.success('Welcome to Lushivie! Check your email for a special gift.', 6000);
    } catch (err) {
      setError(err.message);
      toast.error(err.message, 5000);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <section className="py-20 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-rose-900 via-pink-900 to-orange-900"></div>
      <div className="absolute inset-0 bg-[url('data:image/svg+xml,%3Csvg%20width%3D%2260%22%20height%3D%2260%22%20viewBox%3D%220%200%2060%2060%22%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%3E%3Cg%20fill%3D%22none%22%20fill-rule%3D%22evenodd%22%3E%3Cg%20fill%3D%22%23ffffff%22%20fill-opacity%3D%220.05%22%3E%3Ccircle%20cx%3D%2230%22%20cy%3D%2230%22%20r%3D%222%22/%3E%3C/g%3E%3C/g%3E%3C/svg%3E')]"></div>

      <div className="container mx-auto px-6 relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl md:text-6xl font-bold mb-6 text-white font-playfair">
            Join the Beauty Elite
          </h2>
          <p className="text-xl text-white/80 mb-12 max-w-2xl mx-auto">
            Get exclusive access to luxury beauty secrets, product reviews, and insider tips delivered to your inbox weekly.
          </p>

          {isSubmitted ? (
            <div className="glassmorphism rounded-2xl p-8 max-w-md mx-auto">
              <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <Heart className="text-white" size={24} />
              </div>
              <h3 className="text-2xl font-bold text-white mb-2">Welcome to the Elite!</h3>
              <p className="text-white/80 mb-4">Check your inbox for a special welcome gift. You'll receive our latest beauty tips and exclusive offers!</p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="max-w-md mx-auto space-y-4">
              <div className="glassmorphism rounded-2xl p-4">
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Enter your email address"
                  className="w-full bg-transparent border-none outline-none px-4 py-3 text-white placeholder-white/60 text-lg"
                  required
                  disabled={isLoading}
                />
              </div>

              {error && (
                <div className="bg-red-500/20 border border-red-400/50 rounded-xl p-3">
                  <p className="text-red-200 text-sm text-center">{error}</p>
                </div>
              )}

              <button
                type="submit"
                disabled={isLoading}
                className="w-full bg-gradient-to-r from-rose-500 to-pink-500 text-white px-8 py-4 rounded-2xl font-bold hover:from-rose-600 hover:to-pink-600 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isLoading ? 'Subscribing...' : 'Subscribe to Newsletter'}
              </button>

              <p className="text-white/60 text-sm text-center">
                Join 10,000+ beauty enthusiasts • Unsubscribe anytime
              </p>
            </form>
          )}

          {/* Email Us Section */}
          <div className="mt-16 pt-12 border-t border-white/20">
            <div className="max-w-2xl mx-auto">
              <div className="text-center mb-8">
                <h2 className="text-3xl md:text-4xl font-bold mb-4 text-white font-playfair">
                  Email Us Directly
                </h2>
                <p className="text-white/80 text-lg mb-2">
                  Have specific questions or want to collaborate? Send us a message directly!
                </p>
                <p className="text-white/60 text-sm">
                  Our team at <span className="font-semibold text-rose-300">Help@lushivie.com</span> is here to help
                </p>
              </div>
              <EmailUsForm />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

// Email Us Form Component
function EmailUsForm() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    subject: "",
    message: ""
  });
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const toast = useToast();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const response = await fetch('/.netlify/functions/server/api/contact', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...formData,
          email: formData.email || 'Help@lushivie.com'
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || 'Failed to send message');
      }

      setIsSubmitted(true);
      setFormData({ name: "", email: "", subject: "", message: "" });
      toast.success('Message sent successfully! We\'ll get back to you within 24 hours.', 6000);
    } catch (error) {
      toast.error('Failed to send message: ' + error.message, 5000);
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isSubmitted) {
    return (
      <div className="glassmorphism rounded-2xl p-8 text-center">
        <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
          <Heart className="text-white" size={24} />
        </div>
        <h3 className="text-2xl font-bold text-white mb-2">Message Sent!</h3>
        <p className="text-white/80 mb-4">Thank you for reaching out. We'll respond within 24 hours.</p>
        <button
          onClick={() => {
            setIsSubmitted(false);
            setFormData({ name: "", email: "", subject: "", message: "" });
          }}
          className="text-white/60 hover:text-white transition-colors"
        >
          Send Another Message
        </button>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="glassmorphism rounded-xl p-4">
          <input
            type="text"
            value={formData.name}
            onChange={(e) => setFormData({...formData, name: e.target.value})}
            placeholder="Your Name"
            className="w-full bg-transparent border-none outline-none text-white placeholder-white/60"
            required
          />
        </div>
        <div className="glassmorphism rounded-xl p-4">
          <input
            type="email"
            value={formData.email}
            onChange={(e) => setFormData({...formData, email: e.target.value})}
            placeholder="Your Email (Optional)"
            className="w-full bg-transparent border-none outline-none text-white placeholder-white/60"
          />
        </div>
      </div>

      <div className="glassmorphism rounded-xl p-4">
        <input
          type="text"
          value={formData.subject}
          onChange={(e) => setFormData({...formData, subject: e.target.value})}
          placeholder="Subject"
          className="w-full bg-transparent border-none outline-none text-white placeholder-white/60"
          required
        />
      </div>

      <div className="glassmorphism rounded-xl p-4">
        <textarea
          value={formData.message}
          onChange={(e) => setFormData({...formData, message: e.target.value})}
          placeholder="Your Message"
          rows={4}
          className="w-full bg-transparent border-none outline-none text-white placeholder-white/60 resize-none"
          required
        />
      </div>

      <button
        type="submit"
        disabled={isSubmitting}
        className="w-full bg-gradient-to-r from-blue-500 to-purple-500 text-white px-8 py-4 rounded-2xl font-bold hover:from-blue-600 hover:to-purple-600 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center space-x-2"
      >
        {isSubmitting ? (
          <>
            <div className="animate-spin w-5 h-5 border-b-2 border-white"></div>
            <span>Sending...</span>
          </>
        ) : (
          <>
            <Mail size={20} />
            <span>Send Message</span>
          </>
        )}
      </button>

      <p className="text-white/60 text-sm text-center">
        Questions about beauty products or collaborations? We respond within 24 hours.
      </p>
    </form>
  );
}

// Stats Section with Dynamic Data
function StatsSection() {
  const { data: posts = [] } = useQuery({
    queryKey: ["posts"],
    queryFn: async () => {
      const response = await fetch("/.netlify/functions/server/api/posts");
      if (!response.ok) throw new Error("Failed to fetch posts");
      return response.json();
    }
  });

  // Calculate dynamic stats
  const totalPosts = posts.length;
  const totalViews = posts.reduce((acc, post) => acc + (post.views || Math.floor(Math.random() * 500) + 100), 0);
  const estimatedReaders = Math.max(totalViews * 1.5, 1200);
  const estimatedVisitors = Math.max(totalViews * 2.2, 2000);

  const formatNumber = (num) => {
    if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
    if (num >= 1000) return `${(num / 1000).toFixed(1)}K`;
    return num.toString();
  };

  const stats = [
    { 
      number: formatNumber(Math.floor(estimatedReaders)), 
      label: "Monthly Readers", 
      icon: Eye,
      color: "from-blue-500 to-blue-600"
    },
    { 
      number: totalPosts.toString(), 
      label: "Blog Posts", 
      icon: Star,
      color: "from-rose-500 to-pink-600"
    },
    { 
      number: formatNumber(Math.floor(estimatedVisitors)), 
      label: "Visitors", 
      icon: TrendingUp,
      color: "from-purple-500 to-purple-600"
    },
    { 
      number: formatNumber(totalViews), 
      label: "Total Views", 
      icon: MessageCircle,
      color: "from-green-500 to-green-600"
    }
  ];

  return (
    <section className="py-20 bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 dark:bg-black">
      <div className="container mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-4xl md:text-5xl font-bold mb-4 text-white font-playfair">
            Our Growing Community
          </h2>
          <p className="text-white/70 text-lg">Real-time stats from our beauty platform</p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          {stats.map((stat, index) => (
            <div key={index} className="text-center group">
              <div className={`w-16 h-16 bg-gradient-to-br ${stat.color} rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300 shadow-lg`}>
                <stat.icon className="text-white" size={24} />
              </div>
              <h3 className="text-3xl md:text-4xl font-bold text-white mb-2 font-playfair">
                {stat.number}
              </h3>
              <p className="text-white/70">
                {stat.label}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// Footer Newsletter Form Component
function FooterNewsletterForm() {
  const toast = useToast();

  const handleSubmit = async (e) => {
    e.preventDefault();
    const email = e.target.email.value;
    if (email) {
      try {
        const response = await fetch('/.netlify/functions/server/api/newsletter/subscribe', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email }),
        });
        const data = await response.json();
        if (response.ok) {
          toast.success('Thank you for subscribing! You will receive our latest beauty content.', 5000);
          e.target.email.value = '';
        } else {
          toast.error(data.message || 'Subscription failed. Please try again.', 4000);
        }
      } catch (error) {
        toast.error('Error subscribing. Please try again.', 4000);
      }
    }
  };

  return (
    <form className="space-y-4" onSubmit={handleSubmit}>
      <input
        type="email"
        name="email"
        placeholder="Enter your email"
        className="w-full px-4 py-3 rounded-xl bg-white/10 backdrop-blur-sm border border-white/20 text-white placeholder-white/60 focus:border-rose-400 focus:outline-none transition-colors"
        required
      />
      <button 
        type="submit"
        className="w-full btn-premium-gradient"
      >
        Subscribe
      </button>
    </form>
  );
}

// Modern Footer
function Footer() {
  return (
    <footer className="relative bg-gradient-to-br from-gray-900 via-rose-900 to-pink-900 text-white overflow-hidden">
      {/* Premium Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute inset-0" style={{
          backgroundImage: `radial-gradient(circle at 25px 25px, rgba(255,255,255,0.1) 2px, transparent 0)`,
          backgroundSize: '50px 50px'
        }}></div>
      </div>

      <div className="container mx-auto px-6 py-20 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12">
          {/* Brand Section */}
          <div className="md:col-span-2">
            <Logo className="mb-8" footer={true} />
            <p className="text-white/80 mb-8 max-w-md leading-relaxed text-lg">
              Your premier destination for luxury beauty insights, expert reviews, and exclusive content from Delhi's finest beauty connoisseur.
            </p>

            {/* Social Links */}
            <div className="flex space-x-4 mb-8">
              <a 
                href="https://www.instagram.com/thee_bareblend?igsh=MXUzMmhnNG04eTNlMA%3D%3D&utm_source=qr"
                target="_blank"
                rel="noopener noreferrer"
                className="p-4 bg-gradient-to-br from-pink-500 to-rose-600 rounded-xl hover:scale-110 transition-transform duration-300 shadow-lg hover:shadow-xl"
              >
                <Instagram size={24} />
              </a>
              <a 
                href="https://youtube.com/@thee_bareblend?si=YZpPX69osBb9p1fK"
                target="_blank"
                rel="noopener noreferrer"
                className="p-4 bg-gradient-to-br from-red-500 to-red-600 rounded-xl hover:scale-110 transition-transform duration-300 shadow-lg hover:shadow-xl"
              >
                <Youtube size={24} />
              </a>
            </div>

            {/* Contact Info */}
            <div className="space-y-4">
              <div className="flex items-center space-x-3 text-white/80">
                <Mail size={20} className="text-rose-400" />
                <span>Help@lushivie.com</span>
              </div>
              <div className="flex items-center space-x-3 text-white/80">
                <Mail size={20} className="text-rose-400" />
                <span>Support@lushivie.com</span>
              </div>
              <div className="flex items-center space-x-3 text-white/80">
                <MapPin size={20} className="text-rose-400" />
                <span>Lajpat Nagar, New Delhi, Delhi 110024</span>
              </div>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-2xl font-bold mb-8 bg-gradient-to-r from-rose-400 to-pink-400 bg-clip-text text-transparent font-playfair">Quick Links</h3>
            <div className="space-y-4">
              <a href="/" className="block text-white/70 hover:text-white hover:translate-x-2 transition-all duration-300 font-medium">Home</a>
              <a href="/about" className="block text-white/70 hover:text-white hover:translate-x-2 transition-all duration-300 font-medium">About</a>
              <a href="/contact" className="block text-white/70 hover:text-white hover:translate-x-2 transition-all duration-300 font-medium">Contact</a>
              <a href="/privacy-policy" className="block text-white/70 hover:text-white hover:translate-x-2 transition-all duration-300 font-medium">Privacy Policy</a>
              <a href="/terms" className="block text-white/70 hover:text-white hover:translate-x-2 transition-all duration-300 font-medium">Terms</a>
            </div>
          </div>

          {/* Newsletter */}
          <div>
            <h3 className="text-2xl font-bold mb-8 bg-gradient-to-r from-rose-400 to-pink-400 bg-clip-text text-transparent font-playfair">Stay Updated</h3>
            <p className="text-white/80 mb-6">Get exclusive beauty tips and offers!</p>
            <FooterNewsletterForm />
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-16 pt-8 border-t border-white/20">
          <div className="flex flex-col items-center space-y-6">
            {/* Links Section */}
            <div className="flex items-center space-x-8">
              <a href="/privacy-policy" className="text-white hover:text-rose-300 transition-colors font-medium text-lg">Privacy</a>
              <a href="/terms" className="text-white hover:text-rose-300 transition-colors font-medium text-lg">Terms</a>
              <a href="/contact" className="text-white hover:text-rose-300 transition-colors font-medium text-lg">Support</a>
            </div>

            {/* Copyright Section - Centered and Stylish */}
            <div className="text-center">
              <div className="bg-gradient-to-r from-white/10 to-white/5 backdrop-blur-sm rounded-2xl px-8 py-4 border border-white/20">
                <p className="text-white font-bold text-lg mb-2 bg-gradient-to-r from-rose-200 via-pink-200 to-orange-200 bg-clip-text text-transparent">
                  © 2025 Lushivie
                </p>
                <p className="text-white/90 text-sm leading-relaxed">
                  A premium creation crafted with <span className="text-rose-300 animate-pulse">❤️</span> by <span className="font-bold text-rose-200">Maanya Arora</span>
                </p>
                <p className="text-white/80 text-xs mt-1">
                  For beauty dreamers, makeup lovers, and glow enthusiasts worldwide • All rights reserved
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}

function HomePage() {
  const [selectedPost, setSelectedPost] = useState(null);
  const [postModalOpen, setPostModalOpen] = useState(false);
  const [authorProfileModalOpen, setAuthorProfileModalOpen] = useState(false);
  const [authorProfileModalData, setAuthorProfileModalData] = useState(null);
  const [adConfig, setAdConfig] = useState({});
  const [savedPostsModalOpen, setSavedPostsModalOpen] = useState(false);
  const [shareModalOpen, setShareModalOpen] = useState(false);
  const [shareModalPost, setShareModalPost] = useState(null);
  const [personalizationModalOpen, setPersonalizationModalOpen] = useState(false);
  const [authModalOpen, setAuthModalOpen] = useState(false); // State for Auth Modal
  const [profileModalOpen, setProfileModalOpen] = useState(false); // State for Profile Modal
  const [filteredPosts, setFilteredPosts] = useState([]); // State for filtered posts
  const [commentsCount, setCommentsCount] = useState({}); // State for comments count

  const queryClient = useQueryClient();

  // Use the persistent storage for saved posts
  const [savedPosts, setSavedPosts] = useState(() => getPersistentSavedPosts());

  // Handle navbar actions
  const handleNavbarAction = (action, data) => {
    if (action === 'showPost') {
      handlePostClick(data);
    } else if (action === 'personalization') {
      setPersonalizationModalOpen(true);
    } else if (action === 'auth') {
      setAuthModalOpen(true);
    } else if (action === 'profile') {
      setProfileModalOpen(true);
    } else if (action === 'savedPosts') {
      setSavedPostsModalOpen(true);
    }
  };

  // Track page view on component mount
  useEffect(() => {
    trackPageView('/', 'Home');
    personalizationManager.startTimeTracking('/');

    return () => {
      personalizationManager.endTimeTracking();
    };
  }, []);

  useEffect(() => {
    // Load AdSense configuration
    const savedConfig = localStorage.getItem('lushivie-adsense-config');
    if (savedConfig) {
      setAdConfig(JSON.parse(savedConfig));
    }
  }, []);

  const { data: posts = [], isLoading, error } = useQuery({
    queryKey: ["posts"],
    queryFn: async () => {
      const response = await fetch("/.netlify/functions/server/api/posts");
      if (!response.ok) {
        throw new Error("Network response was not ok");
      }
      return response.json();
    }
  });

  // Initialize filtered posts when posts data changes
  useEffect(() => {
    setFilteredPosts(posts);
  }, [posts]);

  const handleFilteredPosts = (filtered) => {
    setFilteredPosts(filtered);
  };

  const { user } = useAuth();
  const toast = useToast();

  const handlePostClick = (post) => {
    setSelectedPost(post);
    setPostModalOpen(true);

    // Track post view when opened
    try {
      fetch('/.netlify/functions/server/api/posts/' + post.id + '/views', {
        method: 'POST',
      });
    } catch (error) {
      console.error('Error tracking view:', error);
    }
  };

  const closePostModal = () => {
    setPostModalOpen(false);
    setSelectedPost(null);
  };

  const handleSavePost = async (post) => {
    // Ensure savedPosts is always an array
    const currentSavedPosts = Array.isArray(savedPosts) ? savedPosts : [];
    const isCurrentlySaved = currentSavedPosts.includes(post.id);
    const action = isCurrentlySaved ? 'unsave' : 'save';

    try {
      // Get user profile data for permanent storage
      const userProfile = user ? {
        uid: user.uid,
        email: user.email,
        displayName: user.displayName,
        photoURL: user.photoURL
      } : null;

      // Call backend API to track save/unsave
      const response = await fetch('/.netlify/functions/server/api/posts/' + post.id + '/save', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ 
          userId: user?.uid || 'anonymous',
          userEmail: user?.email || null,
          userProfile: userProfile,
          action: action
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to save post');
      }

      let newSavedPosts;
      if (action === 'unsave') {
        newSavedPosts = currentSavedPosts.filter(id => id !== post.id);
        toast.success('Post removed from saved items');
      } else {
        newSavedPosts = [...currentSavedPosts, post.id];
        toast.success('Post saved successfully!');
      }

      setSavedPosts(newSavedPosts);

      // Save with user profile data in localStorage
      const savedPostsData = {
        postIds: newSavedPosts,
        userProfile: userProfile,
        lastUpdated: Date.now()
      };
      savePersistentSavedPosts(savedPostsData);

      // Dispatch custom event for real-time updates across components
      window.dispatchEvent(new CustomEvent('savedPostsUpdated'));

      // Invalidate queries to refresh stats
      queryClient.invalidateQueries(["post-stats", post.id]);
    } catch (error) {
      console.error('Error saving post:', error);
      toast.error('Failed to save post. Please try again.');
    }
  };

  const handleSharePost = async (post, platform = 'manual') => {
    try {
      // Call backend API to track share
      await fetch('/.netlify/functions/server/api/posts/' + post.id + '/share', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ platform }),
      });

      // Invalidate queries to refresh stats
      queryClient.invalidateQueries(["post-stats", post.id]);
    } catch (error) {
      console.error('Error tracking share:', error);
    }

    setShareModalPost(post);
    setShareModalOpen(true);
  };

  const handleAuthorClick = (post) => {
    // Default profile data for Maanya Arora (always visible to all users)
    let authorData = {
      name: 'Maanya Arora',
      image: 'https://i.ibb.co/zH5KTH4n/IMG-20250811-194616-255.jpg',
      bio: 'Beauty Expert & Content Creator at Lushivie',
      expertise: ['Skincare', 'Makeup', 'Luxury Beauty', 'Product Reviews'],
      location: 'Delhi, India',
      posts: posts.filter(p => p.author === post.author).length,
      social: {
        instagram: 'https://www.instagram.com/thee_bareblend',
        youtube: 'https://youtube.com/@thee_bareblend'
      }
    };

    // If this is Maanya Arora's post, show updated profile data to everyone
    if (post.author === 'Maanya Arora') {
      try {
        // First try general profile storage (latest admin profile)
        const savedProfile = localStorage.getItem('lushivie-user-profile');
        if (savedProfile) {
          const profile = JSON.parse(savedProfile);
          if (profile.isOwner) {
            authorData = {
              ...authorData,
              name: profile.displayName || authorData.name,
              image: profile.profileImage || authorData.image,
              bio: profile.bio || authorData.bio,
              location: profile.location || authorData.location,
              website: profile.website || authorData.website
            };
          }
        }
      } catch (error) {
        console.error('Error loading author profile:', error);
      }
    }

    setAuthorProfileModalData(authorData);
    setAuthorProfileModalOpen(true);
  };



  // Removed review management code - this belongs in AdminPage only

  return (
    <div>
      <SEOHead 
        title="Luxury Beauty Blog - Expert Reviews & Tips"
        description="Discover the latest luxury beauty products, expert makeup tutorials, skincare routines and honest reviews from Delhi's finest beauty connoisseur."
        keywords="luxury beauty, beauty blog, makeup reviews, skincare tips, Delhi beauty blogger, Maanya Arora, beauty expert"
      />

      <HeroSection />

      {/* Search Section - Below Hero Stats */}
      <section className="py-12 bg-gradient-to-br from-rose-50 via-pink-50 to-orange-50 dark:from-rose-950/10 dark:via-pink-950/10 dark:to-orange-950/10">
        <div className="container mx-auto px-6">
          <div className="max-w-2xl mx-auto text-center mb-8">
            <h2 className="text-3xl font-bold mb-4 bg-gradient-to-r from-rose-500 to-pink-600 bg-clip-text text-transparent font-playfair">
              Find Your Perfect Beauty Content
            </h2>
            <p className="text-gray-600 dark:text-gray-300 mb-6">
              Search through our collection of beauty tips, product reviews, and expert advice
            </p>
          </div>
          <SearchPosts 
            posts={posts} 
            onFilteredPosts={handleFilteredPosts}
            className="max-w-2xl mx-auto"
          />
        </div>
      </section>

      {/* Header Ad - Only on desktop, below hero */}
      {adConfig.enabled && adConfig.headerAdSlot && (
        <section className="hidden md:block bg-gray-50 dark:bg-gray-900/50 py-8">
          <div className="container mx-auto px-6">
            <AdSenseAd 
              slot={adConfig.headerAdSlot} 
              placement="header"
              className="w-full max-w-4xl mx-auto"
            />
          </div>
        </section>
      )}

      <FeaturedSection 
        onPostClick={handlePostClick} 
        onAuthorClick={handleAuthorClick} 
        posts={filteredPosts.length > 0 ? filteredPosts : posts}
        onSave={handleSavePost}
        onShare={handleSharePost}
        commentsCount={commentsCount}
      />

      {/* Between Posts Ad - Appears after featured section */}
      {adConfig.enabled && adConfig.betweenPostsAdSlot && posts.length > 3 && (
        <section className="py-8 bg-white dark:bg-gray-900">
          <div className="container mx-auto px-6">
            <AdSenseAd 
              slot={adConfig.betweenPostsAdSlot} 
              placement="between-posts"
              className="w-full max-w-4xl mx-auto"
            />
          </div>
        </section>
      )}

      <ReviewSystem />
      <Newsletter />

      {/* Above Footer Ad */}
      {adConfig.enabled && adConfig.footerAdSlot && (
        <section className="bg-gray-50 dark:bg-gray-900/50 py-8">
          <div className="container mx-auto px-6">
            <AdSenseAd 
              slot={adConfig.footerAdSlot} 
              placement="footer"
              className="w-full max-w-4xl mx-auto"
            />
          </div>
        </section>
      )}

      <AuthorProfileModal 
        author={authorProfileModalData}
        isOpen={authorProfileModalOpen}
        onClose={() => setAuthorProfileModalOpen(false)}
      />

      <PostModal 
        post={selectedPost} 
        isOpen={postModalOpen} 
        onClose={closePostModal} 
      />

      <ShareModal 
        post={shareModalPost}
        isOpen={shareModalOpen}
        onClose={() => setShareModalOpen(false)}
      />

      <SavedPostsModal 
        posts={posts} // Pass all posts to filter saved ones inside the modal
        isOpen={savedPostsModalOpen}
        onClose={() => setSavedPostsModalOpen(false)}
        onPostClick={(post) => {
          console.log('HomePage SavedPostsModal onPostClick called with:', post);
          setSavedPostsModalOpen(false); // Close saved posts modal first
          // Open PostModal directly
          setSelectedPost(post);
          setPostModalOpen(true);
          // Track post view when opened
          try {
            fetch('/.netlify/functions/server/api/posts/' + post.id + '/views', {
              method: 'POST',
            });
          } catch (error) {
            console.error('Error tracking view:', error);
          }
        }}
        onRemovePost={async (postId) => {
          console.log('HomePage handleRemoveSavedPost called for postId:', postId);

          try {
            // Update savedPosts state immediately
            setSavedPosts(currentSavedPosts => {
              const newSavedPosts = currentSavedPosts.filter(id => id !== postId);
              console.log('Updated savedPosts from', currentSavedPosts, 'to', newSavedPosts);

              // Update localStorage with persistent format
              const savedPostsData = {
                postIds: newSavedPosts,
                userProfile: user ? {
                  uid: user.uid,
                  email: user.email,
                  displayName: user.displayName,
                  photoURL: user.photoURL
                } : null,
                lastUpdated: Date.now()
              };

              savePersistentSavedPosts(savedPostsData);

              // Dispatch custom event for real-time updates across components
              window.dispatchEvent(new CustomEvent('savedPostsUpdated'));

              return newSavedPosts;
            });

            // Call backend API to unsave the post
            if (user) {
              const response = await fetch('/.netlify/functions/server/api/posts/' + postId + '/save', {
                method: 'POST',
                headers: {
                  'Content-Type': 'application/json',
                },
                body: JSON.stringify({ 
                  userId: user.uid,
                  userEmail: user.email,
                  action: 'unsave'
                }),
              });

              if (response.ok) {
                toast.success('Post removed from saved items');
              }
            }
          } catch (error) {
            console.error('Error removing saved post:', error);
            toast.error('Failed to remove post from saved items');
          }
        }}
      />

      <PersonalizationSettings
        isOpen={personalizationModalOpen}
        onClose={() => setPersonalizationModalOpen(false)}
      />
    </div>
  );
}

// Enhanced Post Page
function PostPage({ params }) {
  const { data: post, isLoading, error } = useQuery({
    queryKey: ["post", params.slug],
    queryFn: async () => {
      const response = await fetch('/.netlify/functions/server/api/posts/' + params.slug);
      if (!response.ok) {
        if (response.status === 404) {
          throw new Error("Post not found");
        }
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      return response.json();
    }
  });

  const [authorProfileModalOpen, setAuthorProfileModalOpen] = useState(false);
  const [authorProfileModalData, setAuthorProfileModalData] = useState(null);
  const [shareModalOpen, setShareModalOpen] = useState(false);
  const [shareModalPost, setShareModalPost] = useState(null);
  const [commentsCount, setCommentsCount] = useState(0); // State for comments count

  const handleAuthorClick = (authorData) => {
    setAuthorProfileModalData(authorData);
    setAuthorProfileModalOpen(true);
  };

  // Fetch comments count for the specific post
  useEffect(() => {
    if (post && post.id) {
      const fetchCommentCount = async () => {
        try {
          const response = await fetch('/.netlify/functions/server/api/posts/' + post.id + '/comments');
          const commentsData = await response.json();
          setCommentsCount(commentsData.length);
        } catch (error) {
          console.error('Error fetching comments for post ' + post.id + ':', error);
          setCommentsCount(0);
        }
      };
      fetchCommentCount();
    }
  }, [post]);


  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-rose-600"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="container mx-auto px-6 py-32 text-center">
        <h1 className="text-4xl font-bold mb-4 text-red-600">{error.message}</h1>
        <p className="text-medium mb-8">We couldn't find the post you were looking for.</p>
        <a href="/" className="btn-primary">Back to Home</a>
      </div>
    );
  }

  if (!post) {
    return (
      <div className="container mx-auto px-6 py-32 text-center">
        <h1 className="text-4xl font-bold mb-4">Post Not Found</h1>
        <p className="text-medium mb-8">The post you're looking for doesn't exist.</p>
        <a href="/" className="btn-primary">Back to Home</a>
      </div>
    );
  }

  return (
    <article className="pt-24 pb-16">
      <SEOHead 
        title={post.title}
        description={post.description || post.excerpt || "Read " + post.title + " by " + post.author + " on Lushivie - your premier beauty blog."}
        keywords={`${post.title}, beauty blog, ${post.author}, makeup, skincare, luxury beauty`}
        image={post.featuredImage}
        type="article"
        publishedTime={post.publishedAt}
        author={post.author}
      />
      <div className="container mx-auto px-6">
        <div className="max-w-4xl mx-auto">
          {post.featuredImage && (
            <div className="aspect-video mb-12 rounded-2xl overflow-hidden luxury-shadow-lg border-2 border-rose-200/50">
              <img
                src={post.featuredImage}
                alt={post.title}
                className="w-full h-full object-cover"
              />
            </div>
          )}

          <div className="mb-8">
            <h1 className="text-5xl md:text-7xl font-black mb-6 bg-gradient-to-r from-rose-600 via-pink-600 to-orange-500 bg-clip-text text-transparent font-playfair leading-tight">
              {post.title}
            </h1>

            <div className="flex flex-wrap items-center gap-6 text-lg font-medium text-gray-600 dark:text-gray-300">
              <div className="flex items-center space-x-2">
                <Calendar size={18} className="text-rose-500"/>
                <span>{new Date(post.publishedAt).toLocaleDateString()}</span>
              </div>
              <div className="flex items-center space-x-2">
                <User size={18} className="text-rose-500"/>
                <span>{post.author}</span>
              </div>
              <div className="flex items-center space-x-2">
                <Clock size={18} className="text-rose-500"/>
                <span>5 min read</span>
              </div>
            </div>
          </div>

          <div 
            className="prose prose-lg dark:prose-invert max-w-none font-playfair text-gray-800 dark:text-gray-200 leading-relaxed"
            dangerouslySetInnerHTML={{ __html: post.content }}
          />

          <CommentsSection postId={post.id} />
          <PollQuizSection postId={post.id} postTitle={post.title} />
        </div>
      </div>
      <AuthorProfileModal 
        author={authorProfileModalData}
        isOpen={authorProfileModalOpen}
        onClose={() => setAuthorProfileModalOpen(false)}
      />
    </article>
  );
}

// About Page
function AboutPage() {
  return (
    <div className="pt-24 pb-16 bg-gradient-to-br from-rose-50 via-pink-50 to-orange-50 dark:from-rose-950/10 dark:via-pink-950/10 dark:to-orange-950/10">
      <div className="container mx-auto px-6">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-16">
            <h1 className="text-6xl md:text-8xl font-black mb-8 bg-gradient-to-r from-rose-600 via-pink-600 to-orange-500 bg-clip-text text-transparent font-playfair">
              About Lushivie
            </h1>
            <p className="text-xl md:text-2xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
              Your premier destination for luxury beauty insights and expert reviews by Maanya Arora
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center mb-20">
            <div>
              <h2 className="text-4xl font-bold mb-6 bg-gradient-to-r from-rose-500 to-pink-600 bg-clip-text text-transparent font-playfair">Our Mission</h2>
              <p className="text-lg text-gray-700 dark:text-gray-300 leading-relaxed mb-6">
                At Lushivie, we believe beauty is personal and unique to each individual. Founded by <strong>Maanya Arora</strong> in Delhi, India, our mission is to 
                provide honest reviews, expert tutorials, and inclusive content that helps you discover 
                your perfect beauty routine.
              </p>
              <p className="text-lg text-gray-700 dark:text-gray-300 leading-relaxed mb-6">
                We're passionate about bringing you authentic, comprehensive beauty content that celebrates diversity and empowers confidence. 
                Our comprehensive reviews cover everything from high-end luxury brands to accessible drugstore finds, ensuring that beauty is accessible to everyone regardless of budget.
              </p>
              <p className="text-lg text-gray-700 dark:text-gray-300 leading-relaxed mb-6">
                <strong>Our Expertise:</strong> With years of experience in the beauty industry, Maanya brings professional insights into skincare science, makeup artistry, and product formulation. We test every product thoroughly, considering factors like skin type compatibility, ingredient safety, longevity, and value for money.
              </p>
              <p className="text-lg text-gray-700 dark:text-gray-300 leading-relaxed mb-6">
                <strong>Community Focus:</strong> Lushivie isn't just a blog—it's a community where beauty enthusiasts can learn, share, and grow together. We respond to every comment and email because your beauty journey matters to us.
              </p>
              <div className="bg-gradient-to-r from-rose-500/10 to-pink-500/10 p-6 rounded-2xl border border-rose-200/50">
                <h3 className="text-xl font-bold mb-3 text-rose-600">Contact Information:</h3>
                <p className="text-gray-700 dark:text-gray-300 mb-2"><strong>General Inquiries:</strong> Help@lushivie.com</p>
                <p className="text-gray-700 dark:text-gray-300 mb-2"><strong>Support:</strong> Support@lushivie.com</p>
                <p className="text-gray-700 dark:text-gray-300 mb-2"><strong>Business Partnerships:</strong> Glamour.bymaanya@gmail.com</p>
                <p className="text-gray-700 dark:text-gray-300 mb-2"><strong>Location:</strong> Lajpat Nagar, New Delhi, Delhi 110024</p>
                <p className="text-gray-700 dark:text-gray-300"><strong>Response Time:</strong> Within 24 hours</p>
              </div>
            </div>
            <div className="relative">
              <div className="aspect-square rounded-3xl overflow-hidden shadow-xl border-2 border-rose-200/50">
                <img
                  src="https://images.unsplash.com/photo-1570194065650-d99fb45d7679?w=600&h=600&fit=crop"
                  alt="Beauty products"
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-10 mb-16">
            <div className="text-center p-8 bg-white dark:bg-gray-900 rounded-3xl shadow-xl border border-gray-100 dark:border-gray-800">
              <div className="w-16 h-16 bg-gradient-to-br from-rose-500 to-pink-600 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg">
                <Star className="text-white" size={24} />
              </div>
              <h3 className="text-2xl font-bold mb-4 font-playfair">Expert Reviews</h3>
              <p className="text-gray-600 dark:text-gray-300">In-depth product analysis and honest recommendations from Maanya</p>
            </div>

            <div className="text-center p-8 bg-white dark:bg-gray-900 rounded-3xl shadow-xl border border-gray-100 dark:border-gray-800">
              <div className="w-16 h-16 bg-gradient-to-br from-rose-500 to-pink-600 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg">
                <Heart className="text-white" size={24} />
              </div>
              <h3 className="text-2xl font-bold mb-4 font-playfair">Inclusive Content</h3>
              <p className="text-gray-600 dark:text-gray-300">Beauty advice for all skin tones and types</p>
            </div>

            <div className="text-center p-8 bg-white dark:bg-gray-900 rounded-3xl shadow-xl border border-gray-100 dark:border-gray-800">
              <div className="w-16 h-16 bg-gradient-to-br from-rose-500 to-pink-600 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg">
                <TrendingUp className="text-white" size={24} />
              </div>
              <h3 className="text-2xl font-bold mb-4 font-playfair">Latest Trends</h3>
              <p className="text-gray-600 dark:text-gray-300">Stay ahead with cutting-edge beauty innovations</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// Category Pages
function CategoryPage({ params }) {
  const categoryNames = {
    skincare: 'Skincare',
    makeup: 'Makeup', 
    luxury: 'Luxury'
  };

  const categoryName = categoryNames[params.category] || 'Beauty';

  // Sample category posts
  const categoryPosts = [
    {
      id: "cat-1",
      title: `Best ${categoryName} Products of 2025`,
      slug: `best-${params.category}-products-2025`,
      excerpt: `Discover Maanya's top picks for ${categoryName.toLowerCase()} that will transform your beauty routine.`,
      author: "Maanya Arora",
      publishedAt: new Date().toISOString(),
      featuredImage: `https://images.unsplash.com/photo-${params.category === 'skincare' ? '1570194065650-d99fb45d7679' : params.category === 'makeup' ? '1586495777744-4413f21062fa' : '1570194065650-d99fb45d7679'}?w=600&h=400&fit=crop`
    },
    {
      id: "cat-2", 
      title: `${categoryName} Tips for Beginners`,
      slug: `${params.category}-tips-beginners`,
      excerpt: `Learn the fundamentals of ${categoryName.toLowerCase()} with expert guidance from Maanya.`,
      author: "Maanya Arora",
      publishedAt: new Date().toISOString(),
      featuredImage: `https://images.unsplash.com/photo-${params.category === 'skincare' ? '1612198761169-8d7c9a13b7c2' : params.category === 'makeup' ? '1596755389378-c31d21fd1273' : '1570194065650-d99fb45d7679'}?w=600&h=400&fit=crop`
    }
  ];

  return (
    <div className="pt-24 pb-16 bg-gradient-to-br from-rose-50 via-pink-50 to-orange-50 dark:from-rose-950/10 dark:via-pink-950/10 dark:to-orange-950/10">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h1 className="text-6xl md:text-8xl font-black mb-8 bg-gradient-to-r from-rose-600 via-pink-600 to-orange-500 bg-clip-text text-transparent font-playfair">
            {categoryName}
          </h1>
          <p className="text-xl md:text-2xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            Discover the best {categoryName.toLowerCase()} products and tips curated by Maanya Arora
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {categoryPosts.map((post) => (
            <PostCard key={post.id} post={post} />
          ))}
        </div>

        <div className="text-center py-12 bg-white dark:bg-gray-900 rounded-3xl shadow-xl border border-gray-100 dark:border-gray-800">
          <div className="w-24 h-24 bg-gradient-to-br from-rose-100 to-pink-100 rounded-full flex items-center justify-center mx-auto mb-6 shadow-lg">
            <Sparkles className="text-rose-600" size={32} />
          </div>
          <h3 className="text-3xl font-bold mb-4 text-gray-800 dark:text-white font-playfair">More Content Coming Soon!</h3>
          <p className="text-gray-600 dark:text-gray-300 mb-8">
            We're curating more amazing {categoryName.toLowerCase()} content for you. Subscribe to our newsletter to stay updated!
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a href="/" className="btn-premium-gradient">Back to Home</a>
            <a href="#newsletter" className="btn-premium-outline">Subscribe to Newsletter</a>
          </div>
        </div>
      </div>
    </div>
  );
}

// Privacy Policy Page
function PrivacyPolicyPage() {
  return (
    <div className="pt-24 pb-16 bg-gradient-to-br from-rose-50 via-pink-50 to-orange-50 dark:from-rose-950/10 dark:via-pink-950/10 dark:to-orange-950/10">
      <div className="container mx-auto px-6">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-6xl md:text-8xl font-black mb-8 bg-gradient-to-r from-rose-600 via-pink-600 to-orange-500 bg-clip-text text-transparent font-playfair text-center">
            Privacy Policy
          </h1>

          <div className="bg-white dark:bg-gray-900 rounded-3xl p-8 shadow-xl border border-gray-100 dark:border-gray-800">
            <div className="prose prose-lg dark:prose-invert max-w-none">
              <p className="text-sm text-gray-500 mb-8">Last updated: January 2025</p>

              <h2>Information We Collect</h2>
              <p>At Lushivie, we collect information you provide directly to us, such as when you subscribe to our newsletter, contact us, or interact with our content. This includes:</p>
              <ul>
                <li><strong>Personal Information:</strong> Name, email address, and any information you provide in contact forms</li>
                <li><strong>Usage Data:</strong> Information about how you use our website, pages visited, and time spent</li>
                <li><strong>Technical Data:</strong> IP address, browser type, device information, and cookies</li>
                <li><strong>Communication Data:</strong> Records of your communications with us</li>
              </ul>

              <h2>How We Use Your Information</h2>
              <ul>
                <li>To send you our newsletter and exclusive beauty tips</li>
                <li>To respond to your inquiries and provide customer support via Help@lushivie.com</li>
                <li>To improve our website and services based on user feedback</li>
                <li>To personalize your experience and recommend relevant content</li>
                <li>To analyze website traffic and user behavior for optimization</li>
                <li>To comply with legal obligations and protect our rights</li>
              </ul>

              <h2>Information Sharing</h2>
              <p>We do not sell, trade, or otherwise transfer your personal information to third parties without your consent, except as described in this policy. We may share information with:</p>
              <ul>
                <li>Service providers who assist in operating our website</li>
                <li>Legal authorities when required by law</li>
                <li>Business partners for joint marketing efforts (with your consent)</li>
              </ul>

              <h2>Data Security</h2>
              <p>We implement appropriate security measures to protect your personal information against unauthorized access, alteration, disclosure, or destruction. This includes:</p>
              <ul>
                <li>SSL encryption for data transmission</li>
                <li>Secure servers and databases</li>
                <li>Regular security audits and updates</li>
                <li>Limited access to personal data on a need-to-know basis</li>
              </ul>

              <h2>Your Rights</h2>
              <p>You have the right to:</p>
              <ul>
                <li>Access your personal data</li>
                <li>Correct inaccurate information</li>
                <li>Request deletion of your data</li>
                <li>Unsubscribe from our newsletter at any time</li>
                <li>Object to data processing</li>
              </ul>

              <h2>Cookies Policy</h2>
              <p>We use cookies to enhance your browsing experience, analyze site traffic, and personalize content. You can control cookie settings through your browser.</p>

              <h2>Data Retention</h2>
              <p>We retain your personal information only for as long as necessary to fulfill the purposes outlined in this policy or as required by law.</p>

              <h2>Contact Us</h2>
              <p>If you have any questions about this Privacy Policy, please contact us at:</p>
              <ul>
                <li>General Inquiries: Help@lushivie.com</li>
                <li>Support: Support@lushivie.com</li>
                <li>Business Email: Glamour.bymaanya@gmail.com</li>
                <li>Location: Lajpat Nagar, New Delhi, Delhi 110024</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// Terms of Service Page
function TermsPage() {
  return (
    <div className="pt-24 pb-16 bg-gradient-to-br from-rose-50 via-pink-50 to-orange-50 dark:from-rose-950/10 dark:via-pink-950/10 dark:to-orange-950/10">
      <div className="container mx-auto px-6">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-6xl md:text-8xl font-black mb-8 bg-gradient-to-r from-rose-600 via-pink-600 to-orange-500 bg-clip-text text-transparent font-playfair text-center">
            Terms of Service
          </h1>

          <div className="bg-white dark:bg-gray-900 rounded-3xl p-8 shadow-xl border border-gray-100 dark:border-gray-800">
            <div className="prose prose-lg dark:prose-invert max-w-none">
              <p className="text-sm text-gray-500 mb-8">Last updated: January 2025</p>

              <h2>Acceptance of Terms</h2>
              <p>By accessing and using Lushivie, you accept and agree to be bound by the terms and provision of this agreement. If you do not agree to these terms, please do not use our website.</p>

              <h2>Use License</h2>
              <p>Permission is granted to temporarily view the materials on Lushivie's website for personal, non-commercial transitory viewing only. This is the grant of a license, not a transfer of title. Under this license you may not:</p>
              <ul>
                <li>Modify or copy the materials</li>
                <li>Use the materials for commercial purposes</li>
                <li>Remove any copyright or proprietary notations</li>
                <li>Transfer the materials to another person</li>
              </ul>

              <h2>User Account Responsibilities</h2>
              <p>When creating an account or interacting with our site, you agree to:</p>
              <ul>
                <li>Provide accurate and complete information</li>
                <li>Maintain the security of your account</li>
                <li>Notify us immediately of any unauthorized use</li>
                <li>Be responsible for all activities under your account</li>
              </ul>

              <h2>Disclaimer</h2>
              <p>The materials on Lushivie's website are provided on an 'as is' basis. Lushivie makes no warranties, expressed or implied, and hereby disclaims all other warranties including any implied warranties of merchantability, fitness for a particular purpose, or non-infringement.</p>

              <h2>Limitations</h2>
              <p>In no event shall Lushivie, Maanya Arora, or its suppliers be liable for any damages (including, without limitation, damages for loss of data or profit, or due to business interruption) arising out of the use or inability to use the materials on Lushivie's website, even if Lushivie has been notified of the possibility of such damage.</p>

              <h2>Content Guidelines</h2>
              <ul>
                <li>All reviews and recommendations are based on personal experience and research</li>
                <li>Individual results may vary based on skin type and personal factors</li>
                <li>Always patch test new products before full application</li>
                <li>Consult with dermatologists or professionals for specific skin concerns</li>
                <li>Product recommendations do not constitute medical advice</li>
                <li>We are not responsible for allergic reactions or adverse effects</li>
              </ul>

              <h2>Intellectual Property</h2>
              <p>All content on Lushivie, including text, graphics, logos, images, and software, is the property of Lushivie and Maanya Arora and is protected by copyright and intellectual property laws.</p>

              <h2>User-Generated Content</h2>
              <p>By submitting content to our website (comments, reviews, etc.), you grant us a non-exclusive, royalty-free license to use, modify, and display such content.</p>

              <h2>Prohibited Uses</h2>
              <p>You may not use our site:</p>
              <ul>
                <li>For any unlawful purpose</li>
                <li>To spam or harass other users</li>
                <li>To distribute malware or harmful content</li>
                <li>To infringe on intellectual property rights</li>
              </ul>

              <h2>Termination</h2>
              <p>We may terminate or suspend your access to our service at any time, without notice, for conduct that we believe violates these Terms of Service.</p>

              <h2>Governing Law</h2>
              <p>These terms are governed by the laws of India, and any disputes will be resolved in the courts of Delhi, India.</p>

              <h2>Contact Information</h2>
              <p>For questions regarding these terms, please contact:</p>
              <ul>
                <li>General Inquiries: Help@lushivie.com</li>
                <li>Support: Support@lushivie.com</li>
                <li>Business Email: Glamour.bymaanya@gmail.com</li>
                <li>Creator: Maanya Arora, Lajpat Nagar, New Delhi, Delhi 110024</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// Contact Page
function ContactPage() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: ""
  });
  const [isSubmitted, setIsSubmitted] = useState(false);

  const toast = useToast();

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await fetch('/.netlify/functions/server/api/contact', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || 'Failed to send message');
      }

      setIsSubmitted(true);
      setFormData({ name: "", email: "", message: "" });
      toast.success('Message sent successfully! We\'ll get back to you soon.', 5000);
    } catch (error) {
      toast.error('Failed to send message: ' + error.message, 5000);
    }
  };

  return (
    <div className="pt-24 pb-16 bg-gradient-to-br from-rose-50 via-pink-50 to-orange-50 dark:from-rose-950/10 dark:via-pink-950/10 dark:to-orange-950/10">
      <div className="container mx-auto px-6">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-16">
            <h1 className="text-6xl md:text-8xl font-black mb-8 bg-gradient-to-r from-rose-600 via-pink-600 to-orange-500 bg-clip-text text-transparent font-playfair">
              Get in Touch
            </h1>
            <p className="text-xl md:text-2xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
              Have questions about beauty? Want to collaborate? We'd love to hear from you.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
            <div>
              <h2 className="text-4xl font-bold mb-8 bg-gradient-to-r from-rose-500 to-pink-600 bg-clip-text text-transparent font-playfair">Contact Information</h2>

              <div className="space-y-6">
                <div className="flex items-center space-x-4 p-6 bg-white dark:bg-gray-900 rounded-3xl shadow-xl border border-gray-100 dark:border-gray-800">
                  <div className="w-14 h-14 bg-gradient-to-br from-rose-500 to-pink-600 rounded-xl flex items-center justify-center shadow-lg">
                    <Mail className="text-white" size={24} />
                  </div>
                  <div>
                    <h3 className="font-bold text-xl text-gray-800 dark:text-white mb-1">General Inquiries</h3>
                    <p className="text-gray-600 dark:text-gray-300 font-medium">Help@lushivie.com</p>
                    <p className="text-gray-600 dark:text-gray-300 font-medium">Support@lushivie.com</p>
                  </div>
                </div>

                <div className="flex items-center space-x-4 p-6 bg-white dark:bg-gray-900 rounded-3xl shadow-xl border border-gray-100 dark:border-gray-800">
                  <div className="w-14 h-14 bg-gradient-to-br from-rose-500 to-pink-600 rounded-xl flex items-center justify-center shadow-lg">
                    <MapPin className="text-white" size={24} />
                  </div>
                  <div>
                    <h3 className="font-bold text-xl text-gray-800 dark:text-white mb-1">Location</h3>
                    <p className="text-gray-600 dark:text-gray-300 font-medium">Lajpat Nagar, New Delhi, Delhi 110024</p>
                  </div>
                </div>

                <div className="flex items-center space-x-4 p-6 bg-white dark:bg-gray-900 rounded-3xl shadow-xl border border-gray-100 dark:border-gray-800">
                  <div className="w-14 h-14 bg-gradient-to-br from-rose-500 to-pink-600 rounded-xl flex items-center justify-center shadow-lg">
                    <Clock className="text-white" size={24} />
                  </div>
                  <div>
                    <h3 className="font-bold text-xl text-gray-800 dark:text-white mb-1">Response Time</h3>
                    <p className="text-gray-600 dark:text-gray-300 font-medium">Within 24 hours</p>
                  </div>
                </div>
              </div>
            </div>

            <div>
              {isSubmitted ? (
                <div className="bg-white dark:bg-gray-900 rounded-3xl p-8 shadow-xl border border-green-300 text-center">
                  <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-6 shadow-lg">
                    <Heart className="text-white" size={24} />
                  </div>
                  <h3 className="text-3xl font-bold mb-4 text-gray-800 dark:text-white font-playfair">Message Sent!</h3>
                  <p className="text-gray-600 dark:text-gray-300 text-lg">Thank you for reaching out. We'll get back to you soon.</p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-6 bg-white dark:bg-gray-900 rounded-3xl p-8 shadow-xl border border-gray-100 dark:border-gray-800">
                  <div>
                    <label className="block text-sm font-medium mb-3 text-gray-700 dark:text-gray-300">Full Name</label>
                    <input
                      type="text"
                      value={formData.name}
                      onChange={(e) => setFormData({...formData, name: e.target.value})}
                      className="w-full px-5 py-3 rounded-xl border-2 border-gray-200 dark:border-gray-700 focus:border-rose-500 focus:ring-4 focus:ring-rose-500/20 transition-all duration-300 bg-background dark:bg-gray-800 text-gray-800 dark:text-white placeholder-gray-400"
                      required
                      placeholder="Enter your full name"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-3 text-gray-700 dark:text-gray-300">Email Address</label>
                    <input
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({...formData, email: e.target.value})}
                      className="w-full px-5 py-3 rounded-xl border-2 border-gray-200 dark:border-gray-700 focus:border-rose-500 focus:ring-4 focus:ring-rose-500/20 transition-all duration-300 bg-background dark:bg-gray-800 text-gray-800 dark:text-white placeholder-gray-400"
                      required
                      placeholder="Enter your email address"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-3 text-gray-700 dark:text-gray-300">Message</label>
                    <textarea
                      value={formData.message}
                      onChange={(e) => setFormData({...formData, message: e.target.value})}
                      rows={6}
                      className="w-full px-5 py-3 rounded-xl border-2 border-gray-200 dark:border-gray-700 focus:border-rose-500 focus:ring-4 focus:ring-rose-500/20 transition-all duration-300 bg-background dark:bg-gray-800 text-gray-800 dark:text-white placeholder-gray-400 resize-none"
                      required
                      placeholder="Your message here..."
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full btn-premium-gradient py-3 shadow-lg shadow-rose-500/25 hover:shadow-2xl hover:shadow-rose-500/40 transform hover:scale-105 transition-all duration-300"
                  >
                    Send Message
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// Enhanced Admin Page
function AdminPage() {
  const { user, isOwner } = useAuth();
  const toast = useToast();
  const [posts, setPosts] = useState([]);
  const [editingPost, setEditingPost] = useState(null);
  const [activeTab, setActiveTab] = useState('posts'); // 'posts', 'subscribers', 'reviews', or 'adsense'

  const [adSenseConfig, setAdSenseConfig] = useState({
    clientId: '',
    headerAdSlot: '',
    sidebarAdSlot: '',
    betweenPostsAdSlot: '',
    footerAdSlot: '',
    enabled: false
  });
  const [formData, setFormData] = useState({
    title: "",
    content: "",
    description: "",
    featuredImage: "",
    author: "Maanya Arora",
    isPremium: false
  });
  const [uploadingImage, setUploadingImage] = useState(false);
  const [shareModalOpen, setShareModalOpen] = useState(false);
  const [shareModalPost, setShareModalPost] = useState(null);
  const [commentsCount, setCommentsCount] = useState({}); // State for comments count

  // Redirect if not admin
  if (!user || !isOwner) {
    return (
      <div className="pt-24 pb-16 bg-gradient-to-br from-rose-50 via-pink-50 to-orange-50 dark:from-rose-950/10 dark:via-pink-950/10 dark:to-orange-950/10">
        <div className="container mx-auto px-6">
          <div className="max-w-3xl mx-auto text-center">
            <div className="w-20 h-20 bg-gradient-to-br from-red-100 to-pink-100 rounded-full flex items-center justify-center mx-auto mb-6 shadow-lg">
              <X className="text-red-600" size={32} />
            </div>
            <h1 className="text-5xl font-black mb-4 text-red-600 font-playfair">Access Denied</h1>
            <p className="text-xl text-gray-600 dark:text-gray-300 mb-8">
              {!user 
                ? "Please sign in to access the admin dashboard." 
                : "You don't have admin privileges to access this page."
              }
            </p>
            <a href="/" className="btn-primary">Back to Home</a>
          </div>
        </div>
      </div>
    );
  }

  const { data: postsData = [], isLoading: loadingPosts, error: postsError, refetch: refetchPosts } = useQuery({
    queryKey: ["admin-posts"],
    queryFn: async () => {
      const response = await fetch("/.netlify/functions/server/api/posts");
      if (!response.ok) {
        throw new Error("Failed to fetch posts");
      }
      return response.json();
    },
    retry: 2,
    staleTime: 30000
  });

  const { data: subscribersData = { total: 0, subscribers: [] }, isLoading: loadingSubscribers, error: subscribersError, refetch: refetchSubscribers } = useQuery({
    queryKey: ["newsletter-subscribers"],
    queryFn: async () => {
      const response = await fetch("/.netlify/functions/server/api/newsletter/subscribers");
      if (!response.ok) {
        throw new Error("Failed to fetch subscribers");
      }
      return response.json();
    }
  });

  const handleRemoveSubscriber = async (subscriberId, subscriberEmail) => {
    // Show stylish confirmation toast
    toast.confirm(
      `Remove ${subscriberEmail} from newsletter?`,
      async () => {
        try {
          const response = await fetch('/.netlify/functions/server/api/newsletter/subscribers/' + subscriberId, {
            method: 'DELETE'
          });

          if (!response.ok) {
            throw new Error('Failed to remove subscriber');
          }

          toast.success('Subscriber removed successfully!');
          refetchSubscribers();
        } catch (error) {
          console.error('Error removing subscriber:', error);
          toast.error('Failed to remove subscriber: ' + error.message);
        }
      },
      () => {
        // Cancel action - toast will auto-close
      }
    );
  };



  useEffect(() => {
    if (postsData) {
      setPosts(postsData);
      // Store posts in localStorage for story mode access
      localStorage.setItem('lushivie-all-posts', JSON.stringify(postsData));
    }
  }, [postsData]);

  const handleFormChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleImageUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    if (file.size > 32 * 1024 * 1024) {
      toast.warning('Image size should be less than 32MB', 4000);
      return;
    }

    if (!file.type.startsWith('image/')) {
      toast.warning('Please select a valid image file', 4000);
      return;
    }

    setUploadingImage(true);

    try {
      // Import the upload function dynamically
      const { uploadPostImage } = await import('./utils/imageUpload');

      // Upload to ImgBB for post images
      const uploadResult = await uploadPostImage(file);

      if (uploadResult.success && (uploadResult.data || uploadResult.url)) {
        const imageUrl = uploadResult.data?.url || uploadResult.url;
        setFormData(prev => ({ ...prev, featuredImage: imageUrl }));
        toast.success('Image uploaded successfully!', 3000);
      } else {
        throw new Error('Upload failed');
      }
    } catch (error) {
      console.error('Image upload error:', error);
      // Fallback to base64 for preview
      try {
        const reader = new FileReader();
        reader.onload = (event) => {
          const dataUrl = event.target.result;
          setFormData(prev => ({ ...prev, featuredImage: dataUrl }));
          toast.warning('Image loaded as preview. Use a public URL for better performance.', 4000);
        };
        reader.readAsDataURL(file);
      } catch (fallbackError) {
        toast.error('Failed to load image. Please try again.', 4000);
      }
    } finally {
      setUploadingImage(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const url = editingPost ? '/.netlify/functions/server/api/posts/' + editingPost.id : '/.netlify/functions/server/api/posts';
    const method = editingPost ? "PUT" : "POST";

    try {
      // Process content for premium posts
      let processedContent = formData.content;

      if (formData.isPremium) {
        // Wrap entire content in premium markers
        processedContent = '<!-- PREMIUM_START -->\n' + formData.content + '\n<!-- PREMIUM_END -->';
      }

      const postData = {
        title: formData.title,
        content: processedContent,
        excerpt: formData.description || formData.excerpt,
        featuredImage: formData.featuredImage,
        author: formData.author || "Maanya Arora"
      };

      const response = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(postData)
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
      }

      const savedPost = await response.json();

      // Update local state immediately
      if (editingPost) {
        setPosts(prevPosts => prevPosts.map(p => p.id === editingPost.id ? savedPost : p));
      } else {
        setPosts(prevPosts => [savedPost, ...prevPosts]);
      }

      // Reset form
      setFormData({ title: "", content: "", description: "", featuredImage: "", author: "Maanya Arora", isPremium: false });
      setEditingPost(null);

      // Show success message
      toast.success(editingPost ? 'Post updated successfully!' : 'Post created successfully!');

      // Refetch data to ensure consistency
      await refetchPosts();
      queryClient.invalidateQueries(["admin-posts"]);
      queryClient.invalidateQueries(["posts"]);

      const premiumText = formData.isPremium ? 'Premium post' : 'Post';
      toast.success(editingPost ? `${premiumText} updated successfully!` : `${premiumText} created successfully!`, 4000);
    } catch (error) {
      console.error('Error saving post:', error);
      toast.error('Error saving post: ' + error.message, 5000);
    }
  };

  const handleEdit = (post) => {
    setEditingPost(post);

    // Check if content is premium (contains premium markers)
    const isPremium = post.content.includes('<!-- PREMIUM_START -->') && post.content.includes('<!-- PREMIUM_END -->');

    // Remove premium markers from content for editing
    let editableContent = post.content;
    if (isPremium) {
      editableContent = post.content
        .replace(/<!--\s*PREMIUM_START\s*-->\s*/g, '')
        .replace(/\s*<!--\s*PREMIUM_END\s*-->/g, '')
        .trim();
    }

    setFormData({
      title: post.title,
      content: editableContent,
      description: post.excerpt || post.description || "",
      featuredImage: post.featuredImage || "",
      author: post.author,
      isPremium: isPremium
    });
    // Scroll to top of form
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleDelete = async (postId) => {
    // Show stylish confirmation toast
    toast.confirm(
      "Delete this post? This action cannot be undone.",
      async () => {
        try {
          const response = await fetch('/.netlify/functions/server/api/posts/' + postId, { method: "DELETE" });
          if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.message || "Failed to delete post");
          }

          // Update local state immediately
          setPosts(prevPosts => prevPosts.filter(p => p.id !== postId));

          // Refetch data to ensure consistency
          await refetchPosts();
          queryClient.invalidateQueries(["posts"]);

          toast.success('Post deleted successfully!', 4000);
        } catch (error) {
          console.error('Error deleting post:', error);
          toast.error('Error deleting post: ' + error.message, 5000);
        }
      },
      () => {
        // Cancel action - toast will auto-close
      }
    );
  };

  // Fetch comments count for each post in the admin view
  useEffect(() => {
    const fetchCommentsCount = async () => {
      const counts = {};
      for (const post of posts) {
        try {
          const response = await fetch('/.netlify/functions/server/api/posts/' + post.id + '/comments');
          const commentsData = await response.json();
          counts[post.id] = commentsData.length;
        } catch (error) {
          console.error('Error fetching comments for post ' + post.id + ':', error);
          counts[post.id] = 0;
        }
      }
      setCommentsCount(counts);
    };

    if (posts.length > 0) {
      fetchCommentsCount();
    }
  }, [posts]);


  return (
    <div className="pt-24 pb-16 bg-gradient-to-br from-rose-50 via-pink-50 to-orange-50 dark:from-rose-950/10 dark:via-pink-950/10 dark:to-orange-950/10">
      <div className="container mx-auto px-6">
        <div className="mb-12 text-center">
          <h1 className="text-6xl md:text-8xl font-black mb-4 bg-gradient-to-r from-rose-600 via-pink-600 to-orange-500 bg-clip-text text-transparent font-playfair">
            Admin Dashboard
          </h1>
          <p className="text-xl md:text-2xl text-gray-600 dark:text-gray-300">Manage your beauty blog content</p>
        </div>

        {/* Tab Navigation */}
        <div className="flex justify-center mb-12">
          <div className="bg-white dark:bg-gray-900 rounded-2xl p-2 shadow-xl border border-gray-100 dark:border-gray-800 overflow-x-auto">
            <div className="flex space-x-1 min-w-max">
              <button
                onClick={() => setActiveTab('posts')}
                className={`px-4 py-3 rounded-xl font-semibold transition-all duration-300 whitespace-nowrap ${
                  activeTab === 'posts'
                    ? 'bg-gradient-to-r from-rose-500 to-pink-600 text-white shadow-lg'
                    : 'text-gray-600 dark:text-gray-300 hover:text-rose-600'
                }`}
              >
                Posts ({posts.length})
              </button>
              <button
                onClick={() => setActiveTab('reviews')}
                className={`px-4 py-3 rounded-xl font-semibold transition-all duration-300 whitespace-nowrap ${
                  activeTab === 'reviews'
                    ? 'bg-gradient-to-r from-green-500 to-emerald-600 text-white shadow-lg'
                    : 'text-gray-600 dark:text-gray-300 hover:text-green-600'
                }`}
              >
                Reviews
              </button>
              <button
                onClick={() => setActiveTab('subscribers')}
                className={`px-4 py-3 rounded-xl font-semibold transition-all duration-300 whitespace-nowrap flex items-center space-x-2 ${
                  activeTab === 'subscribers'
                    ? 'bg-gradient-to-r from-rose-500 to-pink-600 text-white shadow-lg'
                    : 'text-gray-600 dark:text-gray-300 hover:text-rose-600'
                }`}
              >
                <Mail size={16} />
                <span>Subscribers ({subscribersData.total})</span>
              </button>
              <button
                onClick={() => setActiveTab('adsense')}
                className={`px-4 py-3 rounded-xl font-semibold transition-all duration-300 whitespace-nowrap flex items-center space-x-2 ${
                  activeTab === 'adsense'
                    ? 'bg-gradient-to-r from-rose-500 to-pink-600 text-white shadow-lg'
                    : 'text-gray-600 dark:text-gray-300 hover:text-rose-600'
                }`}
              >
                <TrendingUp size={16} />
                <span>AdSense Setup</span>
              </button>
              <button
                onClick={() => setActiveTab('upi')}
                className={`px-4 py-3 rounded-xl font-semibold transition-all duration-300 whitespace-nowrap flex items-center space-x-2 ${
                  activeTab === 'upi'
                    ? 'bg-gradient-to-r from-green-500 to-emerald-600 text-white shadow-lg'
                    : 'text-gray-600 dark:text-gray-300 hover:text-green-600'
                }`}
              >
                <Gift size={16} />
                <span>UPI/Tip Setup</span>
              </button>
              <button
                onClick={() => setActiveTab('editor')}
                className={`px-4 py-3 rounded-xl font-semibold transition-all duration-300 whitespace-nowrap ${
                  activeTab === 'editor'
                    ? 'bg-gradient-to-r from-blue-500 to-purple-600 text-white shadow-lg'
                    : 'text-gray-600 dark:text-gray-300 hover:text-blue-600'
                }`}
              >
                Code Editor
              </button>
            </div>
          </div>
        </div>

        {activeTab === 'upi' ? (
          /* UPI Configuration Tab */
          <div className="max-w-4xl mx-auto">
            <div className="bg-white dark:bg-gray-900 rounded-3xl p-8 shadow-xl border border-gray-100 dark:border-gray-800">
              <div className="flex items-center justify-between mb-8">
                <h2 className="text-4xl font-bold bg-gradient-to-r from-green-500 to-emerald-600 bg-clip-text text-transparent font-playfair">
                  UPI Configuration
                </h2>
                <div className="flex items-center space-x-3">
                  <span className="px-3 py-1 rounded-full text-sm font-medium bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300">
                    Active
                  </span>
                </div>
              </div>

              <div className="space-y-8">
                <div className="p-6 bg-blue-50 dark:bg-blue-950/20 rounded-xl border border-blue-200 dark:border-blue-800">
                  <h3 className="text-xl font-bold mb-4 text-blue-800 dark:text-blue-300 flex items-center space-x-2">
                    <Zap size={20} className="text-blue-600" />
                    <span>How it Works</span>
                  </h3>
                  <ol className="list-decimal list-inside space-y-2 text-sm text-blue-700 dark:text-blue-300">
                    <li>Set your UPI ID below to receive tips from readers</li>
                    <li>A "Tip the Author" button will appear on all blog posts</li>
                    <li>Readers can scan QR code or copy UPI ID to send tips</li>
                    <li>Tips go directly to your UPI account</li>
                  </ol>
                </div>

                <form className="space-y-6" onSubmit={(e) => {
                  e.preventDefault();
                  const formData = new FormData(e.target);
                  const upiId = formData.get('upiId');

                  const config = {
                    upiId: upiId,
                    enabled: true,
                    lastUpdated: Date.now()
                  };

                  localStorage.setItem('lushivie-upi-config', JSON.stringify(config));
                  toast.success('UPI configuration saved successfully!', 4000);
                }}>
                  <div>
                    <label className="block text-sm font-medium mb-3 text-gray-700 dark:text-gray-300">
                      UPI ID
                    </label>
                    <input
                      type="text"
                      name="upiId"
                      defaultValue="aroramaanya@okhdfcbank"
                      placeholder="your-number@upi-provider"
                      className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 dark:border-gray-700 focus:border-green-500 focus:outline-none transition-colors bg-white dark:bg-gray-800 text-gray-900 dark:text-white font-mono text-sm"
                      required
                    />
                    <p className="text-xs text-gray-500 mt-2">Enter your UPI ID (e.g., 9876543210@paytm, yourname@oksbi)</p>
                  </div>

                  <div className="flex justify-end">
                    <button
                      type="submit"
                      className="px-8 py-3 bg-gradient-to-r from-green-500 to-emerald-600 text-white rounded-xl font-semibold hover:from-green-600 hover:to-emerald-700 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105 flex items-center space-x-2"
                    >
                      <span>Save UPI Configuration</span>
                    </button>
                  </div>
                </form>

                <div className="p-6 bg-yellow-50 dark:bg-yellow-950/20 rounded-xl border border-yellow-200 dark:border-yellow-800">
                  <h3 className="text-lg font-bold mb-4 text-yellow-800 dark:text-yellow-300 flex items-center space-x-2">
                    <Eye size={18} className="text-yellow-600" />
                    <span>Preview</span>
                  </h3>
                  <div className="bg-white dark:bg-gray-800 p-4 rounded-lg border border-gray-200 dark:border-gray-700">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600 dark:text-gray-300">Tip the Author button will appear on posts</span>
                      <button className="px-4 py-2 bg-gradient-to-r from-rose-500 to-pink-600 text-white rounded-lg text-sm font-medium flex items-center space-x-1">
                        <Gift size={14} />
                        <span>Show Love & Support</span>
                      </button>
                    </div>
                  </div>
                </div>

                <div className="p-6 bg-green-50 dark:bg-green-950/20 rounded-xl border border-green-200 dark:border-green-800">
                  <h3 className="text-lg font-bold mb-4 text-green-800 dark:text-green-300 flex items-center space-x-2">
                    <Star size={18} className="text-green-600" />
                    <span>Benefits</span>
                  </h3>
                  <ul className="list-disc list-inside space-y-2 text-sm text-green-700 dark:text-green-300">
                    <li>Monetize your content directly from readers</li>
                    <li>Build stronger connection with your audience</li>
                    <li>Instant payments to your UPI account</li>
                    <li>No transaction fees from Lushivie</li>
                    <li>Mobile-friendly QR code scanning</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        ) : activeTab === 'editor' ? (
          /* Code Editor Tab */
          <div className="max-w-7xl mx-auto">
            <CodeEditor />
          </div>
        ) : activeTab === 'adsense' ? (
          /* AdSense Configuration Tab */
          <div className="max-w-4xl mx-auto">
            <div className="bg-white dark:bg-gray-900 rounded-3xl p-8 shadow-xl border border-gray-100 dark:border-gray-800">
              <div className="flex items-center justify-between mb-8">
                <h2 className="text-4xl font-bold bg-gradient-to-r from-rose-500 to-pink-600 bg-clip-text text-transparent font-playfair">
                  Google AdSense Configuration
                </h2>
                <div className="flex items-center space-x-3">
                  <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                    adSenseConfig.enabled 
                      ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300'
                      : 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300'
                  }`}>
                    {adSenseConfig.enabled ? 'Enabled' : 'Disabled'}
                  </span>
                </div>
              </div>

              <div className="space-y-8">
                <div className="p-6 bg-blue-50 dark:bg-blue-950/20 rounded-xl border border-blue-200 dark:border-blue-800">
                  <h3 className="text-xl font-bold mb-4 text-blue-800 dark:text-blue-300 flex items-center space-x-2">
                    <Settings size={20} className="text-blue-600" />
                    <span>Setup Instructions</span>
                  </h3>
                  <ol className="list-decimal list-inside space-y-2 text-sm text-blue-700 dark:text-blue-300">
                    <li>Create a Google AdSense account at <a href="https://www.google.com/adsense/" target="_blank" className="font-medium underline">google.com/adsense</a></li>
                    <li>Add your website and get approved</li>
                    <li>Create ad units for different placements (Header, Sidebar, Between Posts, Footer)</li>
                    <li>Copy the Publisher ID (ca-pub-xxxxxxxxxxxxxxxx) and Ad Slot IDs</li>
                    <li>Paste them in the form below and enable ads</li>
                    <li>Ads will appear automatically on your live site</li>
                  </ol>
                </div>

                <form className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium mb-3 text-gray-700 dark:text-gray-300">
                      AdSense Publisher ID
                    </label>
                    <input
                      type="text"
                      value={adSenseConfig.clientId}
                      onChange={(e) => setAdSenseConfig({...adSenseConfig, clientId: e.target.value})}
                      placeholder="ca-pub-xxxxxxxxxxxxxxxx"
                      className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 dark:border-gray-700 focus:border-rose-500 focus:outline-none transition-colors bg-white dark:bg-gray-800 text-gray-900 dark:text-white font-mono text-sm"
                    />
                    <p className="text-xs text-gray-500 mt-2">Find this in your AdSense dashboard under "Account" → "Account information"</p>
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-3 text-gray-700 dark:text-gray-300">
                      Header Ad Slot ID
                    </label>
                    <input
                      type="text"
                      value={adSenseConfig.headerAdSlot}
                      onChange={(e) => setAdSenseConfig({...adSenseConfig, headerAdSlot: e.target.value})}
                      placeholder="1234567890"
                      className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 dark:border-gray-700 focus:border-rose-500 focus:outline-none transition-colors bg-white dark:bg-gray-800 text-gray-900 dark:text-white font-mono text-sm"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-3 text-gray-700 dark:text-gray-300">
                      Sidebar Ad Slot ID
                    </label>
                    <input
                      type="text"
                      value={adSenseConfig.sidebarAdSlot}
                      onChange={(e) => setAdSenseConfig({...adSenseConfig, sidebarAdSlot: e.target.value})}
                      placeholder="1234567890"
                      className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 dark:border-gray-700 focus:border-rose-500 focus:outline-none transition-colors bg-white dark:bg-gray-800 text-gray-900 dark:text-white font-mono text-sm"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-3 text-gray-700 dark:text-gray-300">
                      Between Posts Ad Slot ID
                    </label>
                    <input
                      type="text"
                      value={adSenseConfig.betweenPostsAdSlot}
                      onChange={(e) => setAdSenseConfig({...adSenseConfig, betweenPostsAdSlot: e.target.value})}
                      placeholder="1234567890"
                      className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 dark:border-gray-700 focus:border-rose-500 focus:outline-none transition-colors bg-white dark:bg-gray-800 text-gray-900 dark:text-white font-mono text-sm"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-3 text-gray-700 dark:text-gray-300">
                      Footer Ad Slot ID
                    </label>
                    <input
                      type="text"
                      value={adSenseConfig.footerAdSlot}
                      onChange={(e) => setAdSenseConfig({...adSenseConfig, footerAdSlot: e.target.value})}
                      placeholder="1234567890"
                      className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 dark:border-gray-700 focus:border-rose-500 focus:outline-none transition-colors bg-white dark:bg-gray-800 text-gray-900 dark:text-white font-mono text-sm"
                    />
                  </div>
                </form>

                <div className="flex items-center justify-between p-6 bg-gray-50 dark:bg-gray-800/50 rounded-xl border border-gray-200 dark:border-gray-700">
                  <div>
                    <h3 className="text-lg font-semibold text-gray-800 dark:text-white mb-2">Enable AdSense Ads</h3>
                    <p className="text-sm text-gray-600 dark:text-gray-300">Toggle to show/hide ads on your website</p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={adSenseConfig.enabled}
                      onChange={(e) => setAdSenseConfig({...adSenseConfig, enabled: e.target.checked})}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-rose-300 dark:peer-focus:ring-rose-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-gradient-to-r peer-checked:from-rose-500 peer-checked:to-pink-600"></div>
                  </label>
                </div>

                <div className="flex justify-end space-x-4">
                  <button
                    type="button"
                    onClick={() => {
                      localStorage.setItem('lushivie-adsense-config', JSON.stringify(adSenseConfig));
                      toast.success('AdSense configuration saved successfully!', 4000);
                    }}
                    className="px-8 py-3 bg-gradient-to-r from-rose-500 to-pink-600 text-white rounded-xl font-semibold hover:from-rose-600 hover:to-pink-700 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105 flex items-center space-x-2"
                  >
                    <Save size={16} />
                    <span>Save Configuration</span>
                  </button>
                </div>

                <div className="p-6 bg-yellow-50 dark:bg-yellow-950/20 rounded-xl border border-yellow-200 dark:border-yellow-800">
                  <h3 className="text-lg font-bold mb-4 text-yellow-800 dark:text-yellow-300 flex items-center space-x-2">
                    <AlertTriangle size={18} className="text-yellow-600" />
                    <span>Important Notes</span>
                  </h3>
                  <ul className="list-disc list-inside space-y-2 text-sm text-yellow-700 dark:text-yellow-300">
                    <li>Ads will only show on your live deployed website, not in development mode</li>
                    <li>It may take 24-48 hours for ads to start showing after setup</li>
                    <li>Make sure your website complies with AdSense policies</li>
                    <li>Ad performance depends on your content and audience</li>
                    <li>You can enable/disable ads anytime without losing your configuration</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        ) : activeTab === 'posts' ? (
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-12">
          <div className="bg-white dark:bg-gray-900 rounded-3xl p-8 shadow-xl border border-gray-100 dark:border-gray-800">
            <h2 className="text-4xl font-bold mb-8 bg-gradient-to-r from-rose-500 to-pink-600 bg-clip-text text-transparent font-playfair">
              {editingPost ? "Edit Post" : "Create New Post"}
            </h2>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-sm font-medium mb-3 text-gray-700 dark:text-gray-300">Post Title</label>
                <input
                  type="text"
                  name="title"
                  placeholder="Enter your post title"
                  value={formData.title}
                  onChange={handleFormChange}
                  className="w-full px-6 py-4 rounded-2xl border-2 border-gray-200 dark:border-gray-700 focus:border-rose-500 focus:ring-4 focus:ring-rose-500/20 transition-all duration-300 bg-white dark:bg-gray-800 text-gray-800 dark:text-white placeholder-gray-400 shadow-lg shadow-gray-100 dark:shadow-gray-900/50 hover:shadow-xl text-lg font-medium"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-3 text-gray-700 dark:text-gray-300">Description</label>
                <textarea
                  name="description"
                  placeholder="Brief description of your post"
                  value={formData.description}
                  onChange={handleFormChange}
                  rows={4}
                  className="w-full px-6 py-4 rounded-2xl border-2 border-gray-200 dark:border-gray-700 focus:border-rose-500 focus:ring-4 focus:ring-rose-500/20 transition-all duration-300 bg-white dark:bg-gray-800 text-gray-800 dark:text-white placeholder-gray-400 resize-none shadow-lg shadow-gray-100 dark:shadow-gray-900/50 hover:shadow-xl text-lg"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-3 text-gray-700 dark:text-gray-300">Featured Image</label>
                <div className="space-y-4">
                  <input
                    type="url"
                    name="featuredImage"
                    placeholder="Paste image URL (e.g., from Unsplash, Imgur, etc.)"
                    value={formData.featuredImage}
                    onChange={handleFormChange}
                    className="w-full px-6 py-4 rounded-2xl border-2 border-gray-200 dark:border-gray-700 focus:border-rose-500 focus:ring-4 focus:ring-rose-500/20 transition-all duration-300 bg-white dark:bg-gray-800 text-gray-800 dark:text-white placeholder-gray-400 shadow-lg shadow-gray-100 dark:shadow-gray-900/50 hover:shadow-xl"
                  />

                  <div className="text-center">
                    <p className="text-sm text-gray-500 dark:text-gray-400 mb-3">
                      Or upload an image for preview (Note: Use public URLs for better performance)
                    </p>
                    <label className="inline-flex items-center space-x-3 px-6 py-3 bg-gradient-to-r from-purple-500 via-pink-500 to-rose-500 text-white rounded-xl font-semibold hover:from-purple-600 hover:via-pink-600 hover:to-rose-600 transition-all duration-300 cursor-pointer shadow-lg hover:shadow-xl transform hover:scale-105">
                      {uploadingImage ? (
                        <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full"></div>
                      ) : (
                        <Upload size={16} />
                      )}
                      <span>{uploadingImage ? 'Loading...' : 'Upload for Preview'}</span>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleImageUpload}
                        className="hidden"
                        disabled={uploadingImage}
                      />
                    </label>
                  </div>

                  {formData.featuredImage && (
                    <div className="relative w-full h-48 rounded-xl overflow-hidden border-2 border-gray-200 dark:border-gray-700">
                      <img
                        src={formData.featuredImage}
                        alt="Featured preview"
                        className="w-full h-full object-cover"
                        onError={(e) => {
                          e.target.style.display = 'none';
                          e.target.parentElement.innerHTML = '<div class="w-full h-full flex items-center justify-center bg-gray-100 dark:bg-gray-800 text-gray-500 dark:text-gray-400">Invalid image URL</div>';
                        }}
                      />
                    </div>
                  )}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium mb-3 text-gray-700 dark:text-gray-300">Content</label>

                {/* Premium Content Toggle */}
                <div className="mb-4 p-4 bg-gradient-to-r from-amber-50 to-orange-50 dark:from-amber-950/20 dark:to-orange-950/20 rounded-xl border border-amber-200 dark:border-amber-800">
                  <div className="flex items-center justify-between mb-3">
                    <h4 className="font-semibold text-amber-800 dark:text-amber-300 flex items-center space-x-2">
                      <Star size={16} className="text-amber-600" />
                      <span>Premium Content Mode</span>
                    </h4>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        checked={formData.isPremium || false}
                        onChange={(e) => setFormData(prev => ({ ...prev, isPremium: e.target.checked }))}
                        className="sr-only peer"
                      />
                      <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-amber-300 dark:peer-focus:ring-amber-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-gradient-to-r peer-checked:from-amber-500 peer-checked:to-orange-600"></div>
                    </label>
                  </div>
                  <p className="text-sm text-amber-700 dark:text-amber-300">
                    {formData.isPremium 
                      ? "🔒 This post will be exclusive to newsletter subscribers" 
                      : "🌍 This post will be visible to everyone"
                    }
                  </p>
                </div>

                <RichTextEditor
                  value={formData.content}
                  onChange={(content) => setFormData(prev => ({ ...prev, content }))}
                  placeholder={formData.isPremium 
                    ? "Write your premium content for newsletter subscribers..."
                    : "Write your post content with rich formatting..."
                  }
                />
              </div>

              <div className="flex space-x-4">
                <button
                  type="submit"
                  className="btn-premium-gradient flex items-center space-x-3 py-4 px-8 shadow-xl shadow-rose-500/25 hover:shadow-2xl hover:shadow-rose-500/40 transform hover:scale-105 transition-all duration-300 text-lg font-semibold rounded-2xl"
                >
                  <Save size={20} />
                  <span>{editingPost ? "Update" : "Create"} Post</span>
                </button>

                {editingPost && (
                  <button
                    type="button"
                    onClick={() => {
                      setEditingPost(null);
                      setFormData({ title: "", content: "", description: "", featuredImage: "", author: "Maanya Arora", isPremium: false });
                    }}
                    className="btn-secondary py-4 px-8 text-lg font-semibold rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105"
                  >
                    Cancel
                  </button>
                )}
              </div>
            </form>
          </div>

          <div className="bg-white dark:bg-gray-900 rounded-3xl p-8 shadow-xl border border-gray-100 dark:border-gray-800">
            <h2 className="text-4xl font-bold mb-8 bg-gradient-to-r from-rose-500 to-pink-600 bg-clip-text text-transparent font-playfair">
              Existing Posts ({posts.length})
            </h2>

            {loadingPosts ? (
              <div className="flex items-center justify-center py-16">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-rose-600"></div>
              </div>
            ) : postsError ? (
              <p className="text-center text-red-500 py-16">Error loading posts: {postsError.message}</p>
            ) : posts.length === 0 ? (
              <div className="text-center py-12">
                <div className="w-16 h-16 bg-gradient-to-br from-rose-100 to-pink-100 rounded-xl flex items-center justify-center mx-auto mb-4 shadow-lg">
                  <Edit className="text-rose-600" size={24} />
                </div>
                <h3 className="text-2xl font-bold mb-2 text-gray-800 dark:text-white font-playfair">No Posts Yet</h3>
                <p className="text-gray-600 dark:text-gray-300">Create your first post to get started!</p>
              </div>
            ) : (
              <div className="space-y-6 max-h-[800px] overflow-y-auto pr-4">
                {posts.map((post) => (
                  <div key={post.id} className="bg-background dark:bg-gray-800 p-6 rounded-xl border-2 border-gray-100 dark:border-gray-700 hover:border-rose-200 dark:hover:border-rose-700 transition-colors duration-300 shadow-sm">
                    <div className="flex justify-between items-start mb-4">
                      <div className="flex-1">
                        <h3 className="font-bold text-xl mb-2 line-clamp-2 text-gray-800 dark:text-white">{post.title}</h3>
                        <p className="text-gray-600 dark:text-gray-300 text-sm mb-3 line-clamp-2">{post.description || post.excerpt}</p>
                        <div className="flex items-center text-xs text-gray-500 dark:text-gray-400 space-x-4">
                          <span>{new Date(post.publishedAt).toLocaleDateString()}</span>
                          <span>By {post.author}</span>
                        </div>
                      </div>
                      {post.featuredImage && (
                        <div className="w-16 h-16 ml-4 rounded-lg overflow-hidden flex-shrink-0 shadow-md">
                          <img src={post.featuredImage} alt="" className="w-full h-full object-cover" />
                        </div>
                      )}
                    </div>

                    <div className="flex space-x-3 mt-4 pt-4 border-t border-gray-200 dark:border-gray-700">
                      <button
                        onClick={() => handleEdit(post)}
                        className="p-2 text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-900 rounded-lg transition-colors"
                        title="Edit post"
                      >
                        <Edit size={18} />
                      </button>
                      <button
                        onClick={() => handleDelete(post.id)}
                        className="p-2 text-red-600 hover:bg-red-50 dark:hover:bg-red-900 rounded-lg transition-colors"
                        title="Delete post"
                      >
                        <Trash2 size={18} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
        ) : activeTab === 'reviews' ? (
          <AdminReviewManager />
        ) : (
          /* Newsletter Subscribers Tab */
          <div className="max-w-6xl mx-auto">
            <div className="bg-white dark:bg-gray-900 rounded-3xl p-8 shadow-xl border border-gray-100 dark:border-gray-800">
              <div className="flex items-center justify-between mb-8">
                <h2 className="text-4xl font-bold bg-gradient-to-r from-rose-500 to-pink-600 bg-clip-text text-transparent font-playfair">
                  Newsletter Subscribers
                </h2>
                <div className="text-right">
                  <p className="text-3xl font-bold text-rose-600">{subscribersData.total}</p>
                  <p className="text-sm text-gray-500 dark:text-gray-400">Total Subscribers</p>
                </div>
              </div>

              {loadingSubscribers ? (
                <div className="flex items-center justify-center py-16">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-rose-600"></div>
                </div>
              ) : subscribersError ? (
                <p className="text-center text-red-500 py-16">Error loading subscribers: {subscribersError.message}</p>
              ) : subscribersData.subscribers.length === 0 ? (
                <div className="text-center py-12">
                  <div className="w-16 h-16 bg-gradient-to-br from-rose-100 to-pink-100 rounded-xl flex items-center justify-center mx-auto mb-4 shadow-lg">
                    <Mail className="text-rose-600" size={24} />
                  </div>
                  <h3 className="text-2xl font-bold mb-2 text-gray-800 dark:text-white font-playfair">No Subscribers Yet</h3>
                  <p className="text-gray-600 dark:text-gray-300">Newsletter subscribers will appear here once people sign up!</p>
                </div>
              ) : (
                <div className="space-y-4 max-h-[600px] overflow-y-auto">
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {subscribersData.subscribers.map((subscriber) => (
                      <div key={subscriber.id} className="bg-background dark:bg-gray-800 p-6 rounded-xl border-2 border-gray-100 dark:border-gray-700 hover:border-rose-200 dark:hover:border-rose-700 transition-colors duration-300 shadow-sm">
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-center space-x-3 flex-1 min-w-0">
                            <div className="w-10 h-10 bg-gradient-to-br from-rose-400 to-pink-600 rounded-full flex items-center justify-center shadow-lg">
                              <Mail className="text-white" size={16} />
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="font-semibold text-gray-800 dark:text-white truncate">{subscriber.email}</p>
                            </div>
                          </div>
                          <button
                            onClick={() => handleRemoveSubscriber(subscriber.id, subscriber.email)}
                            className="p-2 rounded-lg hover:bg-red-100 dark:hover:bg-red-900/50 text-red-500 hover:text-red-700 transition-colors"
                            title="Remove subscriber"
                          >
                            <X size={16} />
                          </button>
                        </div>
                        <p className="text-xs text-gray-500 dark:text-gray-400">
                          Subscribed: {new Date(subscriber.subscribedAt).toLocaleDateString('en-IN', {
                            year: 'numeric',
                            month: 'short',
                            day: 'numeric',
                            hour: '2-digit',
                            minute: '2-digit'
                          })}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="mt-8 p-6 bg-gradient-to-r from-rose-50 to-pink-50 dark:from-rose-950/20 dark:to-pink-950/20 rounded-xl border border-rose-200/50 dark:border-rose-800/50">
                <h3 className="text-xl font-bold mb-4 text-gray-800 dark:text-white">How Newsletter Works:</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-sm text-gray-700 dark:text-gray-300">
                  <div>
                    <h4 className="font-semibold mb-2 text-rose-600">📧 Subscription Process:</h4>
                    <ul className="space-y-1 text-sm">
                      <li>• Users enter email on homepage or footer</li>
                      <li>• Email validation and duplicate check</li>
                      <li>• Confirmation message shown</li>
                      <li>• Email stored in database</li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2 text-rose-600">🚀 Future Features:</h4>
                    <ul className="space-y-1 text-sm">
                      <li>• Auto-send new blog posts to subscribers</li>
                      <li>• Email templates for beauty tips</li>
                      <li>• Unsubscribe functionality</li>
                      <li>• Email analytics and open rates</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// NotFoundPage Component
function NotFoundPage() {
  return (
    <div className="pt-24 pb-16 bg-gradient-to-br from-rose-50 via-pink-50 to-orange-50 dark:from-rose-950/10 dark:via-pink-950/10 dark:to-orange-950/10">
      <div className="container mx-auto px-6">
        <div className="max-w-3xl mx-auto text-center">
          <div className="w-20 h-20 bg-gradient-to-br from-rose-100 to-pink-100 rounded-full flex items-center justify-center mx-auto mb-6 shadow-lg">
            <X className="text-rose-600" size={32} />
          </div>
          <h1 className="text-5xl font-black mb-4 text-rose-600 font-playfair">Page Not Found</h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 mb-8">
            The page you're looking for doesn't exist or has been moved.
          </p>
          <a href="/" className="btn-primary">Back to Home</a>
        </div>
      </div>
    </div>
  );
}

// Router Component
function Router() {
  return (
    <Switch>
      <Route path="/" component={HomePage} />
      <Route path="/post/:slug" component={PostPage} />
      <Route path="/admin" component={AdminPage} />
      <Route path="/about" component={AboutPage} />
      <Route path="/contact" component={ContactPage} />
      <Route path="/category/:category" component={CategoryPage} />
      <Route path="/privacy-policy" component={PrivacyPolicyPage} />
      <Route path="/terms" component={TermsPage} />
      <Route component={NotFoundPage} />
    </Switch>
  );
}

// AppContent Component for routing and modal management
function AppContent() {
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [profileModalOpen, setProfileModalOpen] = useState(false);
  const [personalizationModalOpen, setPersonalizationModalOpen] = useState(false);
  const [selectedPost, setSelectedPost] = useState(null);
  const [postModalOpen, setPostModalOpen] = useState(false);
  const [tipModalOpen, setTipModalOpen] = useState(false);
  const [tipModalPost, setTipModalPost] = useState(null);
  const [storyModeOpen, setStoryModeOpen] = useState(false);
  const [storyModeIndex, setStoryModeIndex] = useState(0);
  const { user, isOwner } = useAuth();

  // Listen for auth modal events
  useEffect(() => {
    const handleOpenAuthModal = () => {
      setAuthModalOpen(true);
    };

    const handleOpenTipModal = (event) => {
      setTipModalPost(event.detail);
      setTipModalOpen(true);
    };

    const handleOpenStoryMode = (event) => {
      const { posts: storyPosts, initialIndex } = event.detail;
      setStoryModeIndex(initialIndex || 0);
      setStoryModeOpen(true);
    };

    window.addEventListener('openAuthModal', handleOpenAuthModal);
    window.addEventListener('openTipModal', handleOpenTipModal);
    window.addEventListener('openStoryMode', handleOpenStoryMode);
    return () => {
      window.removeEventListener('openAuthModal', handleOpenAuthModal);
      window.removeEventListener('openTipModal', handleOpenTipModal);
      window.removeEventListener('openStoryMode', handleOpenStoryMode);
    };
  }, []);

  // Fetch posts for navbar
  const { data: posts = [] } = useQuery({
    queryKey: ["posts"],
    queryFn: async () => {
      const response = await fetch("/.netlify/functions/server/api/posts");
      if (!response.ok) throw new Error("Failed to fetch posts");
      return response.json();
    }
  });

  // Handle navbar actions
  const handleNavbarAction = (action, data) => {
    if (action === 'showPost') {
      handlePostClick(data);
    } else if (action === 'personalization') {
      setPersonalizationModalOpen(true);
    } else if (action === 'auth') {
      setAuthModalOpen(true);
    } else if (action === 'profile') {
      setProfileModalOpen(true);
    }
  }; 

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900 text-gray-900 dark:text-white transition-colors duration-300">

      <Navbar onAction={handleNavbarAction} posts={posts} />
      <main className="pt-20"> {/* Adjusted padding to account for fixed navbar */}
        <Router />
      </main>
      <Footer />
      <AuthModal
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
      />
      {/* Role-based Profile Modals */}
      {isOwner ? (
        <AdminProfileModal
          isOpen={profileModalOpen}
          onClose={() => setProfileModalOpen(false)}
        />
      ) : (
        <UserProfileModal
          isOpen={profileModalOpen}
          onClose={() => setProfileModalOpen(false)}
        />
      )}
      <PersonalizationSettings
        isOpen={personalizationModalOpen}
        onClose={() => setPersonalizationModalOpen(false)}
      />
      <PostModal 
        post={selectedPost} 
        isOpen={postModalOpen} 
        onClose={() => {
          setPostModalOpen(false);
          setSelectedPost(null);
        }} 
      />
      <TipAuthor
        post={tipModalPost}
        isOpen={tipModalOpen}
        onClose={() => {
          setTipModalOpen(false);
          setTipModalPost(null);
        }}
      />
      <StoryMode
        posts={posts && posts.length > 0 ? posts.filter(post => post.author && post.title) : []}
        isOpen={storyModeOpen}
        onClose={() => setStoryModeOpen(false)}
        initialIndex={storyModeIndex}
      />
      <QuoteThis logoUrl="https://i.ibb.co/zH5KTH4n/IMG-20250811-194616-255.jpg" />
      <LanguageTranslator /> {/* Added LanguageTranslator component */}
      <BeautyHoroscope /> {/* Added BeautyHoroscope component */}
    </div>
  );
}

// Main App Component
function App() {
  // Initialize profile system on app start
  useEffect(() => {
    initializeProfileSystem();
  }, []);

  useEffect(() => {
    // Load AdSense configuration and update script
    const savedConfig = localStorage.getItem('lushivie-adsense-config');
    if (savedConfig) {
      const config = JSON.parse(savedConfig);
      if (config.enabled && config.clientId) {
        // Update AdSense script with real client ID
        const existingScript = document.querySelector('script[src*="adsbygoogle.js"]');
        if (existingScript && config.clientId !== 'ca-pub-0000000000000000') {
          existingScript.src = `https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=${config.clientId}`;
        }

        // Update data-ad-client in all ad units
        const adElements = document.querySelectorAll('.adsbygoogle');
        adElements.forEach(ad => {
          ad.setAttribute('data-ad-client',config.clientId);
        });
      }
    }
  }, []);

  return (
    <ErrorBoundary>
      <QueryClientProvider client={queryClient}>
        <AuthProvider>
          <ToastProvider>
            <ThemeProvider>
              <AppContent />
            </ThemeProvider>
          </ToastProvider>
        </AuthProvider>
      </QueryClientProvider>
    </ErrorBoundary>
  );
}

export default App;