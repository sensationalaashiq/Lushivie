import { initializeApp, getApp } from 'firebase/app';
import {
  getAuth,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signInWithPopup,
  GoogleAuthProvider,
  signOut,
  onAuthStateChanged
} from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';

const firebaseConfig = {
  apiKey: "AIzaSyCrYJR657pKMGx3bFYzeYAPGlSvI5U_jO4",
  authDomain: "lushivie.firebaseapp.com",
  projectId: "lushivie",
  storageBucket: "lushivie.firebasestorage.app",
  messagingSenderId: "323310839643",
  appId: "1:323310839643:web:9c6ac6c6426f95591d1c7e",
  measurementId: "G-RGJ8PQPCC0"
};

// Initialize Firebase (check if already initialized)
let app;
try {
  app = initializeApp(firebaseConfig);
} catch (error) {
  if (error.code === 'app/duplicate-app') {
    app = getApp(); // Get the default app if it already exists
  } else {
    throw error;
  }
}

// Initialize Firebase Authentication and get a reference to the service
export const auth = getAuth(app);

// Initialize Cloud Firestore and get a reference to the service
export const db = getFirestore(app);

// Initialize Firebase Storage and get a reference to the service
export const storage = getStorage(app);

// Google Auth Provider with optimized settings
export const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({
  prompt: 'select_account'
});

// Simplified auth functions without timeout/retry logic
export const signInWithEmail = (email, password) => {
  return signInWithEmailAndPassword(auth, email, password);
};

export const signUpWithEmail = (email, password) => {
  return createUserWithEmailAndPassword(auth, email, password);
};

export const signInWithGoogle = () => {
  return signInWithPopup(auth, googleProvider);
};

export const logOut = () => {
  return signOut(auth);
};

export const onAuthStateChange = (callback) => {
  return onAuthStateChanged(auth, callback);
};

// Owner emails
export const OWNER_EMAILS = ['Glamour.bymaanya@gmail.com', 'Help@lushivie.com'];

export const checkIsOwner = (user) => {
  return user && OWNER_EMAILS.includes(user.email);
};

export default app;