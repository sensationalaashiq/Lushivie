import { useState, useEffect } from 'react';
import { X, User, Camera, Save, Mail, MapPin, Edit3, Calendar } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from './Toast';
import { getCurrentUserProfileImage, getInitialsFromName, saveUserProfile, getUserProfile, uploadProfileImage, isValidImageFile } from '../utils/imageUpload';

export default function UserProfileModal({ isOpen, onClose }) {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [profile, setProfile] = useState({
    displayName: '',
    bio: '',
    profileImage: '',
    location: '',
    email: '',
    website: ''
  });
  const [success, setSuccess] = useState('');
  const [error, setError] = useState('');
  const toast = useToast();

  useEffect(() => {
    if (user && isOpen) {
      // Always try to load user's saved profile first
      const savedUserProfile = getUserProfile(user.email);

      if (savedUserProfile) {
        // Use saved profile data
        setProfile(savedUserProfile);
      } else {
        // Create and save default profile if none exists
        let defaultProfile = {
          displayName: user.displayName || user.email?.split('@')[0] || '',
          bio: 'Beauty enthusiast',
          profileImage: getCurrentUserProfileImage(user.email, user.displayName) || user.photoURL || '',
          location: '',
          email: user.email || '',
          website: '',
          version: '2.0',
          lastUpdated: Date.now()
        };

        // Save default profile immediately
        const saved = saveUserProfile(user.email, defaultProfile);
        if (saved) {
          setProfile(defaultProfile);
        }
      }
    }
  }, [user, isOpen]);

  if (!isOpen || !user) return null;

  const handleImageUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setUploading(true);
    setError('');

    try {
      // Validate the image file
      isValidImageFile(file);

      // Upload with Base64 conversion and limit
      const uploadResult = await uploadProfileImage(file);

      if (uploadResult.success && uploadResult.data) {
        const imageUrl = uploadResult.data.url; // Use cloud URL

        const updatedProfile = { 
          ...profile, 
          profileImage: imageUrl
        };

        setProfile(updatedProfile);
        saveUserProfile(user.email, updatedProfile);

        setSuccess('✅ Profile image uploaded successfully!');
        toast.success('🌟 Profile image updated!');
        setTimeout(() => setSuccess(''), 3000);
      } else {
        throw new Error(uploadResult.error || 'Upload failed - Invalid response format');
      }

    } catch (error) {
      console.error('Image upload error:', error);
      setError(error.message || 'Failed to upload image. Please try again.');
    } finally {
      setUploading(false);
    }
  };

  const handleSave = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      // Validate required fields
      if (!profile.displayName.trim()) {
        throw new Error('Display name is required');
      }

      if (!profile.email.trim()) {
        throw new Error('Email is required');
      }

      // Create a complete profile object with enhanced persistence
      const completeProfile = {
        ...profile,
        displayName: profile.displayName.trim(),
        email: profile.email.trim(),
        bio: profile.bio.trim(),
        location: profile.location.trim(),
        website: profile.website.trim(),
        version: '2.0',
        lastUpdated: Date.now(),
        persistenceId: `user-${user.email}-${Date.now()}` // Unique ID for tracking
      };

      // Multi-layer persistence strategy with support for large profile images
      try {
        const serializedProfile = JSON.stringify(completeProfile);
        
        // Check if we need to clear space for large profile images
        if (serializedProfile.length > 5000000) { // 5MB+ profiles
          try {
            // Clear non-essential data to make room
            const keysToCheck = Object.keys(localStorage);
            for (const k of keysToCheck) {
              if (k.includes('lushivie-saved-posts') || k.includes('temp-') || k.includes('cache-')) {
                localStorage.removeItem(k);
              }
            }
          } catch (e) {
            console.warn('Error clearing cache for profile storage:', e);
          }
        }

        // Layer 1: Primary user-specific storage
        const userProfileKey = `lushivie-user-profile-${user.email}`;
        localStorage.setItem(userProfileKey, serializedProfile);

        // Layer 2: Backup general storage
        localStorage.setItem('lushivie-user-profile', serializedProfile);

        // Layer 3: Profile utilities storage
        saveUserProfile(user.email, completeProfile);

        // Layer 4: Redundant backup with timestamp
        const backupKey = `lushivie-user-backup-${user.email}`;
        localStorage.setItem(backupKey, serializedProfile);

        // Layer 5: Global profiles registry
        const globalProfiles = JSON.parse(localStorage.getItem('lushivie-all-profiles') || '{}');
        globalProfiles[user.email] = completeProfile;
        localStorage.setItem('lushivie-all-profiles', JSON.stringify(globalProfiles));

        // Layer 6: Session storage backup
        sessionStorage.setItem(userProfileKey, serializedProfile);

        console.log('Profile saved to all storage layers successfully');
      } catch (storageError) {
        console.error('Storage error:', storageError);
        
        // If storage fails, at least save to one location
        try {
          const userProfileKey = `lushivie-user-profile-${user.email}`;
          localStorage.setItem(userProfileKey, JSON.stringify(completeProfile));
          console.log('Profile saved to primary storage location');
        } catch (fallbackError) {
          throw new Error('Failed to save profile: Storage quota exceeded. Try using a smaller image.');
        }
      }

      // Update local state immediately
      setProfile(completeProfile);

      // Dispatch multiple events for real-time updates across all components
      const updateEvents = [
        'profileUpdated',
        'userProfileUpdated',
        'adminProfileUpdated', 
        'lushivie-profile-changed',
        'globalImageUpdate'
      ];

      updateEvents.forEach(eventType => {
        window.dispatchEvent(new CustomEvent(eventType, { detail: completeProfile }));
      });

      // Also dispatch storage event for broader compatibility
      window.dispatchEvent(new StorageEvent('storage', {
        key: `lushivie-user-profile-${user.email}`,
        newValue: JSON.stringify(completeProfile),
        storageArea: localStorage
      }));

      // Force a general page refresh for profile updates
      setTimeout(() => {
        window.dispatchEvent(new CustomEvent('storage'));
      }, 100);

      setSuccess('✅ Profile saved permanently across all storage layers! Safe from crashes, reloads & logouts.');
      toast.success('🔒 Profile locked in permanent storage! Only you can change it now.');

      setTimeout(() => {
        onClose();
        setSuccess('');
      }, 2000);
    } catch (error) {
      console.error('Profile update error:', error);
      setError('Failed to update profile: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[120] flex items-center justify-center p-4 bg-black/50">
      <div className="relative w-full max-w-2xl">
        <div className="bg-white dark:bg-gray-900 rounded-3xl border border-gray-100 dark:border-gray-800 shadow-2xl max-w-xl w-full max-h-[85vh] overflow-y-auto">

          {/* Header */}
          <div className="relative p-6 border-b border-gray-100 dark:border-gray-800">
            <button
              onClick={onClose}
              className="absolute top-6 right-6 p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
            >
              <X size={20} className="text-gray-500 dark:text-gray-400" />
            </button>

            <div className="text-center">
              <h2 className="text-3xl font-bold bg-gradient-to-r from-rose-600 to-pink-600 bg-clip-text text-transparent font-playfair mb-2">
                My Profile
              </h2>
              <p className="text-gray-600 dark:text-gray-300">
                Manage your profile information and picture
              </p>
            </div>
          </div>

          {/* Profile Form */}
          <form onSubmit={handleSave} className="p-6 space-y-6">

            {/* Profile Picture Section */}
            <div className="text-center">
              <div className="relative inline-block">
                <div className="w-32 h-32 rounded-full overflow-hidden border-4 border-rose-200 dark:border-rose-800 shadow-xl mx-auto mb-4">
                  {profile.profileImage ? (
                    <img 
                      src={profile.profileImage} 
                      alt="Profile" 
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full bg-gradient-to-br from-rose-400 to-pink-600 flex items-center justify-center">
                      <User size={48} className="text-white" />
                    </div>
                  )}
                </div>

                <label className="absolute bottom-2 right-2 p-3 bg-rose-500 hover:bg-rose-600 rounded-full cursor-pointer shadow-lg transition-colors">
                  <Camera size={16} className="text-white" />
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="hidden"
                    disabled={uploading}
                  />
                </label>
              </div>

              {uploading && (
                <div className="flex items-center justify-center space-x-2 text-rose-600 mt-2">
                  <div className="animate-spin w-4 h-4 border-2 border-rose-500 border-t-transparent rounded-full"></div>
                  <span className="text-sm font-medium">Uploading...</span>
                </div>
              )}
            </div>

            {/* Form Fields */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium mb-2 text-gray-700 dark:text-gray-300">
                  Display Name
                </label>
                <input
                  type="text"
                  value={profile.displayName}
                  onChange={(e) => setProfile({ ...profile, displayName: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 dark:border-gray-700 focus:border-rose-500 focus:outline-none transition-colors bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                  placeholder="Your display name"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2 text-gray-700 dark:text-gray-300">
                  Email
                </label>
                <input
                  type="email"
                  value={profile.email}
                  onChange={(e) => setProfile({ ...profile, email: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 dark:border-gray-700 focus:border-rose-500 focus:outline-none transition-colors bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                  placeholder="your@email.com"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2 text-gray-700 dark:text-gray-300">
                  Location
                </label>
                <input
                  type="text"
                  value={profile.location}
                  onChange={(e) => setProfile({ ...profile, location: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 dark:border-gray-700 focus:border-rose-500 focus:outline-none transition-colors bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                  placeholder="Your location"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2 text-gray-700 dark:text-gray-300">
                  Website
                </label>
                <input
                  type="url"
                  value={profile.website}
                  onChange={(e) => setProfile({ ...profile, website: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 dark:border-gray-700 focus:border-rose-500 focus:outline-none transition-colors bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                  placeholder="https://your-website.com"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2 text-gray-700 dark:text-gray-300">
                Bio
              </label>
              <textarea
                value={profile.bio}
                onChange={(e) => setProfile({ ...profile, bio: e.target.value })}
                rows={4}
                className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 dark:border-gray-700 focus:border-rose-500 focus:outline-none transition-colors bg-white dark:bg-gray-800 text-gray-900 dark:text-white resize-none"
                placeholder="Tell us about yourself..."
              />
            </div>

            {/* Status Messages */}
            {success && (
              <div className="p-4 bg-green-50 dark:bg-green-950/30 border border-green-200 dark:border-green-800 rounded-xl">
                <p className="text-green-600 dark:text-green-400 text-sm font-medium">{success}</p>
              </div>
            )}

            {error && (
              <div className="p-4 bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-800 rounded-xl">
                <p className="text-red-600 dark:text-red-400 text-sm font-medium">{error}</p>
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex justify-end space-x-4 pt-4 border-t border-gray-100 dark:border-gray-800">
              <button
                type="button"
                onClick={onClose}
                className="px-6 py-3 text-gray-600 dark:text-gray-300 hover:text-gray-800 dark:hover:text-white transition-colors"
                disabled={loading}
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={loading || uploading}
                className="px-8 py-3 bg-gradient-to-r from-rose-500 to-pink-600 text-white rounded-xl font-semibold hover:from-rose-600 hover:to-pink-700 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105 disabled:opacity-50 disabled:hover:scale-100 flex items-center space-x-2"
              >
                {loading ? (
                  <>
                    <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full"></div>
                    <span>Saving...</span>
                  </>
                ) : (
                  <>
                    <Save size={16} />
                    <span>Save Profile</span>
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}