
import React, { useState, useEffect } from 'react';
import { 
  Sparkles, Star, Sun, Moon, Crown, Gem, Wind, Droplets, 
  Mountain, Heart, Zap, Waves, Copy, Share2, RefreshCw, 
  Calendar, Palette, Eye, Feather, Scissors
} from 'lucide-react';

// Premium Zodiac SVG Icons
const ZodiacIcon = ({ sign, size = 20 }) => {
  const iconProps = {
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: "currentColor",
    className: "drop-shadow-sm"
  };

  const icons = {
    aries: (
      <svg {...iconProps}>
        <path d="M12 2L6 10h12L12 2z"/>
        <path d="M8 10v4c0 2.76 2.24 5 5 5s5-2.24 5-5v-4"/>
        <circle cx="8" cy="16" r="1.5"/>
        <circle cx="16" cy="16" r="1.5"/>
      </svg>
    ),
    taurus: (
      <svg {...iconProps}>
        <circle cx="12" cy="13" r="7"/>
        <path d="M8 7c2-2 4-3 8 0"/>
        <path d="M10 11h4"/>
      </svg>
    ),
    gemini: (
      <svg {...iconProps}>
        <rect x="6" y="4" width="2" height="16" rx="1"/>
        <rect x="16" y="4" width="2" height="16" rx="1"/>
        <rect x="4" y="8" width="16" height="2" rx="1"/>
        <rect x="4" y="14" width="16" height="2" rx="1"/>
      </svg>
    ),
    cancer: (
      <svg {...iconProps}>
        <path d="M12 2c-3 0-5 2-5 5 0 1.5 1 3 2.5 4C8 12 7 14 7 15.5c0 3 2 5 5 5s5-2 5-5c0-1.5-1-3.5-2.5-4.5C16 10 17 8 17 6.5c0-3-2-5-5-5z"/>
        <circle cx="9.5" cy="8.5" r="1"/>
        <circle cx="14.5" cy="15.5" r="1"/>
      </svg>
    ),
    leo: (
      <svg {...iconProps}>
        <circle cx="12" cy="12" r="6"/>
        <path d="M12 6l-2 4 2-1 2 1-2-4z"/>
        <path d="M8 12l2 2-2 2"/>
        <path d="M16 12l-2 2 2 2"/>
        <path d="M12 16v2"/>
      </svg>
    ),
    virgo: (
      <svg {...iconProps}>
        <path d="M8 2v14c0 2 1 4 4 4s4-2 4-4V2"/>
        <path d="M6 2v8"/>
        <path d="M16 16l3 3"/>
        <path d="M6 8h6"/>
      </svg>
    ),
    libra: (
      <svg {...iconProps}>
        <path d="M4 16h16"/>
        <path d="M7 16c0-2.5 2.24-4.5 5-4.5s5 2 5 4.5"/>
        <circle cx="12" cy="8" r="2"/>
        <path d="M12 6v5.5"/>
      </svg>
    ),
    scorpio: (
      <svg {...iconProps}>
        <path d="M6 2v14c0 2 1 4 4 4h4c2 0 4-2 4-4V2"/>
        <path d="M16 18l4 2-2-3"/>
        <circle cx="9" cy="7" r="0.5"/>
        <circle cx="15" cy="7" r="0.5"/>
        <path d="M18 20l2-2"/>
      </svg>
    ),
    sagittarius: (
      <svg {...iconProps}>
        <path d="M3 21l16-16"/>
        <path d="M15 5h4v4"/>
        <path d="M10 14l8-8"/>
        <circle cx="10" cy="14" r="1"/>
      </svg>
    ),
    capricorn: (
      <svg {...iconProps}>
        <path d="M8 2v12c0 3 1.5 6 4 6s4-3 4-6c0-1.5-0.5-3-2-4"/>
        <path d="M14 8c1.5 0 2.5-0.5 2.5-2s-1-2-2.5-2"/>
        <circle cx="8" cy="8" r="1"/>
      </svg>
    ),
    aquarius: (
      <svg {...iconProps}>
        <path d="M4 12c2 0 2-2 4-2s2 2 4 2 2-2 4-2 2 2 4 2"/>
        <path d="M4 16c2 0 2-2 4-2s2 2 4 2 2-2 4-2 2 2 4 2"/>
        <path d="M8 6l2 4-2 4"/>
        <path d="M16 6l-2 4 2 4"/>
      </svg>
    ),
    pisces: (
      <svg {...iconProps}>
        <path d="M2 12h20"/>
        <path d="M6 8c1.5 1.5 1.5 4.5 0 6"/>
        <path d="M18 8c-1.5 1.5-1.5 4.5 0 6"/>
        <ellipse cx="6" cy="11" rx="3" ry="2"/>
        <ellipse cx="18" cy="11" rx="3" ry="2"/>
      </svg>
    )
  };

  return icons[sign] || icons.aries;
};

const BeautyHoroscope = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [userSign, setUserSign] = useState('');
  const [userDOB, setUserDOB] = useState('');
  const [showDOBInput, setShowDOBInput] = useState(false);
  const [selectedSign, setSelectedSign] = useState(null);

  // Enhanced horoscope data with multiple tips
  const horoscopeData = {
    aries: {
      name: 'Aries',
      dates: 'Mar 21 - Apr 19',
      tips: [
        'Bold red lipstick matches your fiery energy - try matte finish for confidence',
        'Use energizing citrus-scented skincare to awaken your senses',
        'Sharp winged eyeliner complements your dynamic personality'
      ],
      luckyColor: '#FF4B4B',
      element: 'fire',
      icon: Star,
      accent: '#FF6B6B'
    },
    taurus: {
      name: 'Taurus',
      dates: 'Apr 20 - May 20',
      tips: [
        'Earthy tones with gold highlights create luxurious depth',
        'Indulge in rich, creamy textures for your skincare routine',
        'Nude lip colors enhance your natural beauty'
      ],
      luckyColor: '#8B4513',
      element: 'earth',
      icon: Mountain,
      accent: '#D2B48C'
    },
    gemini: {
      name: 'Gemini',
      dates: 'May 21 - Jun 20',
      tips: [
        'Two-toned eye looks express your dual nature perfectly',
        'Switch between glossy and matte lip finishes throughout the day',
        'Experiment with contrasting eyeshadow colors that blend beautifully'
      ],
      luckyColor: '#FFD700',
      element: 'air',
      icon: Wind,
      accent: '#F0E68C'
    },
    cancer: {
      name: 'Cancer',
      dates: 'Jun 21 - Jul 22',
      tips: [
        'Dewy, luminous skin reflects your gentle nature',
        'Pearl and moonstone-inspired highlighters suit you perfectly',
        'Soft pink blushes enhance your natural warmth'
      ],
      luckyColor: '#E6E6FA',
      element: 'water',
      icon: Droplets,
      accent: '#DDA0DD'
    },
    leo: {
      name: 'Leo',
      dates: 'Jul 23 - Aug 22',
      tips: [
        'Golden highlights and shimmer showcase your royal nature',
        'Bold, statement lashes make your eyes the center of attention',
        'Warm bronze tones complement your regal personality'
      ],
      luckyColor: '#FFD700',
      element: 'fire',
      icon: Crown,
      accent: '#FFA500'
    },
    virgo: {
      name: 'Virgo',
      dates: 'Aug 23 - Sep 22',
      tips: [
        'Flawless base makeup showcases your attention to detail',
        'Clean, precise lines in your makeup reflect your perfectionist nature',
        'Neutral tones with subtle definition create timeless elegance'
      ],
      luckyColor: '#90EE90',
      element: 'earth',
      icon: Gem,
      accent: '#98FB98'
    },
    libra: {
      name: 'Libra',
      dates: 'Sep 23 - Oct 22',
      tips: [
        'Balanced pink and peach gradients create perfect harmony',
        'Symmetrical makeup looks appeal to your sense of balance',
        'Rose gold tones enhance your natural diplomacy'
      ],
      luckyColor: '#FFB6C1',
      element: 'air',
      icon: Heart,
      accent: '#FFC0CB'
    },
    scorpio: {
      name: 'Scorpio',
      dates: 'Oct 23 - Nov 21',
      tips: [
        'Deep burgundy and plum shades capture your intensity',
        'Smoky eyes with precise definition suit your mysterious nature',
        'Dark berry lip colors reflect your passionate personality'
      ],
      luckyColor: '#8B0000',
      element: 'water',
      icon: Zap,
      accent: '#CD5C5C'
    },
    sagittarius: {
      name: 'Sagittarius',
      dates: 'Nov 22 - Dec 21',
      tips: [
        'Vibrant coral and orange tones match your adventurous spirit',
        'Bold, experimental color combinations reflect your free nature',
        'Bronzed, sun-kissed looks complement your wanderlust'
      ],
      luckyColor: '#FF7F50',
      element: 'fire',
      icon: Sun,
      accent: '#FA8072'
    },
    capricorn: {
      name: 'Capricorn',
      dates: 'Dec 22 - Jan 19',
      tips: [
        'Classic winged liner with nude lips creates timeless sophistication',
        'Structured, polished looks reflect your ambitious nature',
        'Matte finishes complement your professional demeanor'
      ],
      luckyColor: '#2F4F4F',
      element: 'earth',
      icon: Mountain,
      accent: '#708090'
    },
    aquarius: {
      name: 'Aquarius',
      dates: 'Jan 20 - Feb 18',
      tips: [
        'Electric blue and unconventional colors express your uniqueness',
        'Futuristic, innovative makeup techniques suit your forward-thinking nature',
        'Holographic and iridescent finishes reflect your originality'
      ],
      luckyColor: '#00CED1',
      element: 'air',
      icon: Wind,
      accent: '#40E0D0'
    },
    pisces: {
      name: 'Pisces',
      dates: 'Feb 19 - Mar 20',
      tips: [
        'Dreamy pastels and lavender tones reflect your gentle soul',
        'Glossy, wet-look finishes suit your fluid nature',
        'Ethereal, blended looks with soft edges complement your artistic spirit'
      ],
      luckyColor: '#DDA0DD',
      element: 'water',
      icon: Moon,
      accent: '#E6E6FA'
    }
  };

  const zodiacSigns = [
    { name: 'Aries', dates: 'Mar 21 - Apr 19' },
    { name: 'Taurus', dates: 'Apr 20 - May 20' },
    { name: 'Gemini', dates: 'May 21 - Jun 20' },
    { name: 'Cancer', dates: 'Jun 21 - Jul 22' },
    { name: 'Leo', dates: 'Jul 23 - Aug 22' },
    { name: 'Virgo', dates: 'Aug 23 - Sep 22' },
    { name: 'Libra', dates: 'Sep 23 - Oct 22' },
    { name: 'Scorpio', dates: 'Oct 23 - Nov 21' },
    { name: 'Sagittarius', dates: 'Nov 22 - Dec 21' },
    { name: 'Capricorn', dates: 'Dec 22 - Jan 19' },
    { name: 'Aquarius', dates: 'Jan 20 - Feb 18' },
    { name: 'Pisces', dates: 'Feb 19 - Mar 20' }
  ];

  const getZodiacSign = (dateString) => {
    const date = new Date(dateString);
    const month = date.getMonth() + 1;
    const day = date.getDate();

    if ((month === 3 && day >= 21) || (month === 4 && day <= 19)) return 'aries';
    if ((month === 4 && day >= 20) || (month === 5 && day <= 20)) return 'taurus';
    if ((month === 5 && day >= 21) || (month === 6 && day <= 20)) return 'gemini';
    if ((month === 6 && day >= 21) || (month === 7 && day <= 22)) return 'cancer';
    if ((month === 7 && day >= 23) || (month === 8 && day <= 22)) return 'leo';
    if ((month === 8 && day >= 23) || (month === 9 && day <= 22)) return 'virgo';
    if ((month === 9 && day >= 23) || (month === 10 && day <= 22)) return 'libra';
    if ((month === 10 && day >= 23) || (month === 11 && day <= 21)) return 'scorpio';
    if ((month === 11 && day >= 22) || (month === 12 && day <= 21)) return 'sagittarius';
    if ((month === 12 && day >= 22) || (month === 1 && day <= 19)) return 'capricorn';
    if ((month === 1 && day >= 20) || (month === 2 && day <= 18)) return 'aquarius';
    if ((month === 2 && day >= 19) || (month === 3 && day <= 20)) return 'pisces';
    return 'aries';
  };

  useEffect(() => {
    const savedDOB = localStorage.getItem('lushivie-user-dob');
    if (savedDOB) {
      setUserDOB(savedDOB);
      const sign = getZodiacSign(savedDOB);
      setUserSign(sign);
      setSelectedSign(sign);
    }
  }, []);

  const handleDOBSubmit = () => {
    if (userDOB) {
      localStorage.setItem('lushivie-user-dob', userDOB);
      const sign = getZodiacSign(userDOB);
      setUserSign(sign);
      setSelectedSign(sign);
      setShowDOBInput(false);
    }
  };

  const handleSignSelect = (sign) => {
    setUserSign(sign.toLowerCase());
    setSelectedSign(sign.toLowerCase());
    setShowDOBInput(false);
  };

  const shareHoroscope = async () => {
    const currentSign = horoscopeData[userSign];
    if (!currentSign) return;

    const shareText = `My Beauty Horoscope for ${currentSign.name} ${currentSign.dates}\n\nDaily Tips:\n${currentSign.tips.map((tip, i) => `${i + 1}. ${tip}`).join('\n')}\n\nLucky Color: ${currentSign.luckyColor}\n\nDiscover yours at Lushivie Beauty Blog!`;

    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Beauty Horoscope - Lushivie',
          text: shareText,
          url: window.location.href
        });
      } catch (error) {
        copyToClipboard(shareText);
      }
    } else {
      copyToClipboard(shareText);
    }
  };

  const copyToClipboard = (text) => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(text).then(() => {
        alert('Beauty horoscope copied to clipboard!');
      });
    } else {
      const textArea = document.createElement('textarea');
      textArea.value = text;
      document.body.appendChild(textArea);
      textArea.select();
      document.execCommand('copy');
      document.body.removeChild(textArea);
      alert('Beauty horoscope copied to clipboard!');
    }
  };

  const currentHoroscope = userSign ? horoscopeData[userSign] : null;

  // Color name mapping
  const getColorName = (hexColor) => {
    const colorMap = {
      '#FF4B4B': 'Fiery Red',
      '#8B4513': 'Earth Brown',
      '#FFD700': 'Golden Yellow',
      '#E6E6FA': 'Soft Lavender',
      '#90EE90': 'Fresh Green',
      '#FFB6C1': 'Rose Pink',
      '#8B0000': 'Deep Burgundy',
      '#FF7F50': 'Vibrant Coral',
      '#2F4F4F': 'Slate Gray',
      '#00CED1': 'Electric Turquoise',
      '#DDA0DD': 'Dreamy Plum'
    };
    return colorMap[hexColor] || 'Beautiful Color';
  };

  return (
    <div className="fixed bottom-4 left-4 z-[200]" data-no-translate>
      {/* Premium Floating Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="group relative w-12 h-12 bg-gradient-to-br from-purple-500 via-pink-500 to-rose-400 hover:from-purple-600 hover:via-pink-600 hover:to-rose-500 text-white rounded-2xl shadow-xl hover:shadow-2xl transform hover:scale-105 transition-all duration-300 flex items-center justify-center overflow-hidden"
        title="Beauty Horoscope"
      >
        <div className="absolute inset-0 bg-gradient-to-br from-white/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
        <Sparkles size={20} className="relative z-10 drop-shadow-sm" />
        <div className="absolute -inset-1 bg-gradient-to-r from-purple-500 via-pink-500 to-rose-400 rounded-2xl blur opacity-30 group-hover:opacity-50 transition-opacity duration-300"></div>
      </button>

      {/* Premium Modal */}
      {isOpen && (
        <div className="absolute bottom-14 left-0 w-64 max-h-[480px] bg-white/95 dark:bg-gray-900/95 backdrop-blur-xl rounded-xl shadow-2xl border border-white/20 dark:border-gray-700/30 overflow-hidden transform transition-all duration-300 ease-out">
          {/* Header with Gradient */}
          <div className="relative p-3 bg-gradient-to-br from-purple-500 via-pink-500 to-rose-400 text-white">
            <div className="absolute inset-0 bg-gradient-to-br from-white/10 to-transparent"></div>
            <div className="relative z-10 flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <div className="w-6 h-6 bg-white/20 rounded-lg flex items-center justify-center backdrop-blur-sm">
                  <Sparkles size={12} />
                </div>
                <div>
                  <h3 className="text-sm font-bold">Beauty Horoscope</h3>
                  <p className="text-xs opacity-90">Cosmic beauty guide</p>
                </div>
              </div>
              <button
                onClick={() => setIsOpen(false)}
                className="w-6 h-6 bg-white/20 hover:bg-white/30 rounded-lg flex items-center justify-center transition-all duration-200"
              >
                <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
          </div>

          {/* Content */}
          <div className="p-3 max-h-[360px] overflow-y-auto">
            {!userSign ? (
              <div className="space-y-3">
                <div className="text-center">
                  <div className="w-10 h-10 bg-gradient-to-br from-purple-100 to-pink-100 dark:from-purple-900/30 dark:to-pink-900/30 rounded-lg flex items-center justify-center mx-auto mb-2">
                    <Star className="w-5 h-5 text-purple-600 dark:text-purple-400" />
                  </div>
                  <p className="text-gray-600 dark:text-gray-300 text-xs">
                    Discover your personalized beauty destiny
                  </p>
                </div>

                {!showDOBInput ? (
                  <div className="space-y-2">
                    <button
                      onClick={() => setShowDOBInput(true)}
                      className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white py-2 px-3 rounded-lg transition-all duration-300 font-medium flex items-center justify-center space-x-2 shadow-lg hover:shadow-xl text-sm"
                    >
                      <Calendar size={14} />
                      <span>Enter Birthday</span>
                    </button>

                    <div className="relative">
                      <div className="absolute inset-0 flex items-center">
                        <div className="w-full border-t border-gray-200 dark:border-gray-700"></div>
                      </div>
                      <div className="relative flex justify-center text-xs">
                        <span className="px-2 bg-white dark:bg-gray-900 text-gray-500">or select sign</span>
                      </div>
                    </div>

                    <div className="grid grid-cols-4 gap-1.5">
                      {zodiacSigns.map((sign) => (
                        <button
                          key={sign.name}
                          onClick={() => handleSignSelect(sign.name)}
                          className={`p-1 rounded-md border transition-all duration-300 transform hover:scale-105 group ${
                            selectedSign === sign.name.toLowerCase()
                              ? 'border-purple-500 bg-purple-50 dark:bg-purple-950/30 shadow-lg'
                              : 'border-gray-200 dark:border-gray-700 hover:border-purple-300 dark:hover:border-purple-600'
                          }`}
                        >
                          <div className="flex flex-col items-center space-y-0.5">
                            <div className={`transition-colors ${
                              selectedSign === sign.name.toLowerCase()
                                ? 'text-purple-600 dark:text-purple-400'
                                : 'text-gray-600 dark:text-gray-400 group-hover:text-purple-500'
                            }`}>
                              <ZodiacIcon sign={sign.name.toLowerCase()} size={10} />
                            </div>
                            <div className="text-[9px] font-medium text-gray-900 dark:text-white leading-tight">
                              {sign.name}
                            </div>
                          </div>
                        </button>
                      ))}
                    </div>
                  </div>
                ) : (
                  <div className="space-y-3">
                    <div className="relative">
                      <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                      <input
                        type="date"
                        value={userDOB}
                        onChange={(e) => setUserDOB(e.target.value)}
                        className="w-full pl-10 pr-4 py-2.5 border border-gray-200 dark:border-gray-700 rounded-xl focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20 focus:outline-none bg-gray-50 dark:bg-gray-800 dark:text-white transition-all text-sm"
                      />
                    </div>
                    <div className="flex space-x-2">
                      <button
                        onClick={handleDOBSubmit}
                        className="flex-1 bg-gradient-to-r from-purple-500 to-pink-500 text-white py-2.5 rounded-xl hover:from-purple-600 hover:to-pink-600 transition-all font-medium flex items-center justify-center space-x-2 text-sm"
                      >
                        <Sparkles size={14} />
                        <span>Reveal</span>
                      </button>
                      <button
                        onClick={() => setShowDOBInput(false)}
                        className="px-4 py-2.5 border-2 border-gray-200 dark:border-gray-700 rounded-xl hover:bg-gray-50 dark:hover:bg-gray-800 transition-all"
                      >
                        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
                        </svg>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="space-y-3">
                {/* Zodiac Header */}
                <div className="text-center">
                  <div 
                    className="w-10 h-10 rounded-lg flex items-center justify-center mx-auto mb-1.5 shadow-lg"
                    style={{ backgroundColor: `${currentHoroscope.accent}20`, color: currentHoroscope.luckyColor }}
                  >
                    <ZodiacIcon sign={userSign} size={16} />
                  </div>
                  <h4 className="text-base font-bold text-gray-800 dark:text-white">{currentHoroscope.name}</h4>
                  <p className="text-xs text-gray-500 dark:text-gray-400">{currentHoroscope.dates}</p>
                </div>

                {/* Beauty Tips */}
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Palette className="w-3.5 h-3.5 text-purple-600 dark:text-purple-400" />
                    <h5 className="font-semibold text-gray-800 dark:text-white text-sm">Beauty Tips</h5>
                  </div>
                  <div className="space-y-1.5">
                    {currentHoroscope.tips.slice(0, 2).map((tip, index) => (
                      <div key={index} className="flex items-start space-x-1.5 p-2 bg-gray-50 dark:bg-gray-800/50 rounded-lg">
                        <div className="w-4 h-4 bg-gradient-to-br from-purple-500 to-pink-500 rounded-md flex items-center justify-center flex-shrink-0 mt-0.5">
                          <span className="text-white text-xs font-bold">{index + 1}</span>
                        </div>
                        <p className="text-xs text-gray-700 dark:text-gray-300 leading-relaxed">{tip}</p>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Lucky Color */}
                <div className="flex items-center justify-between p-2.5 bg-gradient-to-r from-gray-50 to-gray-100 dark:from-gray-800 dark:to-gray-700 rounded-lg">
                  <div className="flex items-center space-x-2">
                    <Eye className="w-3.5 h-3.5 text-gray-600 dark:text-gray-400" />
                    <span className="font-medium text-gray-800 dark:text-white text-sm">Lucky Color</span>
                  </div>
                  <div className="flex items-center space-x-1.5">
                    <div
                      className="w-5 h-5 rounded-md border-2 border-white shadow-lg"
                      style={{ backgroundColor: currentHoroscope.luckyColor }}
                    ></div>
                    <span className="text-xs font-medium bg-white dark:bg-gray-800 px-1.5 py-0.5 rounded-md border">
                      {getColorName(currentHoroscope.luckyColor)}
                    </span>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex space-x-2">
                  <button
                    onClick={shareHoroscope}
                    className="flex-1 bg-gradient-to-r from-purple-500 to-pink-500 text-white py-2 px-3 rounded-lg hover:from-purple-600 hover:to-pink-600 transition-all font-medium flex items-center justify-center space-x-2 shadow-lg hover:shadow-xl text-sm"
                  >
                    <Share2 size={14} />
                    <span>Share</span>
                  </button>
                  <button
                    onClick={() => {
                      setUserSign('');
                      setUserDOB('');
                      localStorage.removeItem('lushivie-user-dob');
                      setSelectedSign(null);
                    }}
                    className="px-3 py-2 border-2 border-gray-200 dark:border-gray-700 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-all flex items-center justify-center"
                  >
                    <RefreshCw size={14} className="text-gray-600 dark:text-gray-400" />
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Footer */}
          <div className="px-3 py-2 bg-gradient-to-r from-gray-50/80 to-gray-100/80 dark:from-gray-800/80 dark:to-gray-700/80 backdrop-blur-sm">
            <div className="flex items-center justify-center space-x-2 text-xs text-gray-600 dark:text-gray-400">
              <div className="w-3 h-3 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center">
                <Sparkles size={8} className="text-white" />
              </div>
              <span>Powered by</span>
              <span className="font-semibold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">Lushivie</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default BeautyHoroscope;
