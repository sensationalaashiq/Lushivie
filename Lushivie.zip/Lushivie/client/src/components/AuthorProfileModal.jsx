import { useState, useEffect } from 'react';
import { X, Mail, MapPin, Calendar, Edit2, Instagram, Youtube } from 'lucide-react';
import { getUniversalProfileImage } from '../utils/imageUpload';

export default function AuthorProfileModal({ isOpen, onClose, author }) {
  const [profileData, setProfileData] = useState(null);

  useEffect(() => {
    if (isOpen && author) {
      // Load the most recent profile data from all possible sources
      const loadLatestProfile = () => {
        // Default profile data
        let profileData = {
          name: 'Maanya Arora',
          profileImage: 'https://i.ibb.co/zH5KTH4n/IMG-20250811-194616-255.jpg',
          bio: 'Beauty Expert & Content Creator at Lushivie',
          email: 'Help@lushivie.com',
          location: 'Delhi, India',
          website: 'https://lushivie.com',
          joinDate: '2023',
          postsCount: author.postsCount || 0,
          social: {
            instagram: 'https://www.instagram.com/thee_bareblend',
            youtube: 'https://youtube.com/@thee_bareblend'
          }
        };

        try {
          // Enhanced profile loading for all authors
          if (author.name === 'Maanya Arora' || author.displayName === 'Maanya Arora') {
            // Try multiple storage sources for admin profile
            const adminEmails = ['help@lushivie.com', 'glamour.bymaanya@gmail.com'];
            let latestProfile = null;
            let latestTimestamp = 0;

            // Check all possible storage locations
            const storageKeys = [
              'lushivie-user-profile',
              ...adminEmails.map(email => `lushivie-admin-profile-${email}`),
              ...adminEmails.map(email => `lushivie-user-profile-${email}`)
            ];

            storageKeys.forEach(key => {
              try {
                const profileStr = localStorage.getItem(key);
                if (profileStr) {
                  const profile = JSON.parse(profileStr);
                  const timestamp = profile.lastUpdated || 0;
                  if (timestamp > latestTimestamp || (profile.isOwner && !latestProfile)) {
                    latestProfile = profile;
                    latestTimestamp = timestamp;
                  }
                }
              } catch (e) {
                console.warn(`Error parsing profile for key ${key}:`, e);
              }
            });

            if (latestProfile && latestProfile.profileImage) {
              profileData = {
                ...profileData,
                name: latestProfile.displayName || profileData.name,
                profileImage: latestProfile.profileImage, // ImgBB uploaded image
                bio: latestProfile.bio || profileData.bio,
                email: latestProfile.email || profileData.email,
                location: latestProfile.location || profileData.location,
                website: latestProfile.website || profileData.website,
                imageSource: latestProfile.imageSource || 'imgbb',
                imgbbData: latestProfile.imgbbData // Store ImgBB metadata
              };
              console.log('✅ Latest admin profile loaded with ImgBB image:', latestProfile.profileImage);
            } else {
              // Fallback to universal profile getter with ImgBB support
              const adminProfileImage = getUniversalProfileImage(author.email, author.name || author.displayName, 'Maanya Arora');
              if (adminProfileImage && adminProfileImage !== 'https://i.ibb.co/zH5KTH4n/IMG-20250811-194616-255.jpg') {
                profileData.profileImage = adminProfileImage;
                console.log('✅ Found admin ImgBB uploaded image for visitors');
              } else {
                profileData.profileImage = 'https://i.ibb.co/zH5KTH4n/IMG-20250811-194616-255.jpg';
                console.log('⚠️ No ImgBB profile found - using default admin image');
              }
            }
          } else if (author.email) {
            // For other users, get their profile
            const userProfile = localStorage.getItem(`lushivie-user-profile-${author.email}`);
            if (userProfile) {
              const profile = JSON.parse(userProfile);
              profileData = {
                name: profile.displayName || author.name || author.displayName,
                profileImage: profile.profileImage || author.profileImage || author.image,
                bio: profile.bio || 'Beauty enthusiast and content creator',
                email: profile.email || author.email,
                location: profile.location || 'India',
                website: profile.website,
                joinDate: '2024',
                postsCount: author.postsCount || 0,
                social: profile.social || {}
              };
            }
          }
        } catch (error) {
          console.error('Error loading profile:', error);
        }

        setProfileData(profileData);
      };

      loadLatestProfile();

      // Enhanced event listeners for Firebase real-time updates
      const handleProfileUpdate = (event) => {
        console.log('Profile update detected in AuthorProfileModal:', event.type, event.detail);
        
        // Immediate update for Firebase real-time changes or admin updates
        if (event.detail?.source === 'firebase-realtime' || 
            event.detail?.profileImage || 
            event.detail?.adminUpdate ||
            event.detail?.forceUpdate) {
          console.log('🔥 Firebase real-time update - immediate refresh in AuthorProfileModal');
          
          // Force immediate state update if we have the profile image
          if (event.detail?.profileImage && (author.name === 'Maanya Arora' || author.displayName === 'Maanya Arora')) {
            setProfileData(prev => prev ? {
              ...prev, 
              profileImage: event.detail.profileImage,
              timestamp: Date.now()
            } : null);
          }
          
          loadLatestProfile();
        } else {
          // Standard delay for other updates
          setTimeout(() => {
            loadLatestProfile();
            setProfileData(prev => prev ? {...prev, timestamp: Date.now()} : null);
          }, 30);
        }
      };

      const eventTypes = [
        'profileUpdated',
        'adminProfileUpdated', 
        'adminProfilePersisted',
        'userProfileUpdated',
        'storage',
        'lushivie-profile-changed',
        'globalImageUpdate',
        'globalAdminProfileUpdated',
        'adminProfileGlobalSync',
        'maanyaProfileUpdated',
        'globalAuthorProfileSync',
        'visitorProfileRefresh',
        'imgbbImageUploaded',
        'firestoreProfileUpdated',
        'imgbbProfileSync',
        'firebaseAdminProfileUpdated',
        'visitorAdminProfileSync'
      ];

      eventTypes.forEach(eventType => {
        window.addEventListener(eventType, handleProfileUpdate);
      });

      return () => {
        eventTypes.forEach(eventType => {
          window.removeEventListener(eventType, handleProfileUpdate);
        });
      };
    }
  }, [isOpen, author]);

  if (!isOpen || !author) return null;

  const displayData = profileData || author;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50">
      <div className="relative w-full max-w-md">
        <div className="bg-white dark:bg-gray-900 rounded-3xl border border-gray-100 dark:border-gray-800 shadow-2xl max-w-md w-full max-h-[90vh] overflow-y-auto">
          <button
            onClick={onClose}
            className="absolute top-6 right-6 z-10 p-2 text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200 transition-colors rounded-full hover:bg-gray-100 dark:hover:bg-gray-800"
          >
            <X size={20} />
          </button>

          <div className="p-6 text-center">
            <div className="w-20 h-20 rounded-full mx-auto mb-4 overflow-hidden border-3 border-rose-200 dark:border-rose-800 shadow-lg">
              {(() => {
                // Use universal profile image getter for consistency
                const profileImage = getUniversalProfileImage(
                  displayData.email || author.email,
                  displayData.name || displayData.displayName || author.name,
                  displayData.name || author.name
                );

                console.log('AuthorProfileModal: Profile image for', displayData.name || author.name, ':', profileImage);

                // Always try to display an image
                const imageToUse = profileImage || 
                  displayData.profileImage || 
                  author.profileImage || 
                  author.image ||
                  (displayData.name === 'Maanya Arora' || author.name === 'Maanya Arora' || 
                   displayData.email === 'help@lushivie.com' || author.email === 'help@lushivie.com' 
                   ? 'https://i.ibb.co/zH5KTH4n/IMG-20250811-194616-255.jpg' : null);

                if (imageToUse) {
                  return (
                    <img 
                      src={imageToUse} 
                      alt={displayData.name || 'Author'} 
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        console.log('Image failed to load in AuthorProfileModal:', imageToUse);
                        // Check if this is admin
                        const isAdmin = (displayData.name === 'Maanya Arora' || author.name === 'Maanya Arora' || 
                                        displayData.email === 'help@lushivie.com' || author.email === 'help@lushivie.com');
                        
                        if (isAdmin) {
                          e.target.src = 'https://i.ibb.co/zH5KTH4n/IMG-20250811-194616-255.jpg';
                        } else {
                          e.target.style.display = 'none';
                          e.target.nextSibling.style.display = 'flex';
                        }
                      }}
                    />
                  );
                } else {
                  return (
                    <div className="w-full h-full bg-gradient-to-r from-rose-400 to-pink-500 flex items-center justify-center text-white text-xl font-bold">
                      {(displayData.name || displayData.displayName || 'A').charAt(0)}
                    </div>
                  );
                }
              })()}
              <div 
                className="w-full h-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center text-gray-500 text-sm"
                style={{display: 'none'}}
              >
                No Image
              </div>
            </div>

            <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2 font-playfair">
              {displayData.name || displayData.displayName || 'Author'}
            </h3>

            <p className="text-gray-600 dark:text-gray-300 mb-4 text-sm leading-relaxed">
              {displayData.bio || 'Beauty enthusiast and content creator'}
            </p>

            <div className="space-y-3 text-sm">
              {displayData.email && (
                <div className="flex items-center justify-center space-x-2 text-gray-500 dark:text-gray-400">
                  <Mail size={14} className="text-rose-500" />
                  <span className="text-xs">{displayData.email}</span>
                </div>
              )}

              {displayData.location && (
                <div className="flex items-center justify-center space-x-2 text-gray-500 dark:text-gray-400">
                  <MapPin size={14} className="text-rose-500" />
                  <span className="text-xs">{displayData.location}</span>
                </div>
              )}

              <div className="flex items-center justify-center space-x-2 text-gray-500 dark:text-gray-400">
                <Calendar size={14} className="text-rose-500" />
                <span className="text-xs">Member since {displayData.joinDate || '2023'}</span>
              </div>

              {displayData.postsCount && (
                <div className="flex items-center justify-center space-x-2 text-gray-500 dark:text-gray-400">
                  <Edit2 size={14} className="text-rose-500" />
                  <span className="text-xs">{displayData.postsCount} Posts</span>
                </div>
              )}
            </div>

            {/* Social Links - Compact */}
            {displayData.social && (
              <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-700">
                <div className="flex justify-center space-x-3">
                  {displayData.social.instagram && (
                    <a 
                      href={displayData.social.instagram} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="p-2 bg-gradient-to-r from-pink-500 to-rose-500 text-white rounded-full hover:from-pink-600 hover:to-rose-600 transition-all duration-300 shadow-md hover:shadow-lg transform hover:scale-105"
                    >
                      <Instagram size={16} />
                    </a>
                  )}
                  {displayData.social.youtube && (
                    <a 
                      href={displayData.social.youtube} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="p-2 bg-gradient-to-r from-red-500 to-red-600 text-white rounded-full hover:from-red-600 hover:to-red-700 transition-all duration-300 shadow-md hover:shadow-lg transform hover:scale-105"
                    >
                      <Youtube size={16} />
                    </a>
                  )}
                </div>
              </div>
            )}

            <div className="mt-4 pt-3 border-t border-gray-200 dark:border-gray-700">
              <p className="text-xs text-gray-500 dark:text-gray-400">
                Follow for beauty tips & reviews
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}