import { useState, useEffect } from 'react';
import { X, ChevronLeft, ChevronRight, Pause, Play, Volume2 } from 'lucide-react';
import PremiumContentRenderer from './PremiumContentRenderer';
import {
  getUniversalProfileImage,
  getUserDisplayName,
  getInitialsFromName
} from '../utils/profileUtils';

export default function StoryMode({ posts = [], isOpen, onClose, initialIndex = 0 }) {
  const [currentIndex, setCurrentIndex] = useState(initialIndex);
  const [isPlaying, setIsPlaying] = useState(true);
  const [progress, setProgress] = useState(0);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [refreshKey, setRefreshKey] = useState(0); // Renamed from profileUpdateTrigger for clarity

  const currentPost = posts[currentIndex];
  const storyDuration = 15000; // 15 seconds per story

  useEffect(() => {
    if (isOpen) {
      setCurrentIndex(initialIndex);
      setProgress(0);
    }
  }, [isOpen, initialIndex]);

  // Updated useEffect to use the centralized event system
  useEffect(() => {
    // Register component with centralized event system
    import('../utils/profileUtils').then(({ ProfileEventManager }) => {
      ProfileEventManager.registerComponent('StoryMode');
    });

    // Single profile update listener
    const handleProfileUpdate = (event) => {
      console.log('Profile update detected in StoryMode:', event.type);
      const forceUpdate = event.detail?.forceUpdate || false;
      if (forceUpdate) {
        // Force component refresh
        const refreshState = Math.random();
        setRefreshKey(refreshState);
      }
    };

    // Only listen to centralized events
    const centralizedEvents = [
      'adminProfileUpdated',
      'adminProfileRefresh',
      'globalAdminProfileSync'
    ];

    centralizedEvents.forEach(eventType => {
      window.addEventListener(eventType, handleProfileUpdate);
    });

    return () => {
      // Unregister component
      import('../utils/profileUtils').then(({ ProfileEventManager }) => {
        ProfileEventManager.unregisterComponent('StoryMode');
      });

      centralizedEvents.forEach(eventType => {
        window.removeEventListener(eventType, handleProfileUpdate);
      });
    };
  }, []);

  useEffect(() => {
    if (!isOpen || !isPlaying || !currentPost) return;

    const timer = setInterval(() => {
      setProgress(prev => {
        const newProgress = prev + (100 / (storyDuration / 100));
        if (newProgress >= 100) {
          if (currentIndex < posts.length - 1) {
            setCurrentIndex(currentIndex + 1);
            return 0;
          } else {
            onClose();
            return 100;
          }
        }
        return newProgress;
      });
    }, 100);

    return () => clearInterval(timer);
  }, [isOpen, isPlaying, currentIndex, currentPost, posts.length, onClose, storyDuration]);

  const goToPrevious = () => {
    if (currentIndex > 0) {
      setCurrentIndex(currentIndex - 1);
      setProgress(0);
    }
  };

  const goToNext = () => {
    if (currentIndex < posts.length - 1) {
      setCurrentIndex(currentIndex + 1);
      setProgress(0);
    } else {
      onClose();
    }
  };

  const togglePlayPause = () => {
    setIsPlaying(!isPlaying);
  };

  const speakText = () => {
    if ('speechSynthesis' in window) {
      if (isSpeaking) {
        window.speechSynthesis.cancel();
        setIsSpeaking(false);
      } else {
        const textToSpeak = `${currentPost.title}. ${currentPost.description || ''}`;
        const utterance = new SpeechSynthesisUtterance(textToSpeak);
        utterance.rate = 0.9;
        utterance.onend = () => setIsSpeaking(false);
        window.speechSynthesis.speak(utterance);
        setIsSpeaking(true);
      }
    }
  };

  // Get updated author profile image with ImgBB support
  const getUpdatedAuthorImage = () => {
    if (!currentPost) return null;

    try {
      // Use the universal profile image getter with ImgBB support
      const profileImage = getUniversalProfileImage(
        currentPost.authorEmail,
        currentPost.author,
        currentPost.author
      );

      // Enhanced fallback chain including ImgBB uploaded images
      return profileImage ||
             currentPost.profileImage ||
             currentPost.authorImage ||
             currentPost.imgbbProfileImage ||
             null;
    } catch (error) {
      console.error('Error getting updated author image in StoryMode:', error);
      return currentPost.profileImage || currentPost.authorImage || null;
    }
  };

  const getUpdatedAuthorName = () => {
    if (!currentPost) return 'Unknown Author';

    try {
      // Use the universal display name getter for consistency
      return getUserDisplayName(currentPost.authorEmail, currentPost.author);
    } catch (error) {
      console.error('Error getting updated author name in StoryMode:', error);
      return currentPost.author || 'Unknown Author';
    }
  };

  if (!isOpen || !currentPost) return null;

  // Get updated author data (will automatically refresh on profile updates)
  const authorImage = getUpdatedAuthorImage();
  const authorName = getUpdatedAuthorName();

  return (
    <div
      style={{
        position: 'fixed',
        inset: 0,
        zIndex: 200,
        backgroundColor: 'rgba(0, 0, 0, 0.95)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center'
      }}
    >
      {/* Progress bars */}
      <div
        style={{
          position: 'absolute',
          top: '20px',
          left: '20px',
          right: '20px',
          display: 'flex',
          gap: '4px',
          zIndex: 10
        }}
      >
        {posts.map((_, index) => (
          <div
            key={index}
            style={{
              flex: 1,
              height: '3px',
              backgroundColor: 'rgba(255, 255, 255, 0.3)',
              borderRadius: '2px',
              overflow: 'hidden'
            }}
          >
            <div
              style={{
                height: '100%',
                backgroundColor: 'white',
                borderRadius: '2px',
                width: index < currentIndex ? '100%' : index === currentIndex ? `${progress}%` : '0%',
                transition: index === currentIndex ? 'none' : 'width 0.3s ease'
              }}
            />
          </div>
        ))}
      </div>

      {/* Controls */}
      <div
        style={{
          position: 'absolute',
          top: '20px',
          right: '20px',
          zIndex: 10,
          display: 'flex',
          gap: '12px'
        }}
      >
        <button
          onClick={speakText}
          style={{
            padding: '12px',
            backgroundColor: 'rgba(0, 0, 0, 0.5)',
            border: 'none',
            borderRadius: '50%',
            color: 'white',
            cursor: 'pointer',
            backdropFilter: 'blur(10px)'
          }}
        >
          <Volume2 size={20} color={isSpeaking ? '#f59e0b' : 'white'} />
        </button>

        <button
          onClick={togglePlayPause}
          style={{
            padding: '12px',
            backgroundColor: 'rgba(0, 0, 0, 0.5)',
            border: 'none',
            borderRadius: '50%',
            color: 'white',
            cursor: 'pointer',
            backdropFilter: 'blur(10px)'
          }}
        >
          {isPlaying ? <Pause size={20} /> : <Play size={20} />}
        </button>

        <button
          onClick={onClose}
          style={{
            padding: '12px',
            backgroundColor: 'rgba(0, 0, 0, 0.5)',
            border: 'none',
            borderRadius: '50%',
            color: 'white',
            cursor: 'pointer',
            backdropFilter: 'blur(10px)'
          }}
        >
          <X size={20} />
        </button>
      </div>

      {/* Navigation areas */}
      <div
        onClick={goToPrevious}
        style={{
          position: 'absolute',
          left: 0,
          top: 0,
          bottom: 0,
          width: '30%',
          cursor: currentIndex > 0 ? 'pointer' : 'default',
          zIndex: 5
        }}
      />

      <div
        onClick={goToNext}
        style={{
          position: 'absolute',
          right: 0,
          top: 0,
          bottom: 0,
          width: '30%',
          cursor: 'pointer',
          zIndex: 5
        }}
      />

      {/* Navigation buttons */}
      {currentIndex > 0 && (
        <button
          onClick={goToPrevious}
          style={{
            position: 'absolute',
            left: '20px',
            top: '50%',
            transform: 'translateY(-50%)',
            padding: '16px',
            backgroundColor: 'rgba(0, 0, 0, 0.5)',
            border: 'none',
            borderRadius: '50%',
            color: 'white',
            cursor: 'pointer',
            zIndex: 10,
            backdropFilter: 'blur(10px)'
          }}
        >
          <ChevronLeft size={24} />
        </button>
      )}

      {currentIndex < posts.length - 1 && (
        <button
          onClick={goToNext}
          style={{
            position: 'absolute',
            right: '20px',
            top: '50%',
            transform: 'translateY(-50%)',
            padding: '16px',
            backgroundColor: 'rgba(0, 0, 0, 0.5)',
            border: 'none',
            borderRadius: '50%',
            color: 'white',
            cursor: 'pointer',
            zIndex: 10,
            backdropFilter: 'blur(10px)'
          }}
        >
          <ChevronRight size={24} />
        </button>
      )}

      {/* Main content */}
      <div
        style={{
          width: '100%',
          maxWidth: '400px',
          height: '100vh',
          position: 'relative',
          backgroundImage: currentPost.featuredImage ? `url(${currentPost.featuredImage})` : 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          display: 'flex',
          flexDirection: 'column'
        }}
      >
        {/* Gradient overlay for better text readability */}
        <div
          style={{
            position: 'absolute',
            inset: 0,
            background: 'linear-gradient(to bottom, rgba(0,0,0,0.3) 0%, rgba(0,0,0,0.1) 30%, rgba(0,0,0,0.1) 60%, rgba(0,0,0,0.8) 100%)'
          }}
        />

        {/* Content */}
        <div
          style={{
            position: 'absolute',
            bottom: 0,
            left: 0,
            right: 0,
            padding: '40px 24px 32px',
            color: 'white',
            zIndex: 1
          }}
        >
          {/* Author info */}
          <div
            style={{
              marginBottom: '20px',
              display: 'flex',
              alignItems: 'center',
              gap: '12px'
            }}
          >
            <div
              style={{
                width: '44px',
                height: '44px',
                borderRadius: '50%',
                overflow: 'hidden',
                border: '2px solid rgba(255, 255, 255, 0.8)',
                boxShadow: '0 4px 12px rgba(0, 0, 0, 0.3)'
              }}
            >
              {authorImage ? (
                <img
                  src={authorImage}
                  alt={authorName}
                  style={{
                    width: '100%',
                    height: '100%',
                    objectFit: 'cover'
                  }}
                  onError={(e) => {
                    e.target.style.display = 'none';
                    // Check if this is admin post
                    const isAdmin = (currentPost.author === 'Maanya Arora' || currentPost.authorEmail === 'help@lushivie.com');

                    if (isAdmin) {
                      // For admin, always show the default admin image
                      e.target.parentElement.innerHTML = `<img src="https://i.ibb.co/zH5KTH4n/IMG-20250811-194616-255.jpg" alt="Maanya Arora" style="width: 100%; height: 100%; object-fit: cover;" />`;
                    } else {
                      e.target.parentElement.innerHTML = `<div style="width: 100%; height: 100%; background: linear-gradient(135deg, #f59e0b, #ef4444); display: flex; align-items: center; justify-content: center; font-size: 16px; font-weight: bold; color: white;">${getInitialsFromName(authorName)}</div>`;
                    }
                  }}
                />
              ) : (
                // Check if this is admin post with no custom profile - show empty state instead of initials
                (() => {
                  const isAdmin = (currentPost.author === 'Maanya Arora' || currentPost.authorEmail === 'help@lushivie.com');
                  if (isAdmin) {
                    return (
                      <img
                        src="https://i.ibb.co/zH5KTH4n/IMG-20250811-194616-255.jpg"
                        alt="Maanya Arora"
                        style={{
                          width: '100%',
                          height: '100%',
                          objectFit: 'cover'
                        }}
                      />
                    );
                  } else {
                    return (
                      <div
                        style={{
                          width: '100%',
                          height: '100%',
                          background: 'linear-gradient(135deg, #f59e0b, #ef4444)',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          fontSize: '16px',
                          fontWeight: 'bold',
                          color: 'white'
                        }}
                      >
                        {getInitialsFromName(authorName)}
                      </div>
                    );
                  }
                })()
              )}
            </div>
            <div>
              <div style={{ fontSize: '16px', fontWeight: '700', marginBottom: '2px', textShadow: '0 2px 4px rgba(0,0,0,0.5)' }}>
                {authorName}
              </div>
              <div style={{ fontSize: '13px', opacity: 0.9, textShadow: '0 1px 2px rgba(0,0,0,0.5)' }}>
                {new Date(currentPost.publishedAt).toLocaleDateString('en-IN', {
                  month: 'short',
                  day: 'numeric',
                  year: 'numeric'
                })}
              </div>
            </div>
          </div>

          {/* Post title */}
          <h2
            style={{
              fontSize: '24px',
              fontWeight: '800',
              marginBottom: '16px',
              lineHeight: '1.2',
              textShadow: '0 2px 8px rgba(0,0,0,0.7)',
              fontFamily: "'Playfair Display', serif"
            }}
          >
            {currentPost.title}
          </h2>

          {/* Post content - Full content with proper styling */}
          <div
            style={{
              maxHeight: '300px',
              overflowY: 'auto',
              marginBottom: '16px',
              paddingRight: '8px'
            }}
          >
            <div
              style={{
                fontSize: '15px',
                lineHeight: '1.5',
                textShadow: '0 1px 3px rgba(0,0,0,0.7)',
                color: 'rgba(255, 255, 255, 0.95)'
              }}
            >
              <PremiumContentRenderer content={currentPost.content} />
            </div>
          </div>

          {/* Story counter */}
          <div
            style={{
              textAlign: 'center',
              fontSize: '12px',
              opacity: 0.8,
              fontWeight: '500',
              textShadow: '0 1px 2px rgba(0,0,0,0.5)'
            }}
          >
            {currentIndex + 1} of {posts.length}
          </div>
        </div>
      </div>
    </div>
  );
}