import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Search, Mic, MicOff, X } from 'lucide-react';

const SearchPosts = ({ posts, onFilteredPosts, className = "" }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [isRecognitionSupported, setIsRecognitionSupported] = useState(false);
  const recognitionRef = useRef(null);

  // Enhanced speech recognition support check with better browser compatibility
  useEffect(() => {
    const initializeSpeechRecognition = () => {
      try {
        // Check for speech recognition support across different browsers
        const SpeechRecognition = window.SpeechRecognition || 
                                 window.webkitSpeechRecognition || 
                                 window.mozSpeechRecognition || 
                                 window.msSpeechRecognition;

        if (SpeechRecognition) {
          setIsRecognitionSupported(true);
          recognitionRef.current = new SpeechRecognition();

          // Enhanced configuration for better compatibility
          recognitionRef.current.continuous = false;
          recognitionRef.current.interimResults = false;

          // Multi-language support with fallbacks
          const languages = ['en-IN', 'en-US', 'en-GB', 'hi-IN'];
          recognitionRef.current.lang = languages[0];

          // Enhanced result handling
          recognitionRef.current.onresult = (event) => {
            try {
              if (event.results && event.results.length > 0) {
                const transcript = event.results[0][0].transcript;
                if (transcript && transcript.trim()) {
                  const cleanTranscript = transcript.trim();
                  console.log('🎤 Voice search result:', cleanTranscript);
                  setSearchTerm(cleanTranscript);
                  
                  // Trigger search with the new transcript
                  if (onFilteredPosts && posts && Array.isArray(posts)) {
                    const searchLower = cleanTranscript.toLowerCase();
                    const filtered = posts.filter(post => {
                      if (!post) return false;
                      return (
                        (post.title && post.title.toLowerCase().includes(searchLower)) ||
                        (post.content && post.content.toLowerCase().includes(searchLower)) ||
                        (post.excerpt && post.excerpt.toLowerCase().includes(searchLower)) ||
                        (post.description && post.description.toLowerCase().includes(searchLower)) ||
                        (post.author && post.author.toLowerCase().includes(searchLower))
                      );
                    });
                    onFilteredPosts(filtered);
                    console.log(`🔍 Voice search results: ${filtered.length} posts found`);
                  }
                } else {
                  console.warn('Empty transcript received');
                }
              }
            } catch (error) {
              console.error('Error processing speech result:', error);
            } finally {
              setIsListening(false);
            }
          };

          // Enhanced error handling with user-friendly messages
          recognitionRef.current.onerror = (event) => {
            console.error('Speech recognition error:', event.error);
            setIsListening(false);

            // Provide user-friendly error messages
            let errorMessage = 'Voice search failed. ';
            switch (event.error) {
              case 'no-speech':
                errorMessage += 'No speech detected. Please try again.';
                break;
              case 'audio-capture':
                errorMessage += 'Microphone not accessible. Please check permissions.';
                break;
              case 'not-allowed':
                errorMessage += 'Microphone permission denied. Please enable microphone access.';
                break;
              case 'network':
                errorMessage += 'Network error. Please check your connection.';
                break;
              case 'language-not-supported':
                errorMessage += 'Language not supported. Trying alternative...';
                // Try fallback language
                if (recognitionRef.current) {
                  recognitionRef.current.lang = 'en-US';
                }
                break;
              default:
                errorMessage += 'Please try again or type your search.';
            }

            // Show error to user (you might want to add a toast notification here)
            console.warn(errorMessage);
          };

          // Enhanced end handling
          recognitionRef.current.onend = () => {
            setIsListening(false);
          };

          // Additional event handlers for better UX
          recognitionRef.current.onstart = () => {
            console.log('🎤 Voice recognition started');
          };

          recognitionRef.current.onsoundstart = () => {
            console.log('🔊 Sound detected');
          };

          recognitionRef.current.onspeechstart = () => {
            console.log('🗣️ Speech detected');
          };

        } else {
          setIsRecognitionSupported(false);
          console.warn('Speech recognition not supported in this browser');
        }
      } catch (error) {
        console.error('Error initializing speech recognition:', error);
        setIsRecognitionSupported(false);
      }
    };

    initializeSpeechRecognition();

    return () => {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop();
          recognitionRef.current.abort();
        } catch (error) {
          console.warn('Error stopping speech recognition:', error);
        }
      }
    };
  }, []);

  // Filter posts based on search term
  const handleSearch = useCallback(() => {
    if (!posts || !Array.isArray(posts)) {
      console.warn('Posts array is not available or invalid');
      return [];
    }

    if (!searchTerm.trim()) {
      return posts;
    }

    const searchLower = searchTerm.toLowerCase();
    const filtered = posts.filter(post => {
      if (!post) return false;
      return (
        (post.title && post.title.toLowerCase().includes(searchLower)) ||
        (post.content && post.content.toLowerCase().includes(searchLower)) ||
        (post.excerpt && post.excerpt.toLowerCase().includes(searchLower)) ||
        (post.description && post.description.toLowerCase().includes(searchLower)) ||
        (post.author && post.author.toLowerCase().includes(searchLower))
      );
    });

    console.log(`🔍 Search results: ${filtered.length} posts found for "${searchTerm}"`);
    return filtered;
  }, [searchTerm, posts]);

  const filteredPosts = handleSearch();

  useEffect(() => {
    if (onFilteredPosts) {
      onFilteredPosts(filteredPosts);
    }
  }, [filteredPosts]);


  // Enhanced voice recognition with better error handling and permissions
  const startVoiceSearch = () => {
    // Check for browser support
    if (!isRecognitionSupported) {
      alert('Voice search is not supported in this browser. Please use Chrome, Edge, or Safari.');
      return;
    }

    try {
      if (recognitionRef.current) {
        recognitionRef.current.start();
      }
    } catch (error) {
      console.error('Error starting voice search:', error);
      setIsListening(false);
      alert('Failed to start voice search. Please try again.');
    }
  };

  // Enhanced stop voice recognition
  const stopVoiceSearch = () => {
    try {
      if (recognitionRef.current) {
        // Clear timeout if exists
        if (recognitionRef.current.timeoutId) {
          clearTimeout(recognitionRef.current.timeoutId);
        }

        recognitionRef.current.stop();
        recognitionRef.current.abort(); // Force stop for better compatibility
        setIsListening(false);
        console.log('🛑 Voice search stopped');
      }
    } catch (error) {
      console.warn('Error stopping voice recognition:', error);
      setIsListening(false);
    }
  };

  // Clear search
  const clearSearch = () => {
    setSearchTerm('');
    if (onFilteredPosts) {
      onFilteredPosts(posts); // Reset to show all posts
    }
  };

  return (
    <div className={`relative ${className}`}>
      <div className="relative flex items-center">
        {/* Search Input */}
        <div className="relative flex-1">
          <Search
            className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 dark:text-gray-500"
            size={20}
          />
          <input
            type="text"
            placeholder="Search posts..."
            value={searchTerm}
            onChange={(e) => {
              setSearchTerm(e.target.value);
              // Don't filter immediately - let useEffect handle it
            }}
            className={`w-full pl-12 ${isRecognitionSupported ? 'pr-20' : searchTerm ? 'pr-12' : 'pr-4'} py-4 rounded-2xl border-2 border-gray-200 dark:border-gray-700 focus:border-rose-500 focus:ring-4 focus:ring-rose-500/20 transition-all duration-300 bg-white dark:bg-gray-800 text-gray-800 dark:text-white placeholder-gray-400 shadow-lg shadow-gray-100 dark:shadow-gray-900/50 hover:shadow-xl text-lg`}
          />

          <div className="absolute right-2 top-1/2 transform -translate-y-1/2 flex items-center space-x-1">
            {/* Clear Button */}
            {searchTerm && (
              <button
                onClick={clearSearch}
                className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full transition-colors"
                title="Clear search"
              >
                <X size={16} className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300" />
              </button>
            )}

            {/* Enhanced Voice Search Button with better accessibility */}
            <button
              onClick={isRecognitionSupported ? (isListening ? stopVoiceSearch : startVoiceSearch) : () => alert('Voice search is not supported in your browser. Please use Chrome, Edge, or Safari.')}
              className={`p-2 rounded-full transition-all duration-300 ${
                isListening
                  ? 'text-white bg-rose-500 animate-pulse shadow-lg scale-110'
                  : isRecognitionSupported 
                    ? 'text-rose-500 hover:text-rose-600 hover:bg-rose-100 dark:hover:bg-rose-900/50 border border-rose-300 hover:border-rose-500 hover:scale-105'
                    : 'opacity-50 text-gray-400 border border-gray-300 cursor-not-allowed'
              }`}
              title={
                isListening 
                  ? 'Stop listening... (Click to stop)' 
                  : isRecognitionSupported 
                    ? 'Voice Search (Click and speak)' 
                    : 'Voice search not supported in this browser'
              }
              disabled={!isRecognitionSupported}
              aria-label={isListening ? 'Stop voice search' : 'Start voice search'}
            >
              {isListening ? <MicOff size={16} /> : <Mic size={16} />}
            </button>
          </div>
        </div>
      </div>

      {/* Enhanced Voice Search Status */}
      {isListening && (
        <div className="absolute top-full left-0 right-0 mt-2 p-4 bg-gradient-to-r from-rose-500 to-pink-500 text-white rounded-xl shadow-xl z-10 border border-rose-300">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="flex space-x-1">
                <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
                <div className="w-2 h-2 bg-white rounded-full animate-pulse" style={{animationDelay: '0.2s'}}></div>
                <div className="w-2 h-2 bg-white rounded-full animate-pulse" style={{animationDelay: '0.4s'}}></div>
              </div>
              <span className="text-sm font-medium">🎤 Listening... Speak clearly!</span>
            </div>
            <button 
              onClick={stopVoiceSearch}
              className="text-white hover:bg-white/20 rounded-full p-1 transition-colors"
              title="Stop listening"
            >
              <X size={16} />
            </button>
          </div>
          <div className="mt-2 text-xs opacity-90">
            Say your search terms clearly. Tap to stop listening.
          </div>
        </div>
      )}

      {/* Search Results Count */}
      {searchTerm && (
        <div className="absolute top-full left-0 right-0 mt-1 text-center">
          <span className="text-xs text-gray-500 dark:text-gray-400 bg-white dark:bg-gray-800 px-3 py-1 rounded-full shadow-sm">
            {posts && Array.isArray(posts) ? posts.filter(post => {
              if (!post) return false;
              const searchLower = searchTerm.toLowerCase();
              return (
                (post.title && post.title.toLowerCase().includes(searchLower)) ||
                (post.content && post.content.toLowerCase().includes(searchLower)) ||
                (post.excerpt && post.excerpt.toLowerCase().includes(searchLower)) ||
                (post.description && post.description.toLowerCase().includes(searchLower)) ||
                (post.author && post.author.toLowerCase().includes(searchLower))
              );
            }).length : 0} results found
          </span>
        </div>
      )}
    </div>
  );
};

export default SearchPosts;