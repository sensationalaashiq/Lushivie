
import React, { useState, useEffect } from 'react';
import { Lock, Star, Crown } from 'lucide-react';

const PremiumSection = ({ content, isPremium = false, onSubscribe, isSubscribed = false }) => {
  const [showSubscribeModal, setShowSubscribeModal] = useState(false);
  const [localSubscribed, setLocalSubscribed] = useState(false);

  useEffect(() => {
    // Mock subscription status - in production, this would come from user data
    const mockSubscription = localStorage.getItem('lushivie-premium-subscription');
    setLocalSubscribed(mockSubscription === 'true' || isSubscribed);
  }, [isSubscribed]);

  const handleSubscribeClick = () => {
    setShowSubscribeModal(true);
  };

  const handleSubscribe = () => {
    // Mock subscription - in production, integrate with payment gateway
    localStorage.setItem('lushivie-premium-subscription', 'true');
    setLocalSubscribed(true);
    setShowSubscribeModal(false);
    if (onSubscribe) onSubscribe();
  };

  const SubscribeModal = () => (
    <div
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        backgroundColor: 'rgba(0, 0, 0, 0.7)',
        backdropFilter: 'blur(10px)',
        zIndex: 2000,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '20px',
        animation: 'fadeIn 0.3s ease-out'
      }}
      onClick={() => setShowSubscribeModal(false)}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        style={{
          backgroundColor: '#ffffff',
          borderRadius: '24px',
          padding: '40px',
          maxWidth: '480px',
          width: '100%',
          textAlign: 'center',
          boxShadow: '0 30px 60px rgba(0, 0, 0, 0.2)',
          animation: 'slideUp 0.4s ease-out',
          border: '1px solid #f1f5f9'
        }}
      >
        <div
          style={{
            width: '80px',
            height: '80px',
            borderRadius: '50%',
            background: 'linear-gradient(135deg, #fbbf24, #f59e0b, #d97706)',
            margin: '0 auto 24px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            boxShadow: '0 12px 30px rgba(245, 158, 11, 0.4)'
          }}
        >
          <Crown size={36} color="white" />
        </div>

        <h2
          style={{
            fontSize: '28px',
            fontWeight: '800',
            marginBottom: '16px',
            background: 'linear-gradient(135deg, #fbbf24, #f59e0b)',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            backgroundClip: 'text'
          }}
        >
          Unlock Premium Content
        </h2>

        <p style={{ 
          color: '#64748b', 
          fontSize: '16px', 
          marginBottom: '32px',
          lineHeight: '1.6'
        }}>
          Get access to exclusive beauty tips, in-depth tutorials, and premium product reviews from Maanya Arora.
        </p>

        <div style={{ marginBottom: '32px' }}>
          <div style={{
            backgroundColor: '#fef3f2',
            border: '1px solid #fecaca',
            borderRadius: '16px',
            padding: '24px',
            marginBottom: '24px'
          }}>
            <h3 style={{
              fontSize: '20px',
              fontWeight: '700',
              color: '#dc2626',
              marginBottom: '16px'
            }}>
              Premium Benefits
            </h3>
            <div style={{ textAlign: 'left' }}>
              {[
                'Exclusive beauty tutorials & techniques',
                'Early access to product reviews',
                'Personal skincare routine recommendations',
                'Ad-free reading experience',
                'Access to premium community'
              ].map((benefit, index) => (
                <div key={index} style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '12px',
                  marginBottom: '12px'
                }}>
                  <Star size={16} color="#dc2626" fill="#dc2626" />
                  <span style={{ color: '#374151', fontSize: '14px' }}>{benefit}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div style={{ display: 'flex', gap: '12px', justifyContent: 'center' }}>
          <button
            onClick={handleSubscribe}
            style={{
              background: 'linear-gradient(135deg, #fbbf24, #f59e0b)',
              color: 'white',
              padding: '16px 32px',
              borderRadius: '12px',
              border: 'none',
              fontSize: '16px',
              fontWeight: '600',
              cursor: 'pointer',
              transition: 'all 0.3s ease',
              boxShadow: '0 8px 25px rgba(245, 158, 11, 0.3)'
            }}
            onMouseEnter={(e) => {
              e.target.style.transform = 'translateY(-2px)';
              e.target.style.boxShadow = '0 12px 35px rgba(245, 158, 11, 0.4)';
            }}
            onMouseLeave={(e) => {
              e.target.style.transform = 'translateY(0)';
              e.target.style.boxShadow = '0 8px 25px rgba(245, 158, 11, 0.3)';
            }}
          >
            Subscribe Now - ₹99/month
          </button>
          <button
            onClick={() => setShowSubscribeModal(false)}
            style={{
              backgroundColor: '#f8fafc',
              color: '#64748b',
              padding: '16px 24px',
              borderRadius: '12px',
              border: '1px solid #e2e8f0',
              fontSize: '16px',
              fontWeight: '600',
              cursor: 'pointer',
              transition: 'all 0.2s ease'
            }}
          >
            Maybe Later
          </button>
        </div>

        <p style={{ 
          color: '#9ca3af', 
          fontSize: '12px', 
          marginTop: '24px',
          lineHeight: '1.4'
        }}>
          Cancel anytime • 7-day free trial • Secure payment
        </p>
      </div>
    </div>
  );

  if (!isPremium) {
    return <div dangerouslySetInnerHTML={{ __html: content }} />;
  }

  if (localSubscribed) {
    return (
      <div 
        style={{ 
          animation: 'fadeInContent 0.5s ease-out'
        }}
        dangerouslySetInnerHTML={{ __html: content }} 
      />
    );
  }

  return (
    <>
      <div
        style={{
          position: 'relative',
          margin: '32px 0',
          borderRadius: '16px',
          overflow: 'hidden',
          border: '2px solid #fbbf24',
          background: 'linear-gradient(135deg, #fef3f2, #fef7ed)'
        }}
      >
        <div
          style={{
            filter: 'blur(8px)',
            opacity: 0.3,
            pointerEvents: 'none',
            padding: '24px',
            background: 'rgba(255, 255, 255, 0.8)'
          }}
          dangerouslySetInnerHTML={{ __html: content }}
        />
        
        <div
          style={{
            position: 'absolute',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            background: 'linear-gradient(135deg, rgba(251, 191, 36, 0.1), rgba(245, 158, 11, 0.1))',
            backdropFilter: 'blur(2px)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            cursor: 'pointer',
            transition: 'all 0.3s ease'
          }}
          onClick={handleSubscribeClick}
          onMouseEnter={(e) => {
            e.target.style.background = 'linear-gradient(135deg, rgba(251, 191, 36, 0.15), rgba(245, 158, 11, 0.15))';
          }}
          onMouseLeave={(e) => {
            e.target.style.background = 'linear-gradient(135deg, rgba(251, 191, 36, 0.1), rgba(245, 158, 11, 0.1))';
          }}
        >
          <div
            style={{
              backgroundColor: 'rgba(255, 255, 255, 0.95)',
              borderRadius: '20px',
              padding: '32px',
              textAlign: 'center',
              boxShadow: '0 20px 40px rgba(0, 0, 0, 0.15)',
              border: '2px solid #fbbf24',
              maxWidth: '320px',
              animation: 'pulse 2s infinite'
            }}
          >
            <div
              style={{
                width: '64px',
                height: '64px',
                borderRadius: '50%',
                background: 'linear-gradient(135deg, #fbbf24, #f59e0b)',
                margin: '0 auto 16px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                boxShadow: '0 8px 25px rgba(245, 158, 11, 0.4)'
              }}
            >
              <Lock size={24} color="white" />
            </div>
            <h3
              style={{
                fontSize: '20px',
                fontWeight: '700',
                marginBottom: '12px',
                background: 'linear-gradient(135deg, #fbbf24, #f59e0b)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                backgroundClip: 'text'
              }}
            >
              Premium Content
            </h3>
            <p style={{ 
              color: '#64748b', 
              fontSize: '14px', 
              marginBottom: '20px',
              lineHeight: '1.5'
            }}>
              Unlock exclusive beauty insights and advanced techniques
            </p>
            <div
              style={{
                backgroundColor: '#fbbf24',
                color: 'white',
                padding: '12px 24px',
                borderRadius: '12px',
                fontSize: '14px',
                fontWeight: '600',
                border: 'none',
                cursor: 'pointer',
                transition: 'all 0.2s ease',
                display: 'inline-block'
              }}
            >
              Subscribe to Unlock
            </div>
          </div>
        </div>
      </div>

      {showSubscribeModal && <SubscribeModal />}

      <style jsx>{`
        @keyframes fadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        
        @keyframes slideUp {
          from {
            opacity: 0;
            transform: translateY(20px) scale(0.95);
          }
          to {
            opacity: 1;
            transform: translateY(0) scale(1);
          }
        }

        @keyframes fadeInContent {
          from {
            opacity: 0;
            transform: translateY(10px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        @keyframes pulse {
          0%, 100% { transform: scale(1); }
          50% { transform: scale(1.02); }
        }
      `}</style>
    </>
  );
};

export default PremiumSection;
