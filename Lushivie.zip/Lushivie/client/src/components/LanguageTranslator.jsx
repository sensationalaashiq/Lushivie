import React, { useState, useEffect, useRef } from 'react';
import { Globe, ChevronDown, Loader, Check } from 'lucide-react';

const LanguageTranslator = ({ className = "" }) => {
  const [selectedLanguage, setSelectedLanguage] = useState('en');
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [isTranslating, setIsTranslating] = useState(false);
  const [translationCache, setTranslationCache] = useState({});
  const dropdownRef = useRef(null);

  // Languages - Hindi and English only
  const languages = [
    { code: 'en', name: 'English', flag: '🇺🇸' },
    { code: 'hi', name: 'हिन्दी (Hindi)', flag: '🇮🇳' }
  ];

  // Load saved language preference
  useEffect(() => {
    const savedLanguage = localStorage.getItem('lushivie-language');
    if (savedLanguage && languages.find(lang => lang.code === savedLanguage)) {
      setSelectedLanguage(savedLanguage);
    }

    // Load translation cache
    const savedCache = localStorage.getItem('lushivie-translation-cache');
    if (savedCache) {
      try {
        setTranslationCache(JSON.parse(savedCache));
      } catch (error) {
        console.error('Error loading translation cache:', error);
      }
    }
  }, []);

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsDropdownOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Translation function with better error handling
  const translateText = async (text, targetLang, sourceLang = 'en') => {
    if (targetLang === 'en' || targetLang === sourceLang) return text;
    if (!text || text.trim() === '') return text;

    // Check cache first
    const cacheKey = `${sourceLang}-${targetLang}-${text}`;
    if (translationCache[cacheKey]) {
      return translationCache[cacheKey];
    }

    try {
      // Comprehensive fallback translations for Hindi
      const fallbackTranslations = {
        'hi': {
          // Basic Navigation
          'Lushivie Beauty Blog': 'लुशिवी ब्यूटी ब्लॉग',
          'Beauty Reviews': 'सौंदर्य समीक्षा',
          'Read More': 'और पढ़ें',
          'Premium': 'प्रीमियम',
          'Featured Posts': 'फीचर्ड पोस्ट',
          'Comments': 'टिप्पणियाँ',
          'Sign in to comment': 'टिप्पणी करने के लिए साइन इन करें',
          'Home': 'होम',
          'About': 'हमारे बारे में',
          'Contact': 'संपर्क',
          'Search': 'खोजें',
          'Beauty': 'सुंदरता',
          'Skincare': 'त्वचा की देखभाल',
          'Makeup': 'मेकअप',
          'Hair Care': 'बालों की देखभाल',
          'Dark': 'डार्क',
          'Light': 'लाइट',
          'Theme': 'थीम',
          'Settings': 'सेटिंग्स',
          'Profile': 'प्रोफाइल',
          'Login': 'लॉगिन',
          'Logout': 'लॉगआउट',
          'Subscribe': 'सब्सक्राइब करें',
          'Newsletter': 'न्यूज़लेटर',
          'Share': 'शेयर करें',
          'Save': 'सेव करें',
          'Like': 'लाइक',
          'Follow': 'फॉलो करें',
          'Sign In': 'साइन इन',
          'Sign Up': 'साइन अप',
          'Sign Out': 'साइन आउट',

          // Content & Posts
          'The Ultimate Guide to Luxury Skincare': 'लक्जरी स्किनकेयर के लिए अंतिम गाइड',
          'Mastering the Perfect Winged Eyeliner': 'परफेक्ट विंग्ड आईलाइनर में महारत',
          'Introduction to Luxury Beauty': 'लक्जरी ब्यूटी का परिचय',
          'Learn the professional techniques': 'पेशेवर तकनीकों को सीखें',
          'Beauty Expert & Content Creator': 'ब्यूटी एक्सपर्ट और कंटेंट क्रिएटर',
          'Maanya Arora': 'माान्या अरोड़ा',
          'Delhi\'s finest beauty content creator': 'दिल्ली की बेहतरीन ब्यूटी कंटेंट क्रिएटर',
          'Expert reviews and honest recommendations': 'विशेषज्ञ समीक्षा और ईमानदार सिफारिशें',
          'Save post': 'पोस्ट सेव करें',
          'Share post': 'पोस्ट शेयर करें',
          'Saved Posts': 'सेव किए गए पोस्ट',

          // Statistics & Numbers
          'Happy Readers': 'खुश पाठक',
          'Beauty Posts': 'ब्यूटी पोस्ट',
          'Visitors': 'आगंतुक',
          'Support': 'समर्थन',

          // Search & Discovery
          'Find Your Perfect Beauty Match': 'अपना परफेक्ट ब्यूटी मैच खोजें',
          'Search through our curated beauty content': 'हमारे क्यूरेटेड ब्यूटी कंटेंट में खोजें',
          'Search posts...': 'पोस्ट खोजें...',
          'Voice Search': 'वॉयस सर्च',
          'Discover': 'डिस्कवर करें',
          'Luxury Beauty': 'लक्जरी ब्यूटी',
          'Discover the latest in luxury beauty': 'लक्जरी ब्यूटी में नवीनतम की खोज करें',
          'Premium Beauty Content': 'प्रीमियम ब्यूटी कंटेंट',

          // Reviews & Ratings
          'Real experiences, honest reviews': 'वास्तविक अनुभव, ईमानदार समीक्षाएं',
          'Average Rating': 'औसत रेटिंग',
          'Successful Reviews': 'सफल समीक्षाएं',
          'Share Your Experience': 'अपना अनुभव साझा करें',
          'Let others know about your beauty journey': 'दूसरों को अपनी ब्यूटी जर्नी के बारे में बताएं',
          'Your Name': 'आपका नाम',
          'Enter your name': 'अपना नाम दर्ज करें',
          'Email (Optional)': 'ईमेल (वैकल्पिक)',
          'Rating': 'रेटिंग',
          'Click to rate': 'रेट करने के लिए क्लिक करें',
          'Your Review': 'आपकी समीक्षा',
          'Share your thoughts...': 'अपने विचार साझा करें...',
          'characters remaining': 'वर्ण शेष',
          'Submit Review': 'समीक्षा सबमिट करें',
          'Verified Review': 'सत्यापित समीक्षा',
          'stars': 'स्टार',

          // Footer & Newsletter
          'Join the Beauty Revolution': 'ब्यूटी रिवोल्यूशन में शामिल हों',
          'Get exclusive beauty tips and product recommendations': 'एक्सक्लूसिव ब्यूटी टिप्स और प्रोडक्ट सिफारिशें पाएं',
          'Enter your email address': 'अपना ईमेल पता दर्ज करें',
          'Subscribe to Newsletter': 'न्यूज़लेटर की सदस्यता लें',
          'Join 10,000+ beauty enthusiasts': '10,000+ ब्यूटी उत्साही लोगों में शामिल हों',
          'Beauty & Luxury': 'सौंदर्य और लक्जरी',
          'Your premier destination for beauty content': 'ब्यूटी कंटेंट के लिए आपकी प्रमुख मंजिल',
          'Lajpat Nagar, Delhi': 'लाजपत नगर, दिल्ली',
          'Quick Links': 'त्वरित लिंक',
          'Privacy Policy': 'प्राइवेसी पॉलिसी',
          'Terms': 'नियम',
          'Stay Updated': 'अपडेट रहें',
          'Privacy': 'प्राइवेसी',
          'A premium creation by': 'का एक प्रीमियम निर्माण',
          'For beauty dreamers': 'ब्यूटी ड्रीमर्स के लिए',

          // Theme & Settings
          'Switch theme (Currently': 'थीम स्विच करें (वर्तमान में',
          'Preferences Settings': 'प्राथमिकता सेटिंग्स',
          'Preferences': 'प्राथमिकताएं',
          'Customize experience': 'अनुभव को कस्टमाइज़ करें',

          // Language & Translation
          'Language': 'भाषा',
          'English': 'अंग्रेजी',
          'Using MyMemory Translation': 'MyMemory अनुवाद का उपयोग',
          'Translating...': 'अनुवाद हो रहा है...',

          // Common UI Elements
          'Close': 'बंद करें',
          'Open': 'खोलें',
          'Back': 'वापस',
          'Next': 'अगला',
          'Previous': 'पिछला',
          'Submit': 'सबमिट करें',
          'Cancel': 'रद्द करें',
          'Edit': 'संपादित करें',
          'Delete': 'हटाएं',
          'Update': 'अपडेट करें',
          'Add': 'जोड़ें',
          'Remove': 'हटाएं',
          'Select': 'चुनें',
          'Clear': 'साफ़ करें',
          'Reset': 'रीसेट करें',
          'Apply': 'लागू करें',
          'Loading...': 'लोड हो रहा है...',
          'Please wait...': 'कृपया प्रतीक्षा करें...',
          'Error': 'त्रुटि',
          'Success': 'सफलता',
          'Warning': 'चेतावनी',
          'Info': 'जानकारी',

          // Newsletter & Email Us
          'Email Us Directly': 'हमें सीधे ईमेल करें',
          'Have specific questions or want to collaborate? Send us a message directly!': 'विशिष्ट प्रश्न हैं या सहयोग करना चाहते हैं? हमें सीधे संदेश भेजें!',
          'Our team at Help@lushivie.com is here to help': 'Help@lushivie.com पर हमारी टीम आपकी मदद के लिए यहाँ है',
          'Your Name': 'आपका नाम',
          'Your Email (Optional)': 'आपका ईमेल (वैकल्पिक)',
          'Subject': 'विषय',
          'Your Message': 'आपका संदेश',
          'Send Message': 'संदेश भेजें',
          'Sending...': 'भेजा जा रहा है...',
          'Message Sent!': 'संदेश भेजा गया!',
          'Thank you for reaching out. We\'ll respond within 24 hours.': 'संपर्क करने के लिए धन्यवाद। हम 24 घंटों के भीतर जवाब देंगे।',
          'Send Another Message': 'दूसरा संदेश भेजें',
          'Questions about beauty products or collaborations? We respond within 24 hours.': 'ब्यूटी प्रोडक्ट्स या सहयोग के बारे में सवाल? हम 24 घंटों के भीतर जवाब देते हैं।',
        },

      };

      let translatedText = text;

      // Check fallback translations first
      if (fallbackTranslations[targetLang] && fallbackTranslations[targetLang][text]) {
        translatedText = fallbackTranslations[targetLang][text];
      } else {
        try {
          // Try to call the API with better error handling
          const response = await fetch('/api/google-translate', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              text: text,
              from: sourceLang,
              to: targetLang
            })
          });

          if (response.ok) {
            const data = await response.json();
            if (data.success && data.translatedText && data.translatedText !== text) {
              translatedText = data.translatedText;
            }
          }
        } catch (apiError) {
          console.warn('Translation API unavailable, using original text:', apiError);
          // Just use original text if API fails
        }
      }

      // Cache the translation
      const newCache = { ...translationCache, [cacheKey]: translatedText };
      setTranslationCache(newCache);
      try {
        localStorage.setItem('lushivie-translation-cache', JSON.stringify(newCache));
      } catch (storageError) {
        console.warn('Failed to save translation cache:', storageError);
      }

      return translatedText;
    } catch (error) {
      console.warn('Translation error, returning original text:', error);
      return text; // Always return original text if everything fails
    }
  };

  // Enhanced translation function that works for all languages
  const translatePage = async (targetLang) => {
    if (targetLang === 'en') {
      // Restore original content
      try {
        window.location.reload();
      } catch (reloadError) {
        console.warn('Reload failed, manually resetting:', reloadError);
        setIsTranslating(false);
      }
      return;
    }

    setIsTranslating(true);

    try {
      // Store original content before translation
      if (!window.originalContent) {
        window.originalContent = new Map();
      }

      // Get all text elements that should be translated - comprehensive selection
      const textElements = document.querySelectorAll(
        'h1, h2, h3, h4, h5, h6, p, span, div, button, a, label, input[placeholder], textarea[placeholder], li, td, th, blockquote, figcaption, nav, section, article, aside, footer, header, main, time, em, strong, small, mark, del, ins, sub, sup, title, img[alt], [aria-label]'
      );

      const translations = [];
      const maxElements = 500; // Further increased for better coverage
      let processedCount = 0;

      for (let element of textElements) {
        if (processedCount >= maxElements) break;

        try {
          // Skip elements that shouldn't be translated
          if (element.hasAttribute('data-no-translate') ||
              element.closest('[data-no-translate]') ||
              element.tagName === 'SCRIPT' ||
              element.tagName === 'STYLE' ||
              element.classList.contains('no-translate') ||
              element.classList.contains('highlight') ||
              element.classList.contains('code')) {
            continue;
          }

          // Handle different types of content
          let originalText = '';
          let isPlaceholder = false;
          let isTitle = false;
          let isAriaLabel = false;
          let isAltText = false;

          if (element.placeholder) {
            originalText = element.placeholder.trim();
            isPlaceholder = true;
          } else if (element.title) {
            originalText = element.title.trim();
            isTitle = true;
          } else if (element.hasAttribute('aria-label')) {
            originalText = element.getAttribute('aria-label').trim();
            isAriaLabel = true;
          } else if (element.tagName === 'IMG' && element.alt) {
            originalText = element.alt.trim();
            isAltText = true;
          } else if (element.children.length === 0) {
            // Only translate if element has no child elements (leaf nodes)
            originalText = element.textContent?.trim();
          } else {
            // For elements with children, get direct text content
            const directText = Array.from(element.childNodes)
              .filter(node => node.nodeType === Node.TEXT_NODE)
              .map(node => node.textContent.trim())
              .filter(text => text.length > 0)
              .join(' ');

            if (directText && element.children.length <= 3) {
              originalText = directText;
            }
          }

          if (originalText &&
              originalText.length > 0 &&
              originalText.length < 1000 && // Increased limit
              !/^[0-9\s\W\-_+=<>]*$/.test(originalText) && // Skip numbers and symbols only
              !originalText.includes('@') && // Skip emails
              !originalText.startsWith('http') && // Skip URLs
              !originalText.startsWith('www.') && // Skip websites
              !originalText.startsWith('#') && // Skip hashtags
              !originalText.startsWith('data:') && // Skip data URLs
              originalText !== '•' && // Skip bullet points
              originalText !== '...' && // Skip ellipsis
              originalText !== '×' && // Skip close buttons
              originalText.length > 1) { // Minimum length

            // Store original content
            const elementId = `elem_${processedCount}`;
            if (!window.originalContent.has(elementId)) {
              window.originalContent.set(elementId, {
                element,
                originalText,
                isPlaceholder,
                isTitle,
                isAriaLabel,
                isAltText
              });
            }

            const translatedText = await translateText(originalText, targetLang);
            if (translatedText && translatedText !== originalText) {
              translations.push({
                element,
                originalText,
                translatedText,
                isPlaceholder,
                isTitle,
                isAriaLabel,
                isAltText
              });
            }
            processedCount++;
          }
        } catch (elementError) {
          console.warn('Error processing element:', elementError);
          continue;
        }
      }

      // Apply translations with error handling
      translations.forEach(({ element, translatedText, isPlaceholder, isTitle, isAriaLabel, isAltText }) => {
        try {
          if (translatedText && element && document.contains(element)) {
            if (isPlaceholder) {
              element.placeholder = translatedText;
            } else if (isTitle) {
              element.title = translatedText;
            } else if (isAriaLabel) {
              element.setAttribute('aria-label', translatedText);
            } else if (isAltText) {
              element.alt = translatedText;
            } else if (element.children.length === 0) {
              element.textContent = translatedText;
            } else {
              // For elements with children, update only text nodes
              const walker = document.createTreeWalker(
                element,
                NodeFilter.SHOW_TEXT,
                {
                  acceptNode: function(node) {
                    return node.parentNode === element ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT;
                  }
                }
              );

              let textNode;
              while (textNode = walker.nextNode()) {
                if (textNode.textContent.trim().length > 0) {
                  textNode.textContent = translatedText;
                  break;
                }
              }
            }
          }
        } catch (applyError) {
          console.warn('Error applying translation:', applyError);
        }
      });

      // Translate meta content and page title
      const pageTitle = document.title;
      if (pageTitle && pageTitle.length > 0) {
        const translatedTitle = await translateText(pageTitle, targetLang);
        if (translatedTitle && translatedTitle !== pageTitle) {
          document.title = translatedTitle;
        }
      }

      // Translate common UI elements that might be dynamically added
      setTimeout(async () => {
        const dynamicElements = document.querySelectorAll('[data-translate-dynamic]');
        for (const element of dynamicElements) {
          const text = element.textContent?.trim();
          if (text && text.length > 0) {
            const translated = await translateText(text, targetLang);
            if (translated && translated !== text) {
              element.textContent = translated;
            }
          }
        }
      }, 1000);

    } catch (error) {
      console.error('Page translation error:', error);
    } finally {
      setTimeout(() => {
        setIsTranslating(false);
      }, 1000); // Increased timeout for better completion
    }
  };

  const handleLanguageChange = async (langCode) => {
    try {
      setSelectedLanguage(langCode);
      setIsDropdownOpen(false);

      try {
        localStorage.setItem('lushivie-language', langCode);
      } catch (storageError) {
        console.warn('Failed to save language preference:', storageError);
      }

      if (langCode !== 'en') {
        await translatePage(langCode);
      } else {
        try {
          window.location.reload(); // Reload to restore original content
        } catch (reloadError) {
          console.warn('Page reload failed:', reloadError);
        }
      }
    } catch (error) {
      console.error('Language change failed:', error);
      setIsTranslating(false);
      // Don't crash the app, just log the error
    }
  };

  const currentLanguage = languages.find(lang => lang.code === selectedLanguage);

  return (
    <div className={`fixed bottom-4 right-4 z-50 ${className}`} ref={dropdownRef} data-no-translate>
      {/* Language Selector Button */}
      <button
        onClick={() => setIsDropdownOpen(!isDropdownOpen)}
        disabled={isTranslating}
        className="bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700 rounded-full p-2 shadow-lg border border-gray-200 dark:border-gray-700 transition-all duration-300 group flex items-center space-x-1"
        data-no-translate
      >
        {isTranslating ? (
          <Loader className="animate-spin text-rose-500" size={16} />
        ) : (
          <Globe className="text-rose-500 group-hover:text-rose-600 transition-colors" size={16} />
        )}

        <span className="text-sm">{currentLanguage?.flag}</span>

        <ChevronDown
          className={`text-gray-400 transition-transform duration-200 ${
            isDropdownOpen ? 'rotate-180' : ''
          }`}
          size={12}
        />
      </button>

      {/* Dropdown Menu */}
      {isDropdownOpen && (
        <div className="absolute bottom-full right-0 mb-2 bg-white dark:bg-gray-800 rounded-xl shadow-xl border border-gray-200 dark:border-gray-700 py-1 min-w-[200px] max-h-80 overflow-y-auto">
          <div className="px-2 py-1 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider border-b border-gray-100 dark:border-gray-700">
            Language
          </div>

          {languages.map((language) => (
            <button
              key={language.code}
              onClick={() => handleLanguageChange(language.code)}
              className={`w-full flex items-center justify-between px-3 py-2 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors text-left ${
                selectedLanguage === language.code
                  ? 'bg-rose-50 dark:bg-rose-900/20 text-rose-600 dark:text-rose-400'
                  : 'text-gray-700 dark:text-gray-300'
              }`}
            >
              <div className="flex items-center space-x-2">
                <span className="text-sm">{language.flag}</span>
                <span className="text-sm font-medium">{language.name}</span>
              </div>

              {selectedLanguage === language.code && (
                <Check size={12} className="text-rose-500" />
              )}
            </button>
          ))}

          <div className="border-t border-gray-100 dark:border-gray-700 mt-1 pt-1 px-3 py-1">
            <p className="text-xs text-gray-500 dark:text-gray-400">
              Using MyMemory Translation
            </p>
          </div>
        </div>
      )}

      {/* Translation Status */}
      {isTranslating && (
        <div className="absolute bottom-full right-0 mb-2 bg-rose-50 dark:bg-rose-900/20 text-rose-600 dark:text-rose-400 px-3 py-1 rounded-lg shadow-lg border border-rose-200 dark:border-rose-800 text-xs font-medium">
          Translating...
        </div>
      )}
    </div>
  );
};

export default LanguageTranslator;