import React, { useState, useEffect } from 'react';
import { Lock, Star, Mail } from 'lucide-react';

const PremiumContentRenderer = ({ content }) => {
  const [isSubscribed, setIsSubscribed] = useState(false);

  useEffect(() => {
    // Check if user is subscribed to newsletter
    const checkSubscription = () => {
      try {
        // Check if user email exists in newsletter subscribers
        const userEmail = localStorage.getItem('lushivie-user-email') || 
                          sessionStorage.getItem('lushivie-user-email');

        if (!userEmail) {
          setIsSubscribed(false);
          return;
        }

        // Check if user is in newsletter subscribers
        const subscribers = JSON.parse(localStorage.getItem('lushivie-newsletter-subscribers') || '[]');
        const isUserSubscribed = subscribers.some(subscriber => 
          subscriber.email && subscriber.email.toLowerCase() === userEmail.toLowerCase()
        );

        // Also check admin emails (always have access)
        const adminEmails = [
          'help@lushivie.com', 
          'support@lushivie.com',
          'glamour.bymaanya@gmail.com'
        ];

        const isAdmin = adminEmails.includes(userEmail.toLowerCase());

        setIsSubscribed(isUserSubscribed || isAdmin);
      } catch (error) {
        console.error('Error checking subscription:', error);
        setIsSubscribed(false);
      }
    };

    checkSubscription();

    // Listen for subscription updates
    const handleSubscriptionUpdate = () => {
      checkSubscription();
    };

    window.addEventListener('newsletterSubscribed', handleSubscriptionUpdate);
    window.addEventListener('storage', handleSubscriptionUpdate);

    return () => {
      window.removeEventListener('newsletterSubscribed', handleSubscriptionUpdate);
      window.removeEventListener('storage', handleSubscriptionUpdate);
    };
  }, []);

  // If no premium sections found, render normally
  if (!content || !content.includes('<!-- PREMIUM_START -->')) {
    return <div dangerouslySetInnerHTML={{ __html: content }} />;
  }

  // Split content by premium markers
  const premiumPattern = /<!--\s*PREMIUM_START\s*-->([\s\S]*?)<!--\s*PREMIUM_END\s*-->/g;
  const parts = [];
  let lastIndex = 0;
  let match;

  while ((match = premiumPattern.exec(content)) !== null) {
    // Add content before premium section
    if (match.index > lastIndex) {
      const beforeContent = content.slice(lastIndex, match.index);
      if (beforeContent.trim()) {
        parts.push({ type: 'regular', content: beforeContent });
      }
    }

    // Add premium section
    parts.push({ type: 'premium', content: match[1] });
    lastIndex = match.index + match[0].length;
  }

  // Add remaining content
  if (lastIndex < content.length) {
    const remainingContent = content.slice(lastIndex);
    if (remainingContent.trim()) {
      parts.push({ type: 'regular', content: remainingContent });
    }
  }

  return (
    <div>
      {parts.map((part, index) => (
        <React.Fragment key={index}>
          {part.type === 'premium' ? (
            isSubscribed ? (
              <div dangerouslySetInnerHTML={{ __html: part.content }} />
            ) : (
              <div className="relative bg-gradient-to-br from-rose-50 to-pink-50 dark:from-rose-950/20 dark:to-pink-950/20 rounded-2xl p-8 border-2 border-rose-200 dark:border-rose-800/50 backdrop-blur-sm">
                <div className="absolute inset-0 bg-gradient-to-br from-rose-100/50 to-pink-100/50 dark:from-rose-900/20 dark:to-pink-900/20 rounded-2xl"></div>
                <div className="relative z-10 text-center">
                  <div className="w-16 h-16 bg-gradient-to-br from-rose-500 to-pink-600 rounded-full flex items-center justify-center mx-auto mb-6 shadow-lg">
                    <Lock className="text-white" size={24} />
                  </div>
                  <h3 className="text-2xl font-bold mb-4 bg-gradient-to-r from-rose-600 to-pink-600 bg-clip-text text-transparent font-playfair">
                    Subscriber Exclusive Content
                  </h3>
                  <p className="text-gray-700 dark:text-gray-300 mb-6 text-lg leading-relaxed">
                    This exclusive content is available to our newsletter subscribers. Subscribe to unlock expert beauty insights, detailed reviews, and insider tips!
                  </p>
                  <div className="flex flex-col sm:flex-row gap-4 justify-center">
                    <button 
                      onClick={() => {
                        // Scroll to newsletter section
                        const newsletterSection = document.querySelector('#newsletter') || 
                                                document.querySelector('.newsletter') ||
                                                document.querySelector('[data-section="newsletter"]');
                        if (newsletterSection) {
                          newsletterSection.scrollIntoView({ behavior: 'smooth' });
                        } else {
                          // If no newsletter section found, show alert
                          alert('Please scroll down to find the newsletter subscription section!');
                        }
                      }}
                      className="inline-flex items-center space-x-2 px-8 py-4 bg-gradient-to-r from-rose-500 to-pink-600 text-white rounded-xl font-semibold hover:from-rose-600 hover:to-pink-700 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105"
                    >
                      <Mail size={20} />
                      <span>Subscribe to Newsletter</span>
                    </button>
                    <button 
                      onClick={() => window.dispatchEvent(new CustomEvent('openAuthModal'))}
                      className="inline-flex items-center space-x-2 px-8 py-4 bg-white dark:bg-gray-800 text-rose-600 dark:text-rose-400 border-2 border-rose-300 dark:border-rose-700 rounded-xl font-semibold hover:bg-rose-50 dark:hover:bg-rose-950/30 transition-all duration-300"
                    >
                      <Star size={20} />
                      <span>Sign In</span>
                    </button>
                  </div>
                </div>
              </div>
            )
          ) : (
            <div dangerouslySetInnerHTML={{ __html: part.content }} />
          )}
        </React.Fragment>
      ))}
    </div>
  );
};

export default PremiumContentRenderer;