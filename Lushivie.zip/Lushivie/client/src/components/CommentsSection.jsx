import { useState, useEffect } from 'react';
import { MessageCircle, Send, Heart, Reply, User, Trash2, ChevronUp, ChevronDown, TrendingUp , X } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from './Toast';
import {
  getCurrentUserProfileImage,
  getCommentAuthorProfileImage,
  getInitialsFromName,
  getUserProfile,
  getUserDisplayName
} from '../utils/imageUpload';



export default function CommentsSection({ postId }) {
  const { user } = useAuth();
  const toast = useToast();
  const [comments, setComments] = useState([]);
  const [newComment, setNewComment] = useState('');
  const [loading, setLoading] = useState(false);
  const [showAuthPrompt, setShowAuthPrompt] = useState(false);
  const [sortBy, setSortBy] = useState('newest'); // newest, oldest, top
  const [userVotes, setUserVotes] = useState({}); // Track user votes
  const [replyingTo, setReplyingTo] = useState(null); // Track which comment we're replying to
  const [replyText, setReplyText] = useState(''); // Reply text

  useEffect(() => {
    fetchComments();
    loadUserVotes();
  }, [postId]);

  // Listen for profile updates to refresh comments
  useEffect(() => {
    const handleProfileUpdate = () => {
      // Refresh comments to show updated profile images
      fetchComments();
    };

    const eventTypes = [
      'profileUpdated',
      'adminProfileUpdated',
      'adminProfilePersisted',
      'userProfileUpdated',
      'storage',
      'lushivie-profile-changed',
      'globalAdminProfileUpdated',
      'adminProfileGlobalSync',
      'maanyaProfileUpdated',
      'globalAuthorProfileSync',
      'visitorProfileRefresh',
      'imgbbImageUploaded',
      'firestoreProfileUpdated',
      'imgbbProfileSync'
    ];

    eventTypes.forEach(eventType => {
      window.addEventListener(eventType, handleProfileUpdate);
    });

    return () => {
      eventTypes.forEach(eventType => {
        window.removeEventListener(eventType, handleProfileUpdate);
      });
    };
  }, []);

  const loadUserVotes = () => {
    try {
      const saved = localStorage.getItem(`lushivie-comment-votes-${postId}`);
      if (saved) {
        setUserVotes(JSON.parse(saved));
      }
    } catch (error) {
      console.error('Error loading user votes:', error);
    }
  };

  const saveUserVotes = (votes) => {
    try {
      localStorage.setItem(`lushivie-comment-votes-${postId}`, JSON.stringify(votes));
      setUserVotes(votes);
    } catch (error) {
      console.error('Error saving user votes:', error);
    }
  };

  const fetchComments = async () => {
    try {
      const response = await fetch(`/api/posts/${postId}/comments`);
      const data = await response.json();

      // Add vote counts to comments if they don't exist
      const commentsWithVotes = data.map(comment => ({
        ...comment,
        upvotes: comment.upvotes || 0,
        downvotes: comment.downvotes || 0,
        score: (comment.upvotes || 0) - (comment.downvotes || 0)
      }));

      setComments(commentsWithVotes);
    } catch (error) {
      console.error('Error fetching comments:', error);
    }
  };

  const handleSubmitComment = async (e) => {
    e.preventDefault();

    if (!user) {
      setShowAuthPrompt(true);
      return;
    }

    if (!newComment.trim()) return;

    setLoading(true);
    try {
      // Get user profile image with ImgBB support
      let userProfileImage = getCurrentUserProfileImage(user.email, user.displayName);
      if (!userProfileImage) {
        // Try universal profile getter for ImgBB uploaded images
        userProfileImage = getUniversalProfileImage(user.email, user.displayName, user.displayName);
      }
      if (!userProfileImage) {
        userProfileImage = user.photoURL;
      }

      const response = await fetch(`/api/posts/${postId}/comments`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          author: getUserDisplayName(user.email, user.displayName),
          content: newComment.trim(),
          userId: user.uid,
          userEmail: user.email,
          userPhoto: userProfileImage,
          profileImage: userProfileImage,
          displayName: user.displayName,
          upvotes: 0,
          downvotes: 0,
          score: 0,
          parentId: replyingTo,
          // Enhanced profile data storage
          authorProfileData: {
            profileImage: userProfileImage,
            userPhoto: userProfileImage,
            email: user.email,
            displayName: user.displayName,
            uid: user.uid
          }
        })
      });

      if (response.ok) {
        setNewComment('');
        setReplyingTo(null);
        setReplyText('');
        fetchComments();
        toast.success('Comment posted successfully! 💬');
      }
    } catch (error) {
      console.error('Error posting comment:', error);
      toast.error('Failed to post comment');
    } finally {
      setLoading(false);
    }
  };

  const handleReply = (commentId, authorName) => {
    setReplyingTo(commentId);
    setReplyText(`@${authorName} `);
    setNewComment(`@${authorName} `);
  };

  const cancelReply = () => {
    setReplyingTo(null);
    setReplyText('');
    setNewComment('');
  };

  const handleVote = async (commentId, voteType) => {
    if (!user) {
      setShowAuthPrompt(true);
      return;
    }

    const currentVote = userVotes[commentId];
    let newVoteType = null;

    // Determine new vote type
    if (currentVote === voteType) {
      // Remove vote if clicking the same vote type
      newVoteType = null;
    } else {
      // Set new vote type
      newVoteType = voteType;
    }

    // Update local state optimistically
    const newUserVotes = { ...userVotes };
    if (newVoteType) {
      newUserVotes[commentId] = newVoteType;
    } else {
      delete newUserVotes[commentId];
    }
    saveUserVotes(newUserVotes);

    // Update comment votes
    setComments(prevComments =>
      prevComments.map(comment => {
        if (comment.id !== commentId) return comment;

        let upvotes = comment.upvotes || 0;
        let downvotes = comment.downvotes || 0;

        // Remove previous vote
        if (currentVote === 'upvote') upvotes--;
        if (currentVote === 'downvote') downvotes--;

        // Add new vote
        if (newVoteType === 'upvote') upvotes++;
        if (newVoteType === 'downvote') downvotes++;

        return {
          ...comment,
          upvotes,
          downvotes,
          score: upvotes - downvotes
        };
      })
    );

    // In a real app, you would send this to your backend
    try {
      await fetch(`/api/posts/${postId}/comments/${commentId}/vote`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          voteType: newVoteType,
          userId: user.uid
        })
      });
    } catch (error) {
      console.error('Error voting on comment:', error);
      // Revert optimistic update on error
      fetchComments();
      loadUserVotes();
    }
  };

  const handleDeleteComment = async (commentId) => {
    if (!user) return;

    // Check if user is owner (admin emails)
    const adminEmails = ['help@lushivie.com', 'glamour.bymaanya@gmail.com'];
    const isOwner = adminEmails.includes(user.email?.toLowerCase());

    if (!isOwner) {
      toast.error('Only the owner can delete comments');
      return;
    }

    // Use toast confirmation instead of window.confirm
    toast.confirm(
      'Delete this comment? This action cannot be undone.',
      async () => {
        try {
          const response = await fetch(`/api/posts/${postId}/comments/${commentId}`, {
            method: 'DELETE',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ userId: user.uid })
          });

          if (response.ok) {
            // Remove comment from local state
            setComments(prevComments => prevComments.filter(c => c.id !== commentId));

            // Also remove from user votes
            const newUserVotes = { ...userVotes };
            delete newUserVotes[commentId];
            saveUserVotes(newUserVotes);

            toast.success('Comment deleted successfully! 🗑️');
          } else {
            toast.error('Failed to delete comment');
          }
        } catch (error) {
          console.error('Error deleting comment:', error);
          toast.error('Failed to delete comment');
        }
      }
    );
  };

  const getSortedComments = () => {
    const sorted = [...comments];
    switch (sortBy) {
      case 'top':
        return sorted.sort((a, b) => b.score - a.score);
      case 'oldest':
        return sorted.sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt));
      case 'newest':
      default:
        return sorted.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    }
  };

  const getVoteButtonClass = (commentId, voteType) => {
    const userVote = userVotes[commentId];
    const isActive = userVote === voteType;
    const baseClass = "flex items-center justify-center w-8 h-8 rounded-lg transition-all duration-200 text-sm font-medium";

    if (voteType === 'upvote') {
      return `${baseClass} ${isActive
        ? 'bg-orange-500 text-white shadow-lg transform scale-110'
        : 'text-gray-400 hover:bg-orange-100 hover:text-orange-500 dark:hover:bg-orange-900/20'}`;
    } else {
      return `${baseClass} ${isActive
        ? 'bg-blue-500 text-white shadow-lg transform scale-110'
        : 'text-gray-400 hover:bg-blue-100 hover:text-blue-500 dark:hover:bg-blue-900/20'}`;
    }
  };

  return (
    <div className="max-w-3xl mx-auto mt-12 px-4">
      <div className="bg-white/80 dark:bg-gray-900/80 backdrop-blur-xl rounded-2xl shadow-2xl border border-gray-200/50 dark:border-gray-700/50 overflow-hidden">

        {/* Header */}
        <div className="bg-gradient-to-r from-rose-500/10 to-pink-500/10 dark:from-rose-900/30 dark:to-pink-900/30 px-6 py-4 border-b border-gray-200/50 dark:border-gray-700/50">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-br from-rose-500 to-pink-600 rounded-xl flex items-center justify-center shadow-lg">
                <MessageCircle className="text-white" size={20} />
              </div>
              <div>
                <h3 className="text-xl font-bold bg-gradient-to-r from-rose-600 to-pink-600 bg-clip-text text-transparent font-playfair">
                  Comments ({comments.length})
                </h3>
              </div>
            </div>

            {/* Compact Sort Dropdown */}
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="text-sm bg-white/80 dark:bg-gray-800/80 border border-gray-300 dark:border-gray-600 rounded-lg px-3 py-1.5 text-gray-700 dark:text-gray-300 focus:outline-none focus:ring-2 focus:ring-rose-500/50 cursor-pointer"
            >
              <option value="newest">Newest</option>
              <option value="oldest">Oldest</option>
              <option value="top">Top</option>
            </select>
          </div>
        </div>

        {/* Comment Form */}
        <div className="p-6 bg-gray-50/50 dark:bg-gray-800/30 border-b border-gray-200/50 dark:border-gray-700/50">
          <form onSubmit={handleSubmitComment} className="space-y-4">
            {/* Reply Context */}
            {replyingTo && (
              <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-3 flex items-center justify-between">
                <span className="text-sm text-blue-700 dark:text-blue-300">
                  <Reply size={14} className="inline mr-1" />
                  Replying to comment
                </span>
                <button
                  type="button"
                  onClick={cancelReply}
                  className="text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-200"
                >
                  <X size={16} />
                </button>
              </div>
            )}

            <div className="flex items-start space-x-3">
              {/* User Avatar */}
              <div className="flex-shrink-0">
                {user ? (
                  <div className="w-10 h-10 rounded-full overflow-hidden border-2 border-rose-300/50 shadow-md">
                    {(() => {
                      // Get current user's profile image with enhanced fallback
                      let currentUserImage = getCurrentUserProfileImage(user.email, user.displayName);
                      if (!currentUserImage) {
                        currentUserImage = user.photoURL;
                      }

                      return currentUserImage ? (
                        <img
                          src={currentUserImage}
                          alt={user.displayName || user.email}
                          className="w-full h-full object-cover"
                          onError={(e) => {
                            e.target.parentElement.innerHTML = `<div class="w-full h-full bg-gradient-to-br from-rose-400 to-pink-600 flex items-center justify-center"><span class="text-white font-bold text-xs">${getInitialsFromName(user.displayName || user.email)}</span></div>`;
                          }}
                        />
                      ) : (
                        <div className="w-full h-full bg-gradient-to-br from-rose-400 to-pink-600 flex items-center justify-center">
                          <span className="text-white font-bold text-xs">
                            {getInitialsFromName(user.displayName || user.email)}
                          </span>
                        </div>
                      );
                    })()}
                  </div>
                ) : (
                  <div className="w-10 h-10 bg-gray-300 dark:bg-gray-600 rounded-full flex items-center justify-center">
                    <User size={16} className="text-gray-500" />
                  </div>
                )}
              </div>

              {/* Input Area */}
              <div className="flex-1">
                <textarea
                  value={newComment}
                  onChange={(e) => setNewComment(e.target.value)}
                  placeholder={user ? (replyingTo ? "Write your reply..." : "Share your thoughts...") : "Please sign in to comment"}
                  disabled={!user}
                  className="w-full p-3 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-lg focus:border-rose-400 dark:focus:border-rose-500 transition-all resize-none text-gray-800 dark:text-white placeholder-gray-500 dark:placeholder-gray-400 disabled:opacity-60"
                  rows={2}
                />
              </div>
            </div>

            {/* Footer */}
            <div className="flex items-center justify-between">
              <div className="text-sm text-gray-600 dark:text-gray-400">
                {user ? (
                  <span>Commenting as <span className="text-rose-600 dark:text-rose-400 font-medium">{getUserDisplayName(user.email, user.displayName)}</span></span>
                ) : (
                  <button
                    type="button"
                    onClick={() => {
                      setShowAuthPrompt(false);
                      window.dispatchEvent(new CustomEvent('openAuthModal'));
                    }}
                    className="text-rose-600 hover:text-rose-700 dark:text-rose-400 font-medium"
                  >
                    Sign in to comment
                  </button>
                )}
              </div>
              <button
                type="submit"
                disabled={!user || !newComment.trim() || loading}
                className="bg-gradient-to-r from-rose-500 to-pink-600 hover:from-rose-600 hover:to-pink-700 text-white px-5 py-2 rounded-lg font-medium flex items-center space-x-2 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-300 shadow-md hover:shadow-lg text-sm"
              >
                <Send size={14} />
                <span>{loading ? 'Posting...' : 'Post'}</span>
              </button>
            </div>
          </form>
        </div>

        {/* Comments List */}
        <div className="max-h-96 overflow-y-auto">
          {getSortedComments().map((comment) => {
            const userVote = userVotes[comment.id];
            const score = comment.score || 0;

            // Enhanced profile image retrieval with ImgBB support
            const commentAuthorImage = getCommentAuthorProfileImage(comment.userEmail || comment.authorEmail, comment.author || comment.displayName) || 
                                     comment.profileImage || 
                                     comment.userPhoto || 
                                     comment.imgbbProfileImage;

            // Check if current user is owner (can delete comments)
            const adminEmails = ['help@lushivie.com', 'glamour.bymaanya@gmail.com'];
            const isOwner = user && adminEmails.includes(user.email?.toLowerCase());

            return (
              <div key={comment.id} className="p-4 border-b border-gray-200/50 dark:border-gray-700/50 last:border-b-0 hover:bg-gray-50/50 dark:hover:bg-gray-800/30 transition-all">
                <div className="flex space-x-3">

                  {/* Vote Section - Compact */}
                  <div className="flex flex-col items-center space-y-1 flex-shrink-0">
                    <button
                      onClick={() => handleVote(comment.id, 'upvote')}
                      className={getVoteButtonClass(comment.id, 'upvote')}
                      title="Upvote"
                    >
                      <ChevronUp size={16} />
                    </button>

                    <div className={`text-xs font-bold px-2 py-0.5 rounded-full min-w-[2rem] text-center ${
                      score > 0
                        ? 'text-orange-600 bg-orange-100 dark:bg-orange-900/30 dark:text-orange-400'
                        : score < 0
                          ? 'text-blue-600 bg-blue-100 dark:bg-blue-900/30 dark:text-blue-400'
                          : 'text-gray-500 bg-gray-100 dark:bg-gray-700'
                    }`}>
                      {score > 0 ? '+' : ''}{score}
                    </div>

                    <button
                      onClick={() => handleVote(comment.id, 'downvote')}
                      className={getVoteButtonClass(comment.id, 'downvote')}
                      title="Downvote"
                    >
                      <ChevronDown size={16} />
                    </button>
                  </div>

                  {/* Comment Content */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-2">
                        {/* User Avatar */}
                        <div className="w-8 h-8 rounded-full overflow-hidden border border-gray-300 dark:border-gray-600">
                          {commentAuthorImage ? (
                            <img
                              src={commentAuthorImage}
                              alt={comment.author}
                              className="w-full h-full object-cover"
                              onError={(e) => {
                                e.target.parentElement.innerHTML = `<div class="w-full h-full bg-gradient-to-br from-rose-400 to-pink-600 flex items-center justify-center"><span class="text-white font-bold text-xs">${comment.author?.charAt(0)?.toUpperCase() || 'U'}</span></div>`;
                              }}
                            />
                          ) : (
                            <div className="w-full h-full bg-gradient-to-br from-rose-400 to-pink-600 flex items-center justify-center">
                              <span className="text-white font-bold text-xs">
                                {getInitialsFromName(comment.author)}
                              </span>
                            </div>
                          )}
                        </div>

                        {/* User Info */}
                        <div className="flex items-center space-x-2 flex-wrap">
                          <span className="font-semibold text-gray-900 dark:text-white text-sm">
                            {comment.displayName || comment.author}
                          </span>
                          <span className="text-xs text-gray-500 dark:text-gray-400">
                            {new Date(comment.createdAt).toLocaleDateString('en-IN', {
                              month: 'short',
                              day: 'numeric',
                              year: 'numeric'
                            })}
                          </span>
                          {score > 5 && (
                            <div className="flex items-center space-x-1 text-xs bg-gradient-to-r from-orange-100 to-yellow-50 text-orange-600 px-1.5 py-0.5 rounded-full dark:from-orange-900/30 dark:to-yellow-900/30 dark:text-orange-400">
                              <TrendingUp size={10} />
                              <span>Popular</span>
                            </div>
                          )}
                        </div>
                      </div>


                    </div>

                    {/* Comment Text */}
                    <div className="bg-gray-100/80 dark:bg-gray-700/50 rounded-lg px-3 py-2 mb-2">
                      <p className="text-gray-800 dark:text-gray-200 text-sm leading-relaxed break-words">{comment.content}</p>
                    </div>

                    {/* Comment Actions */}
                    <div className="flex items-center justify-between text-xs text-gray-500 dark:text-gray-400">
                      <div className="flex items-center space-x-4">
                        <button
                          onClick={() => handleReply(comment.id, comment.author)}
                          className="flex items-center space-x-1 hover:text-rose-600 dark:hover:text-rose-400 transition-colors"
                        >
                          <Reply size={12} />
                          <span>Reply</span>
                        </button>
                        <span>{comment.upvotes || 0} upvotes</span>
                        <span>{comment.downvotes || 0} downvotes</span>

                        {/* Delete button in horizontal layout */}
                        {isOwner && (
                          <button
                            onClick={() => handleDeleteComment(comment.id)}
                            className="flex items-center space-x-1 text-red-500 hover:text-red-700 hover:bg-red-50 dark:hover:bg-red-900/20 px-2 py-1 rounded-md transition-colors"
                            title="Delete comment"
                          >
                            <Trash2 size={12} />
                            <span>Delete</span>
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}

          {comments.length === 0 && (
            <div className="text-center py-12">
              <div className="w-16 h-16 bg-gradient-to-br from-gray-100 to-gray-200 dark:from-gray-700 dark:to-gray-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <MessageCircle className="text-gray-400" size={24} />
              </div>
              <h3 className="text-lg font-bold mb-2 text-gray-800 dark:white font-playfair">No comments yet</h3>
              <p className="text-gray-600 dark:text-gray-400 text-sm">Be the first to share your thoughts!</p>
            </div>
          )}
        </div>
      </div>

      {/* Auth Prompt Modal */}
      {showAuthPrompt && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div className="bg-white dark:bg-gray-900 rounded-2xl p-6 max-w-sm w-full shadow-2xl border border-gray-200 dark:border-gray-700">
            <div className="text-center mb-6">
              <div className="w-16 h-16 bg-gradient-to-br from-rose-500 to-pink-600 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-xl">
                <MessageCircle className="text-white" size={24} />
              </div>
              <h3 className="text-2xl font-bold bg-gradient-to-r from-rose-600 to-pink-600 bg-clip-text text-transparent font-playfair mb-2">Join the Conversation</h3>
              <p className="text-gray-600 dark:text-gray-300 text-sm">Sign in to comment and vote</p>
            </div>
            <div className="flex space-x-3">
              <button
                onClick={() => setShowAuthPrompt(false)}
                className="flex-1 px-4 py-2 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-lg font-medium hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors text-sm"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  setShowAuthPrompt(false);
                  window.dispatchEvent(new CustomEvent('openAuthModal'));
                }}
                className="flex-1 bg-gradient-to-r from-rose-500 to-pink-600 hover:from-rose-600 hover:to-pink-700 text-white px-4 py-2 rounded-lg font-medium transition-all duration-300 shadow-md hover:shadow-lg text-sm"
              >
                Sign In
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}