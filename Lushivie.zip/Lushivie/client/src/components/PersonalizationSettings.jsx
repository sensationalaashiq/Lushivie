import React, { useState, useEffect } from 'react';
import { X, Settings, Palette, Eye, Clock, TrendingUp, Zap, Moon, Sun, Monitor, Type, Bell, Play, Sparkles } from 'lucide-react';
import { getPreferences, updatePreferences } from '../utils/personalization';
import { useToast } from './Toast';

export default function PersonalizationSettings({ isOpen, onClose }) {
  const [preferences, setPreferences] = useState({
    theme: 'auto',
    contentType: 'mixed',
    readingSpeed: 'medium',
    notifications: true,
    autoplay: false,
    fontSize: 'medium'
  });

  const toast = useToast();

  useEffect(() => {
    if (isOpen) {
      try {
        const saved = getPreferences();
        if (saved && typeof saved === 'object') {
          setPreferences({
            theme: saved.theme || 'light',
            contentType: saved.contentPreferences?.favoriteCategories?.[0] || 'mixed',
            readingSpeed: 'medium',
            notifications: saved.notifications?.newsletter !== false,
            autoplay: false,
            fontSize: saved.displayPreferences?.fontSize || 'medium'
          });
        }
      } catch (error) {
        console.error('Error loading preferences:', error);
        // Reset to defaults on error
        setPreferences({
          theme: 'light',
          contentType: 'mixed',
          readingSpeed: 'medium',
          notifications: true,
          autoplay: false,
          fontSize: 'medium'
        });
      }
    }
  }, [isOpen]);

  const handleSave = () => {
    try {
      updatePreferences({
        contentPreferences: {
          favoriteCategories: preferences.contentType === 'mixed'
            ? ['skincare', 'makeup', 'luxury']
            : [preferences.contentType]
        },
        displayPreferences: {
          fontSize: preferences.fontSize
        },
        notifications: {
          newsletter: preferences.notifications
        }
      });

      toast?.success?.('✨ Preferences saved successfully!', 2000);
      onClose();
    } catch (error) {
      console.error('Error saving preferences:', error);
      toast?.error?.('Failed to save preferences', 2000);
    }
  };

  const handleReset = () => {
    const defaultPrefs = {
      theme: 'auto',
      contentType: 'mixed',
      readingSpeed: 'medium',
      notifications: true,
      autoplay: false,
      fontSize: 'medium'
    };
    setPreferences(defaultPrefs);
    toast?.success?.('🔄 Reset to defaults!', 2000);
  };

  const updatePreference = (key, value) => {
    setPreferences(prev => ({ ...prev, [key]: value }));
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[120] flex items-center justify-center p-3 bg-black/50">
      <div className="relative w-full max-w-sm max-h-[85vh] bg-white dark:bg-gray-900 rounded-xl shadow-2xl overflow-hidden border border-rose-100 dark:border-gray-800">
        {/* Compact Header */}
        <div className="bg-gradient-to-r from-rose-500 to-pink-600 p-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="w-6 h-6 bg-white/20 rounded-md flex items-center justify-center">
                <Settings className="text-white" size={14} />
              </div>
              <div>
                <h2 className="text-sm font-bold text-white">Preferences</h2>
                <p className="text-rose-100 text-xs">Customize experience</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-1.5 hover:bg-white/20 rounded-md transition-colors"
            >
              <X size={14} className="text-white" />
            </button>
          </div>
        </div>

        {/* Compact Content */}
        <div className="p-3 space-y-3 max-h-[calc(85vh-100px)] overflow-y-auto">



          {/* Content Type */}
          <div className="bg-gradient-to-r from-purple-50 to-indigo-50 dark:from-gray-800 dark:to-gray-700 rounded-lg p-2.5">
            <div className="flex items-center space-x-1.5 mb-2">
              <Eye className="text-purple-600 dark:text-purple-400" size={14} />
              <h3 className="font-semibold text-xs text-gray-800 dark:text-white">Content</h3>
            </div>
            <div className="grid grid-cols-2 gap-1.5">
              {[
                { value: 'skincare', label: '🧴', name: 'Skincare' },
                { value: 'makeup', label: '💄', name: 'Makeup' },
                { value: 'luxury', label: '✨', name: 'Luxury' },
                { value: 'mixed', label: '🎨', name: 'All' }
              ].map((option) => (
                <button
                  key={option.value}
                  onClick={() => updatePreference('contentType', option.value)}
                  className={`p-1.5 rounded-md text-xs font-medium transition-all duration-200 flex items-center space-x-1 ${
                    preferences.contentType === option.value
                      ? 'bg-gradient-to-br from-purple-500 to-indigo-600 text-white shadow-lg'
                      : 'bg-white dark:bg-gray-600 text-gray-600 dark:text-gray-300 hover:bg-purple-100 dark:hover:bg-gray-500'
                  }`}
                >
                  <span>{option.label}</span>
                  <span className="text-xs">{option.name}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Font Size */}
          <div className="bg-gradient-to-r from-emerald-50 to-teal-50 dark:from-gray-800 dark:to-gray-700 rounded-lg p-2.5">
            <div className="flex items-center space-x-1.5 mb-2">
              <Type className="text-emerald-600 dark:text-emerald-400" size={14} />
              <h3 className="font-semibold text-xs text-gray-800 dark:text-white">Font Size</h3>
            </div>
            <div className="grid grid-cols-3 gap-1.5">
              {[
                { value: 'small', label: 'A', size: 'text-xs' },
                { value: 'medium', label: 'A', size: 'text-sm' },
                { value: 'large', label: 'A', size: 'text-base' }
              ].map((option) => (
                <button
                  key={option.value}
                  onClick={() => updatePreference('fontSize', option.value)}
                  className={`p-1.5 rounded-md font-bold transition-all duration-200 flex items-center justify-center ${option.size} ${
                    preferences.fontSize === option.value
                      ? 'bg-gradient-to-br from-emerald-500 to-teal-600 text-white shadow-lg'
                      : 'bg-white dark:bg-gray-600 text-gray-600 dark:text-gray-300 hover:bg-emerald-100 dark:hover:bg-gray-500'
                  }`}
                >
                  {option.label}
                </button>
              ))}
            </div>
          </div>

          {/* Toggle Options */}
          <div className="bg-gradient-to-r from-amber-50 to-orange-50 dark:from-gray-800 dark:to-gray-700 rounded-lg p-2.5">
            <div className="flex items-center space-x-1.5 mb-2">
              <Zap className="text-amber-600 dark:text-amber-400" size={14} />
              <h3 className="font-semibold text-xs text-gray-800 dark:text-white">Options</h3>
            </div>
            <div className="space-y-1.5">
              {[
                { key: 'notifications', icon: Bell, label: 'Notifications', desc: 'Beauty updates' },
                { key: 'autoplay', icon: Play, label: 'Auto-scroll', desc: 'Smooth reading' }
              ].map((option) => (
                <div key={option.key} className="flex items-center justify-between bg-white dark:bg-gray-600 rounded-md p-1.5">
                  <div className="flex items-center space-x-1.5">
                    <option.icon size={12} className="text-amber-600 dark:text-amber-400" />
                    <div>
                      <div className="text-xs font-medium text-gray-800 dark:text-white">{option.label}</div>
                      <div className="text-xs text-gray-500 dark:text-gray-400">{option.desc}</div>
                    </div>
                  </div>
                  <button
                    onClick={() => updatePreference(option.key, !preferences[option.key])}
                    className={`w-7 h-4 rounded-full transition-all duration-300 relative ${
                      preferences[option.key]
                        ? 'bg-gradient-to-r from-amber-500 to-orange-500 shadow-lg'
                        : 'bg-gray-300 dark:bg-gray-500'
                    }`}
                  >
                    <div className={`w-3 h-3 bg-white rounded-full absolute top-0.5 transition-transform duration-300 shadow-md ${
                      preferences[option.key] ? 'translate-x-3' : 'translate-x-0.5'
                    }`} />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Compact Footer */}
        <div className="p-3 border-t border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800">
          <div className="flex space-x-2">
            <button
              onClick={handleSave}
              className="flex-1 bg-gradient-to-r from-rose-500 to-pink-600 text-white px-3 py-1.5 rounded-md font-semibold text-sm hover:from-rose-600 hover:to-pink-700 transition-all duration-300 shadow-lg transform hover:scale-105"
            >
              Save
            </button>
            <button
              onClick={handleReset}
              className="px-3 py-1.5 bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-md font-semibold text-sm hover:bg-gray-300 dark:hover:bg-gray-600 transition-all duration-300"
            >
              Reset
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}