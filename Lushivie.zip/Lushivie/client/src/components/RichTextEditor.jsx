import { useState, useRef, useEffect } from 'react';
import {
  Bold, Italic, Underline, AlignLeft, AlignCenter, AlignRight,
  List, ListOrdered, Link, Image, Code, Quote, Type, Palette, Upload
} from 'lucide-react';

// Assuming imageUpload.js is in the same directory as RichTextEditor.jsx
// If imageUpload.js is in a different directory, adjust the import path accordingly.
import { uploadPostImage, isValidImageFile } from '../utils/imageUpload';

export default function RichTextEditor({ value, onChange, placeholder = "Write your content..." }) {
  const editorRef = useRef(null);
  const [isHtmlMode, setIsHtmlMode] = useState(false);
  const [showColorPicker, setShowColorPicker] = useState(false);
  const [uploading, setUploading] = useState(false);

  const fonts = [
    'Arial, sans-serif',
    'Georgia, serif',
    'Times New Roman, serif',
    'Helvetica, sans-serif',
    'Verdana, sans-serif',
    'Trebuchet MS, sans-serif',
    'Comic Sans MS, cursive',
    'Impact, sans-serif',
    'Courier New, monospace',
    'Playfair Display, serif',
    'Poppins, sans-serif'
  ];

  const fontSizes = ['12px', '14px', '16px', '18px', '20px', '24px', '28px', '32px', '36px', '48px'];

  const colors = [
    '#000000', '#333333', '#666666', '#999999', '#CCCCCC', '#FFFFFF',
    '#FF0000', '#FF6B6B', '#FF9F43', '#FFA502', '#F39C12', '#F1C40F',
    '#2ECC71', '#1ABC9C', '#3498DB', '#74B9FF', '#9B59B6', '#E84393',
    '#E8B4A0', '#8B1538', '#D4A574', '#F4E4BC'
  ];

  useEffect(() => {
    if (editorRef.current && !isHtmlMode) {
      editorRef.current.innerHTML = value || '';
    }
  }, [value, isHtmlMode]);

  const execCommand = (command, value = null) => {
    document.execCommand(command, false, value);
    updateContent();
  };

  const updateContent = () => {
    if (editorRef.current && onChange) {
      onChange(editorRef.current.innerHTML);
    }
  };

  const insertLink = () => {
    const url = prompt('Enter URL:');
    if (url) {
      execCommand('createLink', url);
    }
  };

  // The uploadToImgBB function is now replaced by uploadPostImage from utils/imageUpload.js
  // The following function is kept for context but the actual implementation is external.
  // If you need to reimplement it here, please provide the content of imageUpload.js
  // Or if the intention was to remove it, it should be removed from the code.
  // For now, assuming it's not directly used here anymore due to the import change.


  const handleImageUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    if (!isValidImageFile(file)) {
      alert('Please select a valid image file (JPG, PNG, GIF, WebP)');
      return;
    }

    setUploading(true);

    try {
      const uploadResult = await uploadPostImage(file);
      // Assuming uploadPostImage returns the URL of the uploaded image
      const imageUrl = uploadResult.url;
      execCommand('insertImage', imageUrl);
    } catch (error) {
      alert('Failed to upload image. Please try again.');
    } finally {
      setUploading(false);
    }
  };

  const insertImage = () => {
    const url = prompt('Enter image URL:');
    if (url) {
      execCommand('insertImage', url);
    }
  };

  const toggleHtmlMode = () => {
    if (isHtmlMode) {
      // Switch back to visual mode
      const textarea = document.querySelector('.html-editor');
      if (textarea && onChange) {
        onChange(textarea.value);
      }
    }
    setIsHtmlMode(!isHtmlMode);
  };

  return (
    <div className="border-2 border-gray-200 dark:border-gray-700 rounded-xl overflow-hidden bg-white dark:bg-gray-800">
      {/* Toolbar */}
      <div className="bg-gray-50 dark:bg-gray-900 border-b border-gray-200 dark:border-gray-700 p-3">
        <div className="flex flex-wrap items-center gap-2">

          {/* Font Family */}
          <select
            onChange={(e) => execCommand('fontName', e.target.value)}
            className="px-3 py-1 text-sm border border-gray-300 dark:border-gray-600 rounded bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
          >
            <option value="">Font</option>
            {fonts.map(font => (
              <option key={font} value={font} style={{ fontFamily: font }}>
                {font.split(',')[0]}
              </option>
            ))}
          </select>

          {/* Font Size */}
          <select
            onChange={(e) => {
              execCommand('fontSize', '7');
              document.execCommand('removeFormat');
              execCommand('fontSize', e.target.value);
            }}
            className="px-3 py-1 text-sm border border-gray-300 dark:border-gray-600 rounded bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
          >
            <option value="">Size</option>
            {fontSizes.map(size => (
              <option key={size} value={size}>
                {size}
              </option>
            ))}
          </select>

          <div className="w-px h-6 bg-gray-300 dark:bg-gray-600"></div>

          {/* Formatting Buttons */}
          <button
            type="button"
            onClick={() => execCommand('bold')}
            className="p-2 hover:bg-gray-200 dark:hover:bg-gray-700 rounded transition-colors"
            title="Bold"
          >
            <Bold size={16} />
          </button>

          <button
            type="button"
            onClick={() => execCommand('italic')}
            className="p-2 hover:bg-gray-200 dark:hover:bg-gray-700 rounded transition-colors"
            title="Italic"
          >
            <Italic size={16} />
          </button>

          <button
            type="button"
            onClick={() => execCommand('underline')}
            className="p-2 hover:bg-gray-200 dark:hover:bg-gray-700 rounded transition-colors"
            title="Underline"
          >
            <Underline size={16} />
          </button>

          <div className="w-px h-6 bg-gray-300 dark:bg-gray-600"></div>

          {/* Color Picker */}
          <div className="relative">
            <button
              type="button"
              onClick={() => setShowColorPicker(!showColorPicker)}
              className="p-2 hover:bg-gray-200 dark:hover:bg-gray-700 rounded transition-colors"
              title="Text Color"
            >
              <Palette size={16} />
            </button>

            {showColorPicker && (
              <div className="absolute top-full left-0 mt-2 p-3 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg shadow-xl z-10">
                <div className="grid grid-cols-6 gap-1 w-48">
                  {colors.map(color => (
                    <button
                      key={color}
                      type="button"
                      onClick={() => {
                        execCommand('foreColor', color);
                        setShowColorPicker(false);
                      }}
                      className="w-6 h-6 rounded border-2 border-gray-300 hover:border-gray-500 transition-colors"
                      style={{ backgroundColor: color }}
                      title={color}
                    />
                  ))}
                </div>
              </div>
            )}
          </div>

          <div className="w-px h-6 bg-gray-300 dark:bg-gray-600"></div>

          {/* Alignment */}
          <button
            type="button"
            onClick={() => execCommand('justifyLeft')}
            className="p-2 hover:bg-gray-200 dark:hover:bg-gray-700 rounded transition-colors"
            title="Align Left"
          >
            <AlignLeft size={16} />
          </button>

          <button
            type="button"
            onClick={() => execCommand('justifyCenter')}
            className="p-2 hover:bg-gray-200 dark:hover:bg-gray-700 rounded transition-colors"
            title="Align Center"
          >
            <AlignCenter size={16} />
          </button>

          <button
            type="button"
            onClick={() => execCommand('justifyRight')}
            className="p-2 hover:bg-gray-200 dark:hover:bg-gray-700 rounded transition-colors"
            title="Align Right"
          >
            <AlignRight size={16} />
          </button>

          <div className="w-px h-6 bg-gray-300 dark:bg-gray-600"></div>

          {/* Lists */}
          <button
            type="button"
            onClick={() => execCommand('insertUnorderedList')}
            className="p-2 hover:bg-gray-200 dark:hover:bg-gray-700 rounded transition-colors"
            title="Bullet List"
          >
            <List size={16} />
          </button>

          <button
            type="button"
            onClick={() => execCommand('insertOrderedList')}
            className="p-2 hover:bg-gray-200 dark:hover:bg-gray-700 rounded transition-colors"
            title="Numbered List"
          >
            <ListOrdered size={16} />
          </button>

          <div className="w-px h-6 bg-gray-300 dark:bg-gray-600"></div>

          {/* Insert Elements */}
          <button
            type="button"
            onClick={insertLink}
            className="p-2 hover:bg-gray-200 dark:hover:bg-gray-700 rounded transition-colors"
            title="Insert Link"
          >
            <Link size={16} />
          </button>

          <button
            type="button"
            onClick={insertImage}
            className="p-2 hover:bg-gray-200 dark:hover:bg-gray-700 rounded transition-colors"
            title="Insert Image URL"
          >
            <Image size={16} />
          </button>

          {/* Image Upload */}
          <label className="p-2 hover:bg-gray-200 dark:hover:bg-gray-700 rounded transition-colors cursor-pointer" title="Upload Image">
            {uploading ? (
              <div className="animate-spin w-4 h-4 border-2 border-rose-500 border-t-transparent rounded-full"></div>
            ) : (
              <Upload size={16} />
            )}
            <input
              type="file"
              accept="image/*"
              onChange={handleImageUpload}
              className="hidden"
              disabled={uploading}
            />
          </label>

          <button
            type="button"
            onClick={() => execCommand('formatBlock', 'blockquote')}
            className="p-2 hover:bg-gray-200 dark:hover:bg-gray-700 rounded transition-colors"
            title="Quote"
          >
            <Quote size={16} />
          </button>

          <button
            type="button"
            onClick={() => execCommand('formatBlock', 'pre')}
            className="p-2 hover:bg-gray-200 dark:hover:bg-gray-700 rounded transition-colors"
            title="Code Block"
          >
            <Code size={16} />
          </button>

          <div className="w-px h-6 bg-gray-300 dark:bg-gray-600"></div>

          {/* HTML Mode Toggle */}
          <button
            type="button"
            onClick={toggleHtmlMode}
            className={`px-3 py-1 text-sm rounded transition-colors ${
              isHtmlMode
                ? 'bg-rose-500 text-white'
                : 'bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-300 dark:hover:bg-gray-600'
            }`}
            title="Toggle HTML Mode"
          >
            HTML
          </button>
        </div>
      </div>

      {/* Editor Content */}
      <div className="relative">
        {isHtmlMode ? (
          <textarea
            className="html-editor w-full h-96 p-4 border-none resize-none focus:outline-none bg-white dark:bg-gray-800 text-gray-900 dark:text-white font-mono text-sm"
            defaultValue={value || ''}
            onChange={(e) => onChange && onChange(e.target.value)}
            placeholder="Enter HTML content..."
          />
        ) : (
          <div
            ref={editorRef}
            contentEditable
            onInput={updateContent}
            onBlur={updateContent}
            className="min-h-96 p-4 focus:outline-none bg-white dark:bg-gray-800 text-gray-900 dark:text-white prose prose-lg dark:prose-invert max-w-none"
            style={{ minHeight: '384px' }}
            dangerouslySetInnerHTML={{ __html: value || '' }}
            data-placeholder={placeholder}
          />
        )}
      </div>

      {/* Status */}
      {uploading && (
        <div className="p-2 bg-blue-50 dark:bg-blue-950/30 border-t border-blue-200 dark:border-blue-800">
          <p className="text-blue-600 dark:text-blue-400 text-sm text-center">
            Uploading image...
          </p>
        </div>
      )}
    </div>
  );
}