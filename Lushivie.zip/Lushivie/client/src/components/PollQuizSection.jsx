import React, { useState, useEffect } from 'react';
import { BarChart3, CheckCircle, Circle, TrendingUp, Users, Trophy } from 'lucide-react';

export default function PollQuizSection({ postId, postTitle }) {
  const [polls, setPolls] = useState([]);
  const [userVotes, setUserVotes] = useState({});
  const [showResults, setShowResults] = useState({});

  // Sample polls data - in production, this would come from your backend
  const samplePolls = [
    {
      id: `poll-${postId}-1`,
      question: "What's your biggest beauty concern?",
      type: "poll",
      options: [
        { id: 1, text: "Skincare routine", votes: 45 },
        { id: 2, text: "Makeup application", votes: 32 },
        { id: 3, text: "Product recommendations", votes: 28 },
        { id: 4, text: "Anti-aging tips", votes: 51 }
      ]
    },
    {
      id: `quiz-${postId}-1`,
      question: "What type of skin tone do you have?",
      type: "quiz",
      options: [
        { id: 1, text: "Cool undertones", votes: 38 },
        { id: 2, text: "Warm undertones", votes: 42 },
        { id: 3, text: "Neutral undertones", votes: 35 },
        { id: 4, text: "Not sure", votes: 20 }
      ]
    }
  ];

  useEffect(() => {
    // Load polls for this specific post
    setPolls(samplePolls);

    // Load user's previous votes from localStorage
    const savedVotes = localStorage.getItem(`lushivie-votes-${postId}`);
    if (savedVotes) {
      setUserVotes(JSON.parse(savedVotes));
    }
  }, [postId]);

  const handleVote = (pollId, optionId) => {
    // Update user votes
    const newUserVotes = { ...userVotes, [pollId]: optionId };
    setUserVotes(newUserVotes);

    // Save to localStorage
    localStorage.setItem(`lushivie-votes-${postId}`, JSON.stringify(newUserVotes));

    // Show results after voting
    setShowResults(prev => ({ ...prev, [pollId]: true }));

    // Update vote counts (in production, this would be sent to backend)
    setPolls(prevPolls => 
      prevPolls.map(poll => 
        poll.id === pollId 
          ? {
              ...poll,
              options: poll.options.map(option => 
                option.id === optionId 
                  ? { ...option, votes: option.votes + 1 }
                  : option
              )
            }
          : poll
      )
    );
  };

  const getTotalVotes = (poll) => {
    return poll.options.reduce((total, option) => total + option.votes, 0);
  };

  const getPercentage = (votes, total) => {
    return total > 0 ? Math.round((votes / total) * 100) : 0;
  };

  const PollOption = ({ poll, option, isSelected, onVote, showResult }) => {
    const totalVotes = getTotalVotes(poll);
    const percentage = getPercentage(option.votes, totalVotes);
    const isWinning = option.votes === Math.max(...poll.options.map(o => o.votes));

    return (
      <div
        className={`relative overflow-hidden rounded-xl border-2 transition-all duration-300 cursor-pointer ${
          isSelected 
            ? 'border-rose-500 bg-rose-50 dark:bg-rose-900/20' 
            : 'border-gray-200 dark:border-gray-700 hover:border-rose-300 dark:hover:border-rose-600'
        }`}
        onClick={() => !showResult && onVote(poll.id, option.id)}
      >
        {/* Background bar for results */}
        {showResult && (
          <div
            className={`absolute inset-y-0 left-0 transition-all duration-1000 ease-out ${
              isWinning ? 'bg-gradient-to-r from-rose-400 to-pink-500' : 'bg-gray-200 dark:bg-gray-700'
            }`}
            style={{ width: `${percentage}%` }}
          />
        )}

        <div className="relative flex items-center justify-between p-4">
          <div className="flex items-center space-x-3">
            {showResult ? (
              <CheckCircle 
                size={20} 
                className={isSelected ? 'text-rose-600' : 'text-gray-400'} 
              />
            ) : (
              <Circle 
                size={20} 
                className={isSelected ? 'text-rose-600' : 'text-gray-400'} 
              />
            )}
            <span className={`font-medium ${showResult && isWinning ? 'text-white' : 'text-gray-800 dark:text-gray-200'}`}>
              {option.text}
            </span>
          </div>

          {showResult && (
            <div className={`flex items-center space-x-2 ${isWinning ? 'text-white' : 'text-gray-600 dark:text-gray-400'}`}>
              <span className="font-bold">{percentage}%</span>
              <span className="text-sm">({option.votes})</span>
              {isWinning && <Trophy size={16} className="text-yellow-300" />}
            </div>
          )}
        </div>
      </div>
    );
  };

  return (
    <div className="max-w-4xl mx-auto mt-16">
      <div className="bg-gradient-to-br from-white to-rose-50 dark:from-gray-900 dark:to-rose-950/20 rounded-3xl p-8 luxury-shadow-xl border border-gray-100 dark:border-gray-800">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center space-x-3 mb-4">
            <div className="w-12 h-12 bg-gradient-to-br from-rose-500 to-pink-600 rounded-xl flex items-center justify-center shadow-lg">
              <BarChart3 className="text-white" size={24} />
            </div>
            <h3 className="text-3xl font-bold gradient-text font-playfair">
              Community Poll & Quiz
            </h3>
          </div>
          <p className="text-gray-600 dark:text-gray-300 text-lg">
            Share your thoughts and see what our beauty community thinks!
          </p>
        </div>

        <div className="space-y-12">
          {polls.map((poll) => {
            const hasVoted = userVotes[poll.id];
            const shouldShowResults = showResults[poll.id] || hasVoted;
            const totalVotes = getTotalVotes(poll);

            return (
              <div key={poll.id} className="bg-white dark:bg-gray-800 rounded-2xl p-6 shadow-lg">
                <div className="flex items-center space-x-3 mb-6">
                  <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                    poll.type === 'poll' 
                      ? 'bg-blue-100 dark:bg-blue-900/30' 
                      : 'bg-purple-100 dark:bg-purple-900/30'
                  }`}>
                    {poll.type === 'poll' ? (
                      <TrendingUp size={16} className={poll.type === 'poll' ? 'text-blue-600' : 'text-purple-600'} />
                    ) : (
                      <Trophy size={16} className="text-purple-600" />
                    )}
                  </div>
                  <div>
                    <h4 className="text-xl font-bold text-gray-800 dark:text-white font-playfair">
                      {poll.question}
                    </h4>
                    <div className="flex items-center space-x-4 text-sm text-gray-500 dark:text-gray-400">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        poll.type === 'poll' 
                          ? 'bg-blue-100 text-blue-600 dark:bg-blue-900/30 dark:text-blue-400' 
                          : 'bg-purple-100 text-purple-600 dark:bg-purple-900/30 dark:text-purple-400'
                      }`}>
                        {poll.type === 'poll' ? 'Poll' : 'Quiz'}
                      </span>
                      {shouldShowResults && (
                        <div className="flex items-center space-x-1">
                          <Users size={14} />
                          <span>{totalVotes} votes</span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                <div className="space-y-3">
                  {poll.options.map((option) => (
                    <PollOption
                      key={option.id}
                      poll={poll}
                      option={option}
                      isSelected={userVotes[poll.id] === option.id}
                      onVote={handleVote}
                      showResult={shouldShowResults}
                    />
                  ))}
                </div>

                {!shouldShowResults && (
                  <div className="mt-6 text-center">
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      Click an option to vote and see results
                    </p>
                  </div>
                )}

                {shouldShowResults && (
                  <div className="mt-6 pt-6 border-t border-gray-200 dark:border-gray-700">
                    <div className="flex items-center justify-center space-x-6 text-sm text-gray-600 dark:text-gray-400">
                      <div className="flex items-center space-x-1">
                        <Users size={16} />
                        <span>{totalVotes} total votes</span>
                      </div>
                      <div className="text-rose-600 font-medium">
                        Thanks for participating! 🌟
                      </div>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        <div className="mt-8 pt-6 border-t border-gray-200 dark:border-gray-700 text-center">
          <p className="text-sm text-gray-600 dark:text-gray-400 font-medium flex items-center justify-center space-x-2">
            <svg className="w-4 h-4 text-yellow-500" fill="currentColor" viewBox="0 0 20 20">
              <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
            </svg>
            <span><strong>Love these polls?</strong> Follow Lushivie for more interactive beauty content!</span>
          </p>
        </div>
      </div>
    </div>
  );
}