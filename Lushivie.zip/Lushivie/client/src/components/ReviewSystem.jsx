import React, { useState, useEffect } from 'react';
import { Star, Send, MessageSquare, Calendar, User, Eye, ChevronRight } from 'lucide-react';
// Removed Firebase imports as they are no longer used for reviews
// import { collection, addDoc, query, where, orderBy, limit, getDocs, serverTimestamp } from 'firebase/firestore';
// import { db } from '../firebase';
import { useToast } from './Toast';
import { getUniversalProfileImage } from '../utils/imageUpload';

// Star Rating Component
function StarRating({ rating, onRatingChange, interactive = false, size = 20 }) {
  const [hoverRating, setHoverRating] = useState(0);

  return (
    <div className="flex items-center space-x-1">
      {[1, 2, 3, 4, 5].map((star) => (
        <button
          key={star}
          type={interactive ? "button" : undefined}
          className={`${interactive ? 'cursor-pointer hover:scale-110' : 'cursor-default'} transition-all duration-200`}
          onClick={interactive ? () => onRatingChange(star) : undefined}
          onMouseEnter={interactive ? () => setHoverRating(star) : undefined}
          onMouseLeave={interactive ? () => setHoverRating(0) : undefined}
          disabled={!interactive}
        >
          <Star
            size={size}
            className={`${
              star <= (hoverRating || rating)
                ? 'text-yellow-400 fill-yellow-400'
                : 'text-gray-300 dark:text-gray-600'
            } transition-colors duration-200`}
          />
        </button>
      ))}
    </div>
  );
}

// Review Form Component
function ReviewForm({ onSubmitSuccess }) {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    rating: 0,
    reviewText: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const toast = useToast();

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!formData.name.trim() || !formData.email.trim() || formData.rating === 0 || !formData.reviewText.trim()) {
      toast.error('Please fill in all fields and select a rating.');
      return;
    }

    // Simple email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(formData.email)) {
      toast.error('Please enter a valid email address.');
      return;
    }

    if (formData.reviewText.length < 10) {
      toast.error('Review must be at least 10 characters long.');
      return;
    }

    setIsSubmitting(true);

    try {
      // Get user profile image with ImgBB support
      const getUserDP = () => {
        try {
          // Use universal profile getter for consistency
          const profileImage = getUniversalProfileImage(
            formData.email,
            formData.name,
            formData.name
          );

          if (profileImage) return profileImage;

          // Fallback to saved profile
          const savedProfile = localStorage.getItem('lushivie-user-profile');
          if (savedProfile) {
            const profile = JSON.parse(savedProfile);
            return profile.profileImage;
          }
        } catch (error) {
          console.error('Error loading user profile image:', error);
        }
        return null;
      };

      const reviewData = {
        name: formData.name.trim(),
        email: formData.email.trim(),
        rating: formData.rating,
        reviewText: formData.reviewText.trim(),
        profileImage: getUserDP() // Include user's profile image
      };

      // Submit to backend API
      const response = await fetch('/api/reviews', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(reviewData)
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to submit review');
      }

      const result = await response.json();
      console.log('Review submitted successfully:', result);

      // Reset form
      setFormData({ name: '', email: '', rating: 0, reviewText: '' });
      toast.success('Thank you for your review! It will be published after approval.', 5000);

      if (onSubmitSuccess) {
        onSubmitSuccess();
      }
    } catch (error) {
      console.error('Error submitting review:', error);
      toast.error(error.message || 'Failed to submit review. Please try again.', 4000);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <div className="bg-white dark:bg-gray-900 rounded-3xl p-8 shadow-xl border border-gray-100 dark:border-gray-800 hover:shadow-2xl transition-all duration-300">
      <div className="flex items-center space-x-3 mb-6">
        <div className="w-12 h-12 bg-gradient-to-br from-rose-500 to-pink-600 rounded-xl flex items-center justify-center shadow-lg">
          <MessageSquare className="text-white" size={20} />
        </div>
        <div>
          <h3 className="text-2xl font-bold text-gray-800 dark:text-white font-playfair">Share Your Experience</h3>
          <p className="text-gray-600 dark:text-gray-300 text-sm">Let others know about your beauty journey</p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium mb-3 text-gray-700 dark:text-gray-300">
              Your Name *
            </label>
            <input
              type="text"
              value={formData.name}
              onChange={(e) => handleChange('name', e.target.value)}
              className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 dark:border-gray-700 focus:border-rose-500 focus:ring-4 focus:ring-rose-500/20 transition-all duration-300 bg-white dark:bg-gray-800 text-gray-800 dark:text-white placeholder-gray-400"
              placeholder="Enter your name"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-3 text-gray-700 dark:text-gray-300">
              Email (Optional)
            </label>
            <input
              type="email"
              value={formData.email}
              onChange={(e) => handleChange('email', e.target.value)}
              className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 dark:border-gray-700 focus:border-rose-500 focus:ring-4 focus:ring-rose-500/20 transition-all duration-300 bg-white dark:bg-gray-800 text-gray-800 dark:text-white placeholder-gray-400"
              placeholder="your@email.com"
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium mb-3 text-gray-700 dark:text-gray-300">
            Rating *
          </label>
          <div className="flex items-center space-x-4">
            <StarRating
              rating={formData.rating}
              onRatingChange={(rating) => handleChange('rating', rating)}
              interactive={true}
              size={28}
            />
            <span className="text-sm text-gray-600 dark:text-gray-400">
              {formData.rating > 0 ? `${formData.rating} out of 5 stars` : 'Click to rate'}
            </span>
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium mb-3 text-gray-700 dark:text-gray-300">
            Your Review *
          </label>
          <textarea
            value={formData.reviewText}
            onChange={(e) => handleChange('reviewText', e.target.value)}
            rows={4}
            className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 dark:border-gray-700 focus:border-rose-500 focus:ring-4 focus:ring-rose-500/20 transition-all duration-300 bg-white dark:bg-gray-800 text-gray-800 dark:text-white placeholder-gray-400 resize-none"
            placeholder="Share your thoughts about Lushivie's content, recommendations, or overall experience..."
            required
            minLength={10}
          />
          <p className="text-xs text-gray-500 dark:text-gray-400 mt-2">
            {formData.reviewText.length}/500 characters
          </p>
        </div>

        <button
          type="submit"
          disabled={isSubmitting}
          className="w-full bg-gradient-to-r from-rose-500 to-pink-600 text-white px-8 py-4 rounded-2xl font-bold hover:from-rose-600 hover:to-pink-700 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center space-x-3"
        >
          {isSubmitting ? (
            <div className="animate-spin w-5 h-5 border-2 border-white border-t-transparent rounded-full"></div>
          ) : (
            <>
              <Send size={20} />
              <span>Submit Review</span>
            </>
          )}
        </button>
      </form>
    </div>
  );
}

// Review Card Component with DP on top
function ReviewCard({ review }) {
  const formatDate = (timestamp) => {
    try {
      // Assuming timestamp is a Date object or ISO string
      const date = timestamp?.toDate ? timestamp.toDate() : new Date(timestamp);
      return date.toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      });
    } catch (error) {
      console.error("Error formatting date:", error);
      return 'Invalid Date';
    }
  };

  const getInitials = (name) => {
    if (!name) return '';
    return name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
  };

  const getUserProfileImage = (userEmail, authorName) => {
    // Use universal profile image getter for consistency
    try {
      const profileImage = getUniversalProfileImage(userEmail, authorName, authorName);
      console.log('Getting profile image for:', authorName, 'Result:', profileImage);
      return profileImage;
    } catch (error) {
      console.error('Error getting user profile image:', error);
      return null;
    }
  };

  return (
    <div className="bg-white dark:bg-gray-900 rounded-2xl shadow-lg border border-gray-100 dark:border-gray-800 hover:shadow-xl transition-all duration-300 overflow-hidden">
      {/* Header with DP and Name */}
      <div className="p-6 pb-4">
        <div className="flex items-center space-x-4">
          {/* Profile Picture */}
          <div className="flex-shrink-0">
            <div className="w-12 h-12 rounded-full overflow-hidden shadow-lg border-2 border-white dark:border-gray-700">
              {(() => {
                // Get profile image with enhanced universal getter
                let profileImage = null;

                // Always use universal getter for consistency
                profileImage = getUniversalProfileImage(
                  review.userEmail || review.email,
                  review.name,
                  review.name
                );

                // Additional fallback for review-specific data
                if (!profileImage) {
                  profileImage = review.profileImage || review.userPhoto;
                }

                console.log('Review profile image for', review.name, ':', profileImage);

                return profileImage ? (
                  <img
                    src={profileImage}
                    alt={review.name}
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      console.log('Image failed to load for review:', review.name);
                      e.target.parentElement.innerHTML = `<div class="w-12 h-12 bg-gradient-to-br from-rose-400 to-pink-600 flex items-center justify-center"><span class="text-white font-bold text-sm">${getInitials(review.name)}</span></div>`;
                    }}
                  />
                ) : (
                  <div className="w-12 h-12 bg-gradient-to-br from-rose-400 to-pink-600 flex items-center justify-center">
                    <span className="text-white font-bold text-sm">
                      {getInitials(review.name)}
                    </span>
                  </div>
                );
              })()}
            </div>
          </div>

          {/* Name and Date */}
          <div className="flex-grow min-w-0">
            <h4 className="font-semibold text-gray-800 dark:text-white text-base font-playfair truncate">
              {review.name}
            </h4>
            <div className="flex items-center space-x-1 text-xs text-gray-500 dark:text-gray-400">
              <Calendar size={12} />
              <span>{formatDate(review.createdAt || review.timestamp)}</span>
            </div>
          </div>

          {/* Rating */}
          <div className="flex-shrink-0">
            <StarRating rating={review.rating} size={16} />
          </div>
        </div>
      </div>

      {/* Review Content */}
      <div className="px-6 pb-4">
        <div className="bg-gray-50 dark:bg-gray-800 rounded-xl p-4">
          <p className="text-gray-700 dark:text-gray-300 leading-relaxed text-sm break-words">
            "{review.reviewText}"
          </p>
        </div>
      </div>

      {/* Footer */}
      <div className="px-6 pb-6">
        <div className="flex justify-between items-center pt-4 border-t border-gray-100 dark:border-gray-800">
          <span className="bg-rose-50 dark:bg-rose-900/20 text-rose-600 dark:text-rose-400 px-3 py-1 rounded-full font-medium text-xs">
            <div className="flex items-center space-x-1">
              <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
              </svg>
              <span>Verified Review</span>
            </div>
          </span>
          <div className="text-xs text-gray-400 dark:text-gray-500">
            {review.rating}/5 stars
          </div>
        </div>
      </div>
    </div>
  );
}

// Main Review System Component
export default function ReviewSystem() {
  const [reviews, setReviews] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [showAllReviews, setShowAllReviews] = useState(false);
  const [stats, setStats] = useState({ total: 0, averageRating: 0 });

  // Fetch reviews function
  const fetchReviews = async () => {
    setIsLoading(true);
    try {
      console.log('Attempting to fetch reviews...');

      // Use backend API for public reviews
      const response = await fetch('/api/reviews/public');
      if (!response.ok) {
        throw new Error('Failed to fetch reviews');
      }

      const data = await response.json();
      console.log('Reviews fetched successfully:', data.reviews?.length || 0, 'approved');

      const reviewsData = data.reviews || [];
      setReviews(reviewsData.slice(0, showAllReviews ? 50 : 6));
      setStats(data.stats || { total: 0, averageRating: 0 });

    } catch (error) {
      console.error('Error fetching reviews:', error);

      // Fallback to empty state
      setReviews([]);
      setStats({ total: 0, averageRating: 0 });
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchReviews();
  }, [showAllReviews]);

  // Function to refresh admin reviews
  const refreshAdminReviews = () => {
    console.log('Refreshing admin reviews in ReviewSystem...');
    setReviews(prev => prev.map(review => ({
      ...review,
      _updateTrigger: Date.now()
    })));
    // Also trigger a second update after delay for thoroughness
    setTimeout(() => {
      setReviews(prev => prev.map(review => ({
        ...review,
        _updateTrigger: Date.now()
      })));
    }, 100);
  };

  useEffect(() => {
    // Register component with centralized event system
    import('../utils/profileUtils').then(({ ProfileEventManager }) => {
      ProfileEventManager.registerComponent('ReviewSystem');
    });

    // Single profile update listener
    const handleProfileUpdate = (event) => {
      console.log('Profile update detected in ReviewSystem:', event.type);
      const profileImage = event.detail?.profileImage || getUniversalProfileImage('help@lushivie.com', 'Maanya Arora');
      console.log('Review profile image for', 'Maanya Arora', ':', profileImage);

      // Force refresh of admin reviews
      refreshAdminReviews();
    };

    // Only listen to centralized events
    const centralizedEvents = [
      'adminProfileUpdated',
      'adminProfileRefresh',
      'globalAdminProfileSync'
    ];

    centralizedEvents.forEach(eventType => {
      window.addEventListener(eventType, handleProfileUpdate);
    });

    return () => {
      // Unregister component
      import('../utils/profileUtils').then(({ ProfileEventManager }) => {
        ProfileEventManager.unregisterComponent('ReviewSystem');
      });

      centralizedEvents.forEach(eventType => {
        window.removeEventListener(eventType, handleProfileUpdate);
      });
    };
  }, []);

  const handleReviewSubmitted = () => {
    // Refresh reviews after successful submission
    // A short delay to allow the backend to process the new review before fetching
    setTimeout(() => {
      fetchReviews();
    }, 2000);
  };

  if (isLoading && reviews.length === 0) {
    return (
      <section className="py-20 bg-gradient-to-br from-gray-50 via-rose-50 to-pink-50 dark:from-gray-950/20 dark:via-rose-950/10 dark:to-pink-950/10">
        <div className="container mx-auto px-6">
          <div className="flex items-center justify-center py-16">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-rose-600"></div>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="py-20 bg-gradient-to-br from-gray-50 via-rose-50 to-pink-50 dark:from-gray-950/20 dark:via-rose-950/10 dark:to-pink-950/10 relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0" style={{
          backgroundImage: `radial-gradient(circle at 25px 25px, rgba(236, 72, 153, 0.3) 2px, transparent 0)`,
          backgroundSize: '50px 50px'
        }}></div>
      </div>

      <div className="container mx-auto px-6 relative z-10">
        {/* Section Header */}
        <div className="text-center mb-16">
          <div className="flex items-center justify-center space-x-3 mb-6">
            <div className="relative group">
              <div className="absolute -inset-1 bg-gradient-to-r from-rose-400 via-pink-500 to-orange-400 rounded-full blur opacity-30 group-hover:opacity-60 transition-opacity duration-500"></div>
              <div className="w-16 h-16 rounded-full overflow-hidden shadow-2xl transform group-hover:scale-110 transition-all duration-300 border-3 border-white dark:border-gray-800 bg-white dark:bg-gray-800">
                <img
                src="https://i.ibb.co/zH5KTH4n/IMG-20250811-194616-255.jpg"
                alt="Maanya Arora"
                className="w-full h-full object-cover"
                onError={(e) => {
                  e.target.style.display = 'none';
                  e.target.parentElement.innerHTML = '<span class="text-2xl font-black text-white drop-shadow-lg font-playfair flex items-center justify-center w-full h-full bg-gradient-to-br from-amber-200 via-orange-300 to-rose-400">M</span>';
                }}
              />
              </div>
            </div>
            <div>
              <h2 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-rose-500 to-pink-600 bg-clip-text text-transparent font-playfair">
                Beauty Reviews
              </h2>
              <p className="text-xl text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
                Real experiences from our beauty community
              </p>
            </div>
          </div>

          {stats.total > 0 && (
            <div className="flex items-center justify-center space-x-8 mb-8">
              <div className="text-center">
                <div className="flex items-center justify-center space-x-2 mb-2">
                  <StarRating rating={Math.round(stats.averageRating)} size={20} />
                  <span className="text-2xl font-bold text-gray-800 dark:text-white">
                    {stats.averageRating.toFixed(1)}
                  </span>
                </div>
                <p className="text-sm text-gray-600 dark:text-gray-400">Average Rating</p>
              </div>
              <div className="w-px h-12 bg-gray-300 dark:bg-gray-700"></div>
              <div className="text-center">
                <div className="text-2xl font-bold text-gray-800 dark:text-white mb-2">
                  {stats.total}+
                </div>
                <p className="text-sm text-gray-600 dark:text-gray-400">Successful Reviews</p>
              </div>
            </div>
          )}
        </div>

        {/* Review Form and Display Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 lg:gap-12 mb-16">
          {/* Review Form */}
          <div className="lg:col-span-1">
            <ReviewForm onSubmitSuccess={handleReviewSubmitted} />
          </div>

          {/* Reviews Display */}
          <div className="lg:col-span-2">
            {reviews.length === 0 ? (
              <div className="text-center py-12 bg-white dark:bg-gray-900 rounded-3xl shadow-xl border border-gray-100 dark:border-gray-800">
                <div className="w-16 h-16 bg-gradient-to-br from-rose-100 to-pink-100 rounded-xl flex items-center justify-center mx-auto mb-4 shadow-lg">
                  <MessageSquare className="text-rose-600" size={24} />
                </div>
                <h3 className="text-2xl font-bold mb-2 text-gray-800 dark:text-white font-playfair">No Reviews Yet</h3>
                <p className="text-gray-600 dark:text-gray-300">Be the first to share your beauty experience!</p>
              </div>
            ) : (
              <>
                <div className="grid grid-cols-1 gap-6 mb-8">
                  {reviews.slice(0, showAllReviews ? reviews.length : 6).map((review) => (
                    <ReviewCard key={review.id} review={review} />
                  ))}
                </div>

                {reviews.length > 6 && !showAllReviews && (
                  <div className="text-center">
                    <button
                      onClick={() => setShowAllReviews(true)}
                      className="inline-flex items-center space-x-3 bg-gradient-to-r from-rose-500 to-pink-600 text-white px-8 py-4 rounded-2xl font-bold hover:from-rose-600 hover:to-pink-700 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105"
                    >
                      <Eye size={20} />
                      <span>View All Reviews</span>
                      <ChevronRight size={20} />
                    </button>
                  </div>
                )}
              </>
            )}
          </div>
        </div>

        {/* Footer Note */}
        <div className="text-center mt-16 py-8 border-t border-gray-200 dark:border-gray-700">
          <p className="text-sm text-gray-600 dark:text-gray-400 font-medium">
            © 2025 Lushivie. Created with ❤️ by Maanya Arora — Inspiring beauty enthusiasts worldwide.
          </p>
        </div>
      </div>
    </section>
  );
}