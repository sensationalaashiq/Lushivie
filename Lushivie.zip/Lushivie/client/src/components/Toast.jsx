import React, { useState, useEffect, createContext, useContext, useCallback } from 'react';
import { X, CheckCircle, AlertCircle, Info, AlertTriangle } from 'lucide-react';

// Toast Context
const ToastContext = createContext();

// Custom hook for using toast
export const useToast = () => {
  const context = useContext(ToastContext);
  if (!context) {
    throw new Error('useToast must be used within a ToastProvider');
  }
  return context;
};

// Toast Provider Component
export const ToastProvider = ({ children }) => {
  const [toasts, setToasts] = useState([]);

  const addToast = useCallback((message, type = 'info', duration = 5000) => {
    const id = Date.now() + Math.random();
    const toast = { id, message, type, duration };

    setToasts(prev => [...prev, toast]);

    if (duration > 0) {
      setTimeout(() => {
        removeToast(id);
      }, duration);
    }
  }, []);

  const removeToast = useCallback((id) => {
    setToasts(prev => prev.filter(toast => toast.id !== id));
  }, []);

  const confirm = useCallback((message, onConfirm, onCancel = () => {}) => {
    const toastId = Date.now() + Math.random();
    
    const handleConfirm = () => {
      removeToast(toastId);
      onConfirm();
    };
    
    const handleCancel = () => {
      removeToast(toastId);
      onCancel();
    };
    
    const toast = {
      id: toastId,
      message: (
        <div className="flex flex-col space-y-3">
          <p className="font-semibold">{message}</p>
          <div className="flex space-x-2 pt-2">
            <button
              onClick={handleConfirm}
              className="px-3 py-1 bg-red-500 text-white text-sm rounded-lg hover:bg-red-600 transition-colors"
            >
              Confirm
            </button>
            <button
              onClick={handleCancel}
              className="px-3 py-1 bg-gray-300 text-gray-700 text-sm rounded-lg hover:bg-gray-400 transition-colors"
            >
              Cancel
            </button>
          </div>
        </div>
      ),
      type: 'warning',
      duration: 0
    };

    setToasts(prev => [...prev, toast]);
  }, [removeToast]);

  const toast = {
    success: (message, duration) => addToast(message, 'success', duration),
    error: (message, duration) => addToast(message, 'error', duration),
    info: (message, duration) => addToast(message, 'info', duration),
    warning: (message, duration) => addToast(message, 'warning', duration),
    confirm: confirm,
  };

  return (
    <ToastContext.Provider value={toast}>
      {children}
      <ToastContainer toasts={toasts} onRemove={removeToast} />
    </ToastContext.Provider>
  );
};

// Toast Container
const ToastContainer = ({ toasts, onRemove }) => {
  if (toasts.length === 0) return null;

  return (
    <div className="fixed top-6 right-6 z-[200] space-y-3 max-w-sm">
      {toasts.map(toast => (
        <ToastItem key={toast.id} toast={toast} onRemove={onRemove} />
      ))}
    </div>
  );
};

// Individual Toast Item
const ToastItem = ({ toast, onRemove }) => {
  const [isVisible, setIsVisible] = useState(false);
  const [isLeaving, setIsLeaving] = useState(false);

  useEffect(() => {
    // Animate in
    setTimeout(() => setIsVisible(true), 10);

    // Auto-dismiss if duration is set
    if (toast.duration > 0) {
      const timer = setTimeout(() => {
        handleRemove();
      }, toast.duration);

      return () => clearTimeout(timer);
    }
  }, []);

  const handleRemove = () => {
    setIsLeaving(true);
    setTimeout(() => onRemove(toast.id), 300);
  };

  const getToastStyles = () => {
    const baseStyles = `
      transform transition-all duration-300 ease-out
      bg-white/95 dark:bg-gray-800/95 
      border-l-4 rounded-2xl shadow-2xl 
      p-4 backdrop-blur-lg border border-white/20 dark:border-gray-700/50
      max-w-sm
    `;

    const visibilityStyles = isVisible && !isLeaving
      ? 'translate-x-0 opacity-100 scale-100'
      : 'translate-x-full opacity-0 scale-95';

    const typeStyles = {
      success: 'border-green-500 bg-gradient-to-r from-green-50/90 to-emerald-50/90 dark:from-green-900/30 dark:to-emerald-900/30',
      error: 'border-red-500 bg-gradient-to-r from-red-50/90 to-rose-50/90 dark:from-red-900/30 dark:to-rose-900/30',
      warning: 'border-yellow-500 bg-gradient-to-r from-yellow-50/90 to-amber-50/90 dark:from-yellow-900/30 dark:to-amber-900/30',
      info: 'border-blue-500 bg-gradient-to-r from-blue-50/90 to-indigo-50/90 dark:from-blue-900/30 dark:to-indigo-900/30'
    };

    return `${baseStyles} ${visibilityStyles} ${typeStyles[toast.type]}`;
  };

  const getIcon = () => {
    const iconStyles = "w-5 h-5 flex-shrink-0 drop-shadow-sm";

    switch (toast.type) {
      case 'success':
        return <CheckCircle className={`${iconStyles} text-green-600 dark:text-green-400`} />;
      case 'error':
        return <AlertCircle className={`${iconStyles} text-red-600 dark:text-red-400`} />;
      case 'warning':
        return <AlertTriangle className={`${iconStyles} text-yellow-600 dark:text-yellow-400`} />;
      default:
        return <Info className={`${iconStyles} text-blue-600 dark:text-blue-400`} />;
    }
  };

  const isReactElement = React.isValidElement(toast.message);

  return (
    <div className={getToastStyles()}>
      <div className="flex items-start space-x-3 w-full">
        {getIcon()}

        <div className="flex-1 min-w-0">
          {isReactElement ? (
            toast.message
          ) : (
            <p className="text-sm font-medium text-gray-800 dark:text-gray-200 leading-tight">
              {toast.message}
            </p>
          )}
        </div>

        {toast.duration !== 0 && (
          <button
            onClick={handleRemove}
            className="flex-shrink-0 p-1 rounded-lg hover:bg-gray-100/80 dark:hover:bg-gray-700/80 transition-colors ml-2"
          >
            <X className="w-4 h-4 text-gray-500 dark:text-gray-400" />
          </button>
        )}
      </div>
    </div>
  );
};