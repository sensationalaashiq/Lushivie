
import { useEffect } from 'react';

export default function CustomCodeInjector() {
  useEffect(() => {
    // Load and apply custom code configuration
    const loadCustomCode = () => {
      const savedEditorConfig = localStorage.getItem('lushivie-editor-config');
      if (!savedEditorConfig) return;

      const config = JSON.parse(savedEditorConfig);
      if (!config.enabled) return;

      // Inject custom CSS
      if (config.css) {
        let existingStyle = document.getElementById('lushivie-custom-css');
        if (existingStyle) {
          existingStyle.textContent = config.css;
        } else {
          const styleElement = document.createElement('style');
          styleElement.id = 'lushivie-custom-css';
          styleElement.textContent = config.css;
          document.head.appendChild(styleElement);
        }
      }

      // Inject custom JavaScript
      if (config.javascript) {
        let existingScript = document.getElementById('lushivie-custom-js');
        if (existingScript) {
          existingScript.remove();
        }
        
        const scriptElement = document.createElement('script');
        scriptElement.id = 'lushivie-custom-js';
        scriptElement.textContent = config.javascript;
        document.body.appendChild(scriptElement);
      }

      // Inject header HTML
      if (config.html) {
        let existingHeader = document.getElementById('lushivie-custom-header');
        if (existingHeader) {
          existingHeader.remove();
        }
        
        const headerDiv = document.createElement('div');
        headerDiv.id = 'lushivie-custom-header';
        headerDiv.innerHTML = config.html;
        document.head.appendChild(headerDiv);
      }

      // Inject AdSense HTML
      if (config.adsense) {
        let existingAdsense = document.getElementById('lushivie-custom-adsense');
        if (existingAdsense) {
          existingAdsense.remove();
        }
        
        const adsenseDiv = document.createElement('div');
        adsenseDiv.id = 'lushivie-custom-adsense';
        adsenseDiv.innerHTML = config.adsense;
        document.body.appendChild(adsenseDiv);
      }
    };

    // Load custom code on mount
    loadCustomCode();

    // Listen for storage changes to update code dynamically
    const handleStorageChange = (e) => {
      if (e.key === 'lushivie-editor-config') {
        loadCustomCode();
      }
    };

    window.addEventListener('storage', handleStorageChange);

    // Clean up
    return () => {
      window.removeEventListener('storage', handleStorageChange);
    };
  }, []);

  return null; // This component doesn't render anything
}
