// ENHANCED profile loading with proper universal getter
  useEffect(() => {
    const loadAuthorProfile = () => {
      try {
        // Import utilities dynamically to avoid circular imports
        import('../utils/profileUtils').then(({ getUserDisplayName, getUniversalProfileImage }) => {
          const displayName = getUserDisplayName(post.authorEmail, post.author);
          const profileImage = getUniversalProfileImage(
            post.authorEmail,
            post.author,
            displayName
          );

          setAuthorProfile({
            displayName,
            profileImage: profileImage || getAuthorProfileImage(),
            lastUpdated: Date.now()
          });
        }).catch(error => {
          console.error('Error importing profile utils:', error);
          // Import the universal getter directly
          import('../utils/imageUpload').then(({ getUniversalProfileImage, getUserDisplayName }) => {
            const displayName = getUserDisplayName ? getUserDisplayName(post.authorEmail, post.author) : (post.author || 'Unknown Author');
            const profileImage = getUniversalProfileImage(post.authorEmail, post.author, displayName);

            setAuthorProfile({
              displayName,
              profileImage: profileImage || getAuthorProfileImage(),
              lastUpdated: Date.now()
            });
          });
        });
      } catch (error) {
        console.error('Error loading author profile in PostCard:', error);
        setAuthorProfile({
          displayName: post.author || 'Unknown Author',
          profileImage: getAuthorProfileImage(),
          lastUpdated: Date.now()
        });
      }
    };

    // Helper function to get author profile image with proper fallback
    const getAuthorProfileImage = () => {
      try {
        // For admin posts, ensure we check with proper admin identification
        const isAdminPost = post.author === 'Maanya Arora' ||
                           post.authorEmail === 'help@lushivie.com' ||
                           post.authorEmail === 'glamour.bymaanya@gmail.com';

        if (isAdminPost) {
          // Direct import for immediate use
          import('../utils/profileUtils').then(({ getUniversalProfileImage }) => {
            const profileImage = getUniversalProfileImage(
              post.authorEmail || 'help@lushivie.com', // Provide fallback admin email
              post.author,
              'Maanya Arora'
            );
            console.log('Admin profile image in PostCard:', profileImage);
            if (profileImage && profileImage !== 'https://i.ibb.co/zH5KTH4n/IMG-20250811-194616-255.jpg') {
              setAuthorProfile(prev => ({
                ...prev,
                profileImage: profileImage,
                lastUpdated: Date.now()
              }));
            }
          });
        }

        // Immediate fallback for synchronous return
        return post.authorImage || post.profileImage ||
               (isAdminPost ? 'https://i.ibb.co/zH5KTH4n/IMG-20250811-194616-255.jpg' : null);
      } catch (error) {
        console.error('Error getting author profile image in PostCard:', error);
        const isAdminPost = post.author === 'Maanya Arora' ||
                           post.authorEmail === 'help@lushivie.com';
        return isAdminPost ? 'https://i.ibb.co/zH5KTH4n/IMG-20250811-194616-255.jpg' : null;
      }
    };

    // Initial load
    loadAuthorProfile();

    // Enhanced event listeners for real-time updates with Firebase and ImgBB support
    const handleProfileUpdate = debounce((event) => {
      if (!isMounted.current) return;

      console.log('Profile update detected in PostCard:', event.type);

      // Only update if it's an admin post and the event is relevant
      const isAdminPost = post.author === 'Maanya Arora' ||
                         post.authorEmail === 'help@lushivie.com' ||
                         post.authorEmail === 'glamour.bymaanya@gmail.com';

      if (isAdminPost || event.type === 'storage') {
        setImageUrl(prevUrl => {
          const newUrl = getCurrentUserProfileImage(authorName, authorEmail, prevUrl);
          return newUrl;
        });
      }
    }, 500); // Increased debounce to 500ms


    const eventTypes = [
      'profileUpdated', 'adminProfileUpdated', 'adminProfilePersisted',
      'userProfileUpdated', 'storage', 'lushivie-profile-changed', 'globalImageUpdate',
      'forceProfileRefresh', 'globalAdminProfileSync', 'globalAdminProfileUpdated',
      'adminProfileGlobalSync', 'maanyaProfileUpdated', 'globalAuthorProfileSync',
      'visitorProfileRefresh', 'imgbbImageUploaded', 'firestoreProfileUpdated',
      'imgbbProfileSync', 'firebaseAdminProfileUpdated', 'globalAdminProfileSync'
    ];

    eventTypes.forEach(eventType => {
      window.addEventListener(eventType, handleProfileUpdate);
    });

    // Enhanced storage listener for cross-tab updates
    const handleStorageChange = (e) => {
      if (e.key && (
        e.key.includes('lushivie-user-profile') ||
        e.key.includes('lushivie-admin-profile') ||
        e.key.includes('lushivie-global-admin') ||
        e.key === 'lushivie-user-profile'
      )) {
        handleProfileUpdate({ type: 'storage' });
      }
    };

    window.addEventListener('storage', handleStorageChange);

    // Periodic refresh for admin profiles to ensure they're always up-to-date
    let intervalId = null;
    const isAdminPost = post.author === 'Maanya Arora' ||
                       post.authorEmail === 'help@lushivie.com' ||
                       post.authorEmail === 'glamour.bymaanya@gmail.com';

    if (isAdminPost) {
      intervalId = setInterval(() => {
        loadAuthorProfile();
      }, 5000); // Check every 5 seconds for admin profiles
    }

    return () => {
      eventTypes.forEach(eventType => {
        window.removeEventListener(eventType, handleProfileUpdate);
      });
      window.removeEventListener('storage', handleStorageChange);
      if (intervalId) {
        clearInterval(intervalId);
      }
    };
  }, [post.author, post.authorEmail, post.id]);