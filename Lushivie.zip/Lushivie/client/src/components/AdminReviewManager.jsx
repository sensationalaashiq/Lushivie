import React, { useState, useEffect } from 'react';
import { Star, Check, Trash2, RefreshCw, User, Calendar, Mail } from 'lucide-react';
import { useToast } from './Toast';
import { getUniversalProfileImage } from '../utils/profileUtils';

// Star Rating Display Component
function StarRating({ rating, size = 16 }) {
  return (
    <div className="flex items-center space-x-1">
      {[1, 2, 3, 4, 5].map((star) => (
        <Star
          key={star}
          size={size}
          className={`${
            star <= rating
              ? 'text-yellow-400 fill-yellow-400'
              : 'text-gray-300 dark:text-gray-600'
          }`}
        />
      ))}
    </div>
  );
}

// Compact Review Card for Admin
function AdminReviewCard({ review, onApprove, onDelete }) {
  const formatDate = (timestamp) => {
    try {
      const date = timestamp?.toDate ? timestamp.toDate() : new Date(timestamp);
      return date.toLocaleDateString('en-IN', {
        day: '2-digit',
        month: 'short',
        hour: '2-digit',
        minute: '2-digit'
      });
    } catch (error) {
      return 'Recent';
    }
  };

  const getInitials = (name) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
  };

  const getUserProfileImage = (userEmail, authorName) => {
    // Force refresh based on profileUpdateTrigger
    const _trigger = profileUpdateTrigger; // Use trigger to force re-evaluation

    // For admin users, ensure proper lookup
    if (authorName === 'Maanya Arora' || (userEmail && ['help@lushivie.com', 'glamour.bymaanya@gmail.com'].includes(userEmail.toLowerCase()))) {
      return getUniversalProfileImage(userEmail || 'help@lushivie.com', 'Maanya Arora', 'Maanya Arora');
    }
    
    return getUniversalProfileImage(userEmail, authorName, authorName);
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl p-4 border border-gray-200 dark:border-gray-700 shadow-sm hover:shadow-md transition-all duration-200">
      {/* Header with DP and status */}
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center space-x-3 flex-1 min-w-0">
          <div className="w-8 h-8 rounded-full overflow-hidden flex-shrink-0 border border-gray-200 dark:border-gray-600">
            {(() => {
              // Get profile image with proper admin handling
              let profileImage = null;
              
              if (review.name === 'Maanya Arora' || (review.userEmail && ['help@lushivie.com', 'glamour.bymaanya@gmail.com'].includes(review.userEmail.toLowerCase()))) {
                profileImage = getUniversalProfileImage(review.userEmail || review.email || 'help@lushivie.com', 'Maanya Arora', 'Maanya Arora');
              } else {
                profileImage = review.profileImage || review.userPhoto || getUserProfileImage(review.userEmail || review.email, review.name);
              }
              
              return profileImage ? (
                <img
                  src={profileImage}
                  alt={review.name}
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    e.target.style.display = 'none';
                    e.target.nextElementSibling.style.display = 'flex';
                  }}
                />
              ) : null;
            })()}
            <div className="w-8 h-8 bg-gradient-to-br from-rose-400 to-pink-600 flex items-center justify-center" style={{display: 'none'}}>
              <span className="text-white font-bold text-xs">
                {getInitials(review.name)}
              </span>
            </div>
          </div>
          <div className="min-w-0 flex-1">
            <h4 className="font-semibold text-sm text-gray-800 dark:text-white truncate">
              {review.name}
            </h4>
            <p className="text-xs text-gray-500 dark:text-gray-400 truncate">
              {review.email}
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-2 flex-shrink-0">
          <StarRating rating={review.rating} size={14} />
          <span className={`px-2 py-1 rounded-full text-xs font-medium ${
            review.approved
              ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300'
              : 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300'
          }`}>
            {review.approved ? 'Live' : 'Pending'}
          </span>
        </div>
      </div>

      {/* Review Text */}
      <div className="mb-3">
        <p className="text-sm text-gray-700 dark:text-gray-300 leading-relaxed line-clamp-3 break-words">
          "{review.reviewText}"
        </p>
      </div>

      {/* Footer with date and actions */}
      <div className="flex items-center justify-between pt-3 border-t border-gray-100 dark:border-gray-700">
        <div className="flex items-center space-x-1 text-xs text-gray-500 dark:text-gray-400">
          <Calendar size={12} />
          <span>{formatDate(review.createdAt || review.timestamp)}</span>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={() => onApprove(review.id, review.approved)}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors flex items-center space-x-1 ${
              review.approved
                ? 'bg-yellow-100 hover:bg-yellow-200 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300'
                : 'bg-green-100 hover:bg-green-200 text-green-800 dark:bg-green-900/30 dark:text-green-300'
            }`}
            title={review.approved ? 'Hide from public' : 'Approve and publish'}
          >
            <Check size={12} />
            <span>{review.approved ? 'Hide' : 'Approve'}</span>
          </button>

          <button
            onClick={() => onDelete(review.id)}
            className="px-3 py-1.5 bg-red-100 hover:bg-red-200 text-red-800 dark:bg-red-900/30 dark:text-red-300 rounded-lg text-xs font-medium transition-colors flex items-center space-x-1"
            title="Delete review permanently"
          >
            <Trash2 size={12} />
            <span>Delete</span>
          </button>
        </div>
      </div>
    </div>
  );
}

// Main Admin Review Manager Component
export default function AdminReviewManager() {
  const [reviews, setReviews] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [stats, setStats] = useState({ total: 0, pending: 0, approved: 0, averageRating: 0 });
  const [profileUpdateTrigger, setProfileUpdateTrigger] = useState(0);
  const toast = useToast();

  const fetchReviews = async () => {
    setIsLoading(true);
    try {
      const response = await fetch('/api/reviews');
      if (!response.ok) {
        throw new Error('Failed to fetch reviews');
      }

      const data = await response.json();
      setReviews(data.reviews || []);
      setStats(data.stats || { total: 0, pending: 0, approved: 0, averageRating: 0 });
    } catch (error) {
      console.error('Error fetching reviews:', error);
      toast.error('Failed to load reviews');
      setReviews([]);
      setStats({ total: 0, pending: 0, approved: 0, averageRating: 0 });
    } finally {
      setIsLoading(false);
    }
  };

  const handleApproveReview = async (reviewId, currentStatus) => {
    try {
      const response = await fetch(`/api/reviews/${reviewId}/approve`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          approved: !currentStatus
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to update review');
      }

      const result = await response.json();

      setReviews(prev => prev.map(review =>
        review.id === reviewId
          ? { ...review, approved: !currentStatus }
          : review
      ));

      // Update stats
      setStats(prev => ({
        ...prev,
        pending: !currentStatus ? prev.pending - 1 : prev.pending + 1,
        approved: !currentStatus ? prev.approved + 1 : prev.approved - 1
      }));

      toast.success(!currentStatus ? 'Review approved!' : 'Review hidden');
    } catch (error) {
      console.error('Error updating review:', error);
      toast.error('Failed to update review');
    }
  };

  const handleDeleteReview = async (reviewId) => {
    toast.confirm(
      "Delete this review permanently?",
      async () => {
        try {
          const response = await fetch(`/api/reviews/${reviewId}`, {
            method: 'DELETE',
          });

          if (!response.ok) {
            throw new Error('Failed to delete review');
          }

          const deletedReview = reviews.find(r => r.id === reviewId);

          setReviews(prev => prev.filter(review => review.id !== reviewId));

          // Update stats
          setStats(prev => ({
            ...prev,
            total: prev.total - 1,
            pending: deletedReview && !deletedReview.approved ? prev.pending - 1 : prev.pending,
            approved: deletedReview && deletedReview.approved ? prev.approved - 1 : prev.approved
          }));

          toast.success('Review deleted successfully!');
        } catch (error) {
          console.error('Error deleting review:', error);
          toast.error('Failed to delete review');
        }
      }
    );
  };

  useEffect(() => {
    fetchReviews();
  }, []);

  // Listen for profile updates to refresh review profile images
  useEffect(() => {
    const handleProfileUpdate = () => {
      console.log('Profile update detected in AdminReviewManager');
      setProfileUpdateTrigger(prev => prev + 1);
      // Force re-render of reviews to show updated profile images
      setReviews(prev => [...prev]);
    };

    const eventTypes = [
      'profileUpdated',
      'adminProfileUpdated', 
      'adminProfilePersisted',
      'userProfileUpdated',
      'globalImageUpdate',
      'lushivie-profile-changed'
    ];

    eventTypes.forEach(eventType => {
      window.addEventListener(eventType, handleProfileUpdate);
    });

    return () => {
      eventTypes.forEach(eventType => {
        window.removeEventListener(eventType, handleProfileUpdate);
      });
    };
  }, []);

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white dark:bg-gray-900 rounded-2xl shadow-xl border border-gray-100 dark:border-gray-800 overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-green-500 to-emerald-600 p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center overflow-hidden">
                <img
                  src="https://i.ibb.co/zH5KTH4n/IMG-20250811-194616-255.jpg"
                  alt="Admin Profile"
                  className="w-full h-full object-cover rounded-xl"
                  onError={(e) => {
                    e.target.style.display = 'none';
                    e.target.parentElement.innerHTML = '<div class="w-full h-full flex items-center justify-center"><svg class="text-white" width="20" height="20" fill="currentColor" viewBox="0 0 24 24"><path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/></svg></div>';
                  }}
                />
              </div>
              <div>
                <h2 className="text-2xl font-bold text-white font-playfair">
                  Review Manager
                </h2>
                <p className="text-green-100 text-sm">Manage customer reviews</p>
              </div>
            </div>

            <button
              onClick={fetchReviews}
              disabled={isLoading}
              className="px-4 py-2 bg-white/20 hover:bg-white/30 text-white rounded-lg font-medium transition-colors flex items-center space-x-2 disabled:opacity-50"
            >
              <RefreshCw size={16} className={isLoading ? 'animate-spin' : ''} />
              <span className="hidden sm:inline">Refresh</span>
            </button>
          </div>
        </div>

        {/* Stats */}
        <div className="p-6 border-b border-gray-200 dark:border-gray-700">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-gray-800 dark:text-white">
                {stats.total}
              </div>
              <div className="text-xs text-gray-600 dark:text-gray-400">Total</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-yellow-600">
                {stats.pending}
              </div>
              <div className="text-xs text-gray-600 dark:text-gray-400">Pending</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">
                {stats.approved}
              </div>
              <div className="text-xs text-gray-600 dark:text-gray-400">Approved</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-600">
                {stats.averageRating.toFixed(1)}
              </div>
              <div className="text-xs text-gray-600 dark:text-gray-400">Avg Rating</div>
            </div>
          </div>
        </div>

        {/* Reviews List */}
        <div className="p-6">
          {isLoading ? (
            <div className="flex items-center justify-center py-12">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-600"></div>
            </div>
          ) : reviews.length === 0 ? (
            <div className="text-center py-12">
              <div className="w-12 h-12 bg-gray-100 dark:bg-gray-800 rounded-xl flex items-center justify-center mx-auto mb-4">
                <User className="text-gray-400" size={20} />
              </div>
              <h3 className="text-lg font-semibold text-gray-800 dark:text-white mb-2">
                No Reviews Yet
              </h3>
              <p className="text-gray-600 dark:text-gray-400 text-sm">
                Customer reviews will appear here
              </p>
            </div>
          ) : (
            <div className="space-y-4 max-h-96 overflow-y-auto">
              {reviews.map((review) => (
                <AdminReviewCard
                  key={review.id}
                  review={review}
                  onApprove={handleApproveReview}
                  onDelete={handleDeleteReview}
                />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}