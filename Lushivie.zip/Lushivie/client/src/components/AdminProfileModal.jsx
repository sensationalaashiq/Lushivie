
import { useState, useEffect, useRef } from 'react';
import { X, User, Camera, Save, Mail, MapPin, Edit3, Calendar, Shield, Upload, Check, AlertCircle } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from './Toast';
import {
  getCurrentUserProfileImage,
  getInitialsFromName,
  saveUserProfile,
  getUserProfile,
  uploadProfileImage,
  isValidImageFile,
  getProfileFromFirestore,
  saveProfileToFirestore
} from '../utils/profileUtils';

export default function AdminProfileModal({ isOpen, onClose }) {
  const { user, isOwner } = useAuth();
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [profile, setProfile] = useState({
    displayName: '',
    bio: '',
    profileImage: '',
    location: 'Delhi, India',
    email: '',
    website: 'https://lushivie.com'
  });
  const [success, setSuccess] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);

  // CRASH-PROOF: Single cleanup system with render throttling
  const cleanup = useRef({
    timers: new Set(),
    intervals: new Set(),
    mounted: true,
    lastRender: 0,
    renderThrottle: 100 // Minimum 100ms between renders
  });

  // Safe timer functions with render throttling
  const safeSetTimeout = (fn, delay) => {
    if (!cleanup.current.mounted) return null;
    const timer = setTimeout(() => {
      cleanup.current.timers.delete(timer);
      if (cleanup.current.mounted) {
        const now = Date.now();
        if (now - cleanup.current.lastRender > cleanup.current.renderThrottle) {
          cleanup.current.lastRender = now;
          fn();
        }
      }
    }, delay);
    cleanup.current.timers.add(timer);
    return timer;
  };

  const safeSetInterval = (fn, delay) => {
    if (!cleanup.current.mounted) return null;
    const interval = setInterval(() => {
      if (cleanup.current.mounted) {
        const now = Date.now();
        if (now - cleanup.current.lastRender > cleanup.current.renderThrottle) {
          cleanup.current.lastRender = now;
          fn();
        }
      }
    }, delay);
    cleanup.current.intervals.add(interval);
    return interval;
  };

  const clearAllTimers = () => {
    cleanup.current.timers.forEach(timer => clearTimeout(timer));
    cleanup.current.intervals.forEach(interval => clearInterval(interval));
    cleanup.current.timers.clear();
    cleanup.current.intervals.clear();
    
    // CRASH-PROOF: Clear all pending global events
    ['pendingProfileImageEvent', 'pendingProfileSaveEvent', 'pendingRenderEvent', 'pendingEventDispatch'].forEach(key => {
      if (window[key]) {
        clearTimeout(window[key]);
        window[key] = null;
      }
    });
  };

  useEffect(() => {
    cleanup.current.mounted = true;

    if (user && isOpen && isOwner) {
      loadAdminProfile();
    }

    return () => {
      cleanup.current.mounted = false;
      clearAllTimers();
      
      // CRASH-PROOF: Force clear any React render queues
      if (window.pendingEventDispatch) {
        clearTimeout(window.pendingEventDispatch);
        window.pendingEventDispatch = null;
      }
    };
  }, [user, isOpen, isOwner]);

  const loadAdminProfile = async () => {
    if (!cleanup.current.mounted) return;

    setIsLoading(true);
    setError('');
    setSuccess('');

    try {
      let loadedProfile = await getProfileFromFirestore(user.email);

      if (!loadedProfile) {
        const localProfile = await getUserProfile(user.email);
        if (localProfile) {
          loadedProfile = localProfile;
        }
      }

      if (!loadedProfile) {
        loadedProfile = {
          displayName: user.displayName || 'Maanya Arora',
          bio: 'Beauty Expert & Content Creator at Lushivie',
          profileImage: user.photoURL || 'https://i.ibb.co/zH5KTH4n/IMG-20250811-194616-255.jpg',
          location: 'Delhi, India',
          email: user.email || '',
          website: 'https://lushivie.com',
          isOwner: true,
          version: '5.0',
          lastUpdated: new Date()
        };
      }

      if (cleanup.current.mounted) {
        setProfile(loadedProfile);
      }
    } catch (error) {
      console.error('Error loading admin profile:', error);
      if (cleanup.current.mounted) {
        setError('Failed to load profile. Using defaults.');
        setProfile({
          displayName: 'Maanya Arora',
          bio: 'Beauty Expert & Content Creator at Lushivie',
          profileImage: 'https://i.ibb.co/zH5KTH4n/IMG-20250811-194616-255.jpg',
          location: 'Delhi, India',
          email: user.email || '',
          website: 'https://lushivie.com'
        });
      }
    } finally {
      if (cleanup.current.mounted) {
        setIsLoading(false);
      }
    }
  };

  if (!isOpen || !user || !isOwner) return null;

  const handleImageUpload = async (e) => {
    const file = e.target.files[0];
    if (!file || !cleanup.current.mounted) return;

    // Clear any existing operations
    clearAllTimers();

    try {
      isValidImageFile(file);
    } catch (validationError) {
      if (cleanup.current.mounted) {
        setError(validationError.message);
      }
      return;
    }

    if (!cleanup.current.mounted) return;

    setUploading(true);
    setError('');
    setSuccess('');
    setUploadProgress(0);
    
    try {
      // Progress simulation with safe intervals
      const progressInterval = safeSetInterval(() => {
        if (cleanup.current.mounted) {
          setUploadProgress(prev => {
            if (prev >= 85) return 85;
            return Math.min(85, prev + Math.random() * 8 + 2);
          });
        }
      }, 300);

      // Upload timeout protection
      const uploadTimeout = safeSetTimeout(() => {
        if (cleanup.current.mounted) {
          setUploading(false);
          setUploadProgress(0);
          setError('Upload timeout. Please try again.');
        }
      }, 30000);

      const uploadResult = await uploadProfileImage(file);

      if (!cleanup.current.mounted) return;

      if (!uploadResult || !uploadResult.success || !uploadResult.data || !uploadResult.data.url) {
        throw new Error('Upload failed - Invalid response format');
      }

      setUploadProgress(100);

      const imageUrl = uploadResult.data.url;

      const updatedProfile = {
        ...profile,
        profileImage: imageUrl,
        imageUploadedAt: new Date().toISOString(),
        imageSource: 'imgbb',
        lastUpdated: new Date(),
        version: '5.2'
      };

      // Update state first
      setProfile(updatedProfile);

      // CRASH-PROOF: Minimal storage writes to prevent event floods
      try {
        // Only write to ONE storage location to prevent cascade
        await saveProfileToFirestore(user.email, updatedProfile);
        
        // Batch localStorage writes with delay to prevent storage event flooding
        setTimeout(() => {
          if (cleanup.current.mounted) {
            localStorage.setItem('lushivie-user-profile', JSON.stringify(updatedProfile));
          }
        }, 1000);
        
      } catch (storageError) {
        console.warn('Storage save failed (non-critical):', storageError);
      }

      // CRASH-PROOF: Single heavily-debounced event to prevent cascading
      if (cleanup.current.mounted) {
        // Clear ANY pending profile events first
        if (window.pendingEventDispatch) {
          clearTimeout(window.pendingEventDispatch);
        }
        
        window.pendingEventDispatch = setTimeout(() => {
          if (cleanup.current.mounted) {
            try {
              // Only ONE event type - no cascading
              window.dispatchEvent(new CustomEvent('adminProfileUpdated', { 
                detail: { 
                  profileImage: imageUrl,
                  source: 'single-safe-upload',
                  timestamp: Date.now(),
                  preventCascade: true
                }
              }));
              window.pendingEventDispatch = null;
            } catch (eventError) {
              console.warn('Event failed (ignored):', eventError);
            }
          }
        }, 2000); // Heavy 2-second debounce to prevent flooding
      }

      setSuccess('✅ Profile image uploaded successfully!');

      // Auto-clear success message
      safeSetTimeout(() => {
        if (cleanup.current.mounted) {
          setSuccess('');
          setUploadProgress(0);
          setUploading(false);
        }
      }, 3000);

    } catch (error) {
      console.error('Image upload error:', error);
      
      if (cleanup.current.mounted) {
        const errorMessage = error?.message || 'Failed to upload image. Please try again.';
        setError(errorMessage);
        setUploadProgress(0);
        setUploading(false);

        // Auto-clear error message
        safeSetTimeout(() => {
          if (cleanup.current.mounted) {
            setError('');
          }
        }, 5000);
      }
    }
  };

  const handleSave = async (e) => {
    e.preventDefault();
    if (!cleanup.current.mounted) return;

    setLoading(true);
    setError('');
    setSuccess('');

    try {
      if (!profile.displayName?.trim()) {
        throw new Error('Display name is required');
      }

      if (!profile.email?.trim()) {
        throw new Error('Email is required');
      }

      const completeProfile = {
        displayName: profile.displayName.trim(),
        email: profile.email.trim(),
        bio: profile.bio?.trim() || 'Beauty Expert & Content Creator at Lushivie',
        location: profile.location?.trim() || 'Delhi, India',
        website: profile.website?.trim() || 'https://lushivie.com',
        profileImage: profile.profileImage || 'https://i.ibb.co/zH5KTH4n/IMG-20250811-194616-255.jpg',
        isOwner: true,
        version: '5.2',
        lastUpdated: new Date(),
        adminProfile: true
      };

      try {
        await saveProfileToFirestore(user.email, completeProfile);
        localStorage.setItem('lushivie-user-profile', JSON.stringify(completeProfile));
        localStorage.setItem(`lushivie-user-profile-${user.email}`, JSON.stringify(completeProfile));
      } catch (storageError) {
        console.warn('Storage save failed:', storageError);
      }

      setProfile(completeProfile);

      // CRASH-PROOF: No separate save event - use same update event to prevent cascade
      if (cleanup.current.mounted) {
        // Clear any pending events
        if (window.pendingEventDispatch) {
          clearTimeout(window.pendingEventDispatch);
        }
        
        // Use SAME event type as upload to prevent multiple listeners
        window.pendingEventDispatch = setTimeout(() => {
          if (cleanup.current.mounted) {
            try {
              window.dispatchEvent(new CustomEvent('adminProfileUpdated', { 
                detail: { 
                  profile: completeProfile,
                  profileImage: completeProfile.profileImage,
                  source: 'single-safe-save',
                  timestamp: Date.now(),
                  preventCascade: true
                }
              }));
              window.pendingEventDispatch = null;
            } catch (eventError) {
              console.warn('Event failed (ignored):', eventError);
            }
          }
        }, 1500); // Heavy debounce
      }

      setSuccess('🔒 Admin profile saved successfully!');

      safeSetTimeout(() => {
        if (cleanup.current.mounted) {
          setSuccess('');
          if (onClose) onClose();
        }
      }, 2000);

    } catch (error) {
      console.error('Error saving admin profile:', error);

      if (cleanup.current.mounted) {
        const errorMessage = error?.message || 'Failed to save profile';
        setError(errorMessage);

        safeSetTimeout(() => {
          if (cleanup.current.mounted) {
            setError('');
          }
        }, 5000);
      }
    } finally {
      if (cleanup.current.mounted) {
        setLoading(false);
      }
    }
  };

  return (
    <div className="fixed inset-0 z-[120] flex items-center justify-center p-4 bg-black/50">
      <div className="bg-white dark:bg-gray-900 rounded-2xl shadow-2xl max-w-md w-full max-h-[90vh] overflow-y-auto border border-purple-200 dark:border-purple-800">

        {/* Header */}
        <div className="p-6 border-b border-gray-200 dark:border-gray-700 bg-gradient-to-r from-purple-50 to-pink-50 dark:from-purple-900/30 dark:to-pink-900/30">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-purple-600 rounded-lg">
                <Shield className="text-white" size={20} />
              </div>
              <div>
                <h2 className="text-xl font-bold text-gray-900 dark:text-white">Admin Profile</h2>
                <p className="text-sm text-purple-600 dark:text-purple-400">Crash-Free v5.2</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg transition-colors"
              disabled={loading || uploading}
            >
              <X size={20} className="text-gray-500" />
            </button>
          </div>
        </div>

        {/* Status Indicator */}
        <div className="px-6 py-2 bg-green-50 dark:bg-green-900/30 border-b border-green-200 dark:border-green-800">
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
            <span className="text-sm text-green-700 dark:text-green-400 font-medium">
              Hosting-Ready Protection Active
            </span>
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleSave} className="p-6 space-y-6">

          {/* Profile Image */}
          <div className="text-center">
            <div className="relative inline-block">
              <div className="w-28 h-28 rounded-full overflow-hidden border-4 border-purple-200 dark:border-purple-600 mx-auto shadow-lg">
                {isLoading ? (
                  <div className="w-full h-full bg-gray-200 dark:bg-gray-700 animate-pulse flex items-center justify-center">
                    <User size={24} className="text-gray-400" />
                  </div>
                ) : (
                  <img
                    src={profile.profileImage}
                    alt="Profile"
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      e.target.src = 'https://i.ibb.co/zH5KTH4n/IMG-20250811-194616-255.jpg';
                    }}
                  />
                )}
              </div>

              <label className={`absolute bottom-0 right-0 p-2 bg-purple-500 hover:bg-purple-600 rounded-full cursor-pointer shadow-lg transition-colors group ${uploading ? 'opacity-50 cursor-not-allowed' : ''}`}>
                <Camera size={16} className="text-white group-hover:scale-110 transition-transform" />
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="hidden"
                  disabled={uploading || loading}
                />
              </label>

              {uploading && (
                <div className="absolute inset-0 flex items-center justify-center bg-black/50 rounded-full">
                  <div className="text-center">
                    <Upload size={20} className="text-white animate-bounce mx-auto mb-1" />
                    <div className="text-xs text-white font-medium">{uploadProgress}%</div>
                  </div>
                </div>
              )}
            </div>

            {uploading && (
              <div className="mt-3 space-y-2">
                <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2 overflow-hidden">
                  <div
                    className="bg-purple-600 h-2 rounded-full transition-all duration-300 ease-out"
                    style={{ width: `${Math.min(100, uploadProgress)}%` }}
                  ></div>
                </div>
                <p className="text-sm text-purple-600 dark:text-purple-400 font-medium">
                  {uploadProgress < 100 ? 'Uploading safely...' : 'Processing...'}
                </p>
              </div>
            )}
          </div>

          {/* Form Fields */}
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Display Name *
              </label>
              <input
                type="text"
                value={profile.displayName}
                onChange={(e) => setProfile({ ...profile, displayName: e.target.value })}
                className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent bg-white dark:bg-gray-800 text-gray-900 dark:text-white transition-all"
                required
                disabled={loading || isLoading || uploading}
                placeholder="Enter your display name"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Email *
              </label>
              <input
                type="email"
                value={profile.email}
                onChange={(e) => setProfile({ ...profile, email: e.target.value })}
                className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent bg-white dark:bg-gray-800 text-gray-900 dark:text-white transition-all"
                required
                disabled={loading || isLoading || uploading}
                placeholder="Enter your email"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Bio
              </label>
              <textarea
                value={profile.bio}
                onChange={(e) => setProfile({ ...profile, bio: e.target.value })}
                rows={3}
                className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent bg-white dark:bg-gray-800 text-gray-900 dark:text-white resize-none transition-all"
                disabled={loading || isLoading || uploading}
                placeholder="Tell us about yourself..."
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Location
              </label>
              <input
                type="text"
                value={profile.location}
                onChange={(e) => setProfile({ ...profile, location: e.target.value })}
                className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent bg-white dark:bg-gray-800 text-gray-900 dark:text-white transition-all"
                disabled={loading || isLoading || uploading}
                placeholder="Where are you based?"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Website
              </label>
              <input
                type="url"
                value={profile.website}
                onChange={(e) => setProfile({ ...profile, website: e.target.value })}
                className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent bg-white dark:bg-gray-800 text-gray-900 dark:text-white transition-all"
                disabled={loading || isLoading || uploading}
                placeholder="https://your-website.com"
              />
            </div>
          </div>

          {/* Status Messages */}
          {success && (
            <div className="p-4 bg-green-50 dark:bg-green-900/30 border border-green-200 dark:border-green-800 rounded-lg">
              <div className="flex items-center space-x-2">
                <Check size={18} className="text-green-600 dark:text-green-400" />
                <p className="text-green-700 dark:text-green-400 text-sm font-medium">{success}</p>
              </div>
            </div>
          )}

          {error && (
            <div className="p-4 bg-red-50 dark:bg-red-900/30 border border-red-200 dark:border-red-800 rounded-lg">
              <div className="flex items-center space-x-2">
                <AlertCircle size={18} className="text-red-600 dark:text-red-400" />
                <p className="text-red-700 dark:text-red-400 text-sm font-medium">{error}</p>
              </div>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex justify-end space-x-3 pt-4 border-t border-gray-200 dark:border-gray-700">
            <button
              type="button"
              onClick={onClose}
              className="px-6 py-2 text-gray-600 dark:text-gray-300 hover:text-gray-800 dark:hover:text-white transition-colors"
              disabled={loading || uploading}
            >
              Cancel
            </button>

            <button
              type="submit"
              disabled={loading || uploading || isLoading}
              className="px-6 py-3 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white rounded-lg transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed flex items-center space-x-2 shadow-lg hover:shadow-xl transform hover:scale-105"
            >
              {loading || isLoading || uploading ? (
                <>
                  <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full"></div>
                  <span>
                    {uploading ? 'Uploading...' : isLoading ? 'Loading...' : 'Saving...'}
                  </span>
                </>
              ) : (
                <>
                  <Save size={16} />
                  <span>Save Profile</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
