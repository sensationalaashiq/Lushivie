import React, { useState, useEffect, useRef } from 'react';
import { 
  Folder, 
  File, 
  Plus, 
  Save, 
  Download, 
  Upload, 
  Trash2, 
  Edit3, 
  Code, 
  FileText, 
  Settings,
  Play,
  Square,
  Terminal,
  FolderPlus,
  FilePlus,
  ChevronDown,
  ChevronRight,
  X,
  Maximize2,
  Minimize2,
  Copy,
  Search,
  Replace,
  RotateCcw,
  Eye,
  EyeOff,
  Zap,
  Globe,
  Monitor,
  Wrench,
  RefreshCw,
  ExternalLink,
  Split,
  MoreHorizontal,
  Send,
  Minus
} from 'lucide-react';
import { GoogleGenerativeAI } from '@google/generative-ai';

const CodeEditor = () => {
  const [files, setFiles] = useState({});
  const [currentFile, setCurrentFile] = useState(null);
  const [fileStructure, setFileStructure] = useState({});
  const [expandedFolders, setExpandedFolders] = useState(new Set(['root', 'client', 'server']));
  const [isFullScreen, setIsFullScreen] = useState(false);
  const [showTerminal, setShowTerminal] = useState(false);
  const [showWebview, setShowWebview] = useState(true);
  const [terminalOutput, setTerminalOutput] = useState([]);
  const [currentCommand, setCurrentCommand] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [replaceQuery, setReplaceQuery] = useState('');
  const [showSearch, setShowSearch] = useState(false);
  const [isRunning, setIsRunning] = useState(false);
  const [openTabs, setOpenTabs] = useState([]);
  const [fileManagerCollapsed, setFileManagerCollapsed] = useState(false);
  const [autoSaveEnabled, setAutoSaveEnabled] = useState(true);
  const [lastSaved, setLastSaved] = useState(null);
  const [webviewUrl, setWebviewUrl] = useState('');
  const [showDevtools, setShowDevtools] = useState(false);
  const [layoutMode, setLayoutMode] = useState('horizontal');
  const [webviewLoading, setWebviewLoading] = useState(true);
  const [consoleOutput, setConsoleOutput] = useState([]);
  const [showAIAssistant, setShowAIAssistant] = useState(true);
  const [aiInput, setAiInput] = useState('');
  const [aiMessages, setAiMessages] = useState([]);
  const [aiLoading, setAiLoading] = useState(false);
  const [aiAssistantMode, setAIAssistantMode] = useState('advanced');
  const [aiAssistantMinimized, setAiAssistantMinimized] = useState(false);
  const [showFileManagerIcon, setShowFileManagerIcon] = useState(false);
  const [fileManagerOpen, setFileManagerOpen] = useState(false);

  // Initialize Gemini AI
  const GEMINI_API_KEY = 'AIzaSyDiUOH9uH0erJYL8LN2I9OjwZHjB9p3K3o';
  const [genAI, setGenAI] = useState(null);
  const [geminiModel, setGeminiModel] = useState(null);

  // Initialize Gemini AI on component mount
  useEffect(() => {
    try {
      const googleAI = new GoogleGenerativeAI(GEMINI_API_KEY);
      const model = googleAI.getGenerativeModel({ model: "gemini-pro" });
      setGenAI(googleAI);
      setGeminiModel(model);
      console.log('✅ Gemini AI initialized successfully');
    } catch (error) {
      console.error('❌ Failed to initialize Gemini AI:', error);
      addToConsole('Gemini AI initialization failed. Using fallback responses.', 'warning');
    }
  }, []);

  const editorRef = useRef(null);
  const terminalRef = useRef(null);
  const webviewRef = useRef(null);
  const dragRef = useRef({ isDragging: false, startX: 0, startY: 0, offsetX: 0, offsetY: 0 });
  const previewDragRef = useRef({ isDragging: false, startX: 0, startY: 0, offsetX: 0, offsetY: 0 });

  // Enhanced drag handler for preview window with proper viewport constraints
  const handlePreviewDragStart = (event) => {
    // Prevent dragging if clicking on buttons or interactive elements
    if (event.target.tagName === 'BUTTON' || event.target.closest('button') || event.target.tagName === 'IFRAME') {
      return;
    }

    event.preventDefault();
    event.stopPropagation();

    const isTouch = event.type === 'touchstart';
    const clientX = isTouch ? event.touches[0].clientX : event.clientX;
    const clientY = isTouch ? event.touches[0].clientY : event.clientY;
    const panel = event.currentTarget;
    const rect = panel.getBoundingClientRect();

    // Store initial position and drag offset
    previewDragRef.current = {
      isDragging: true,
      startX: clientX,
      startY: clientY,
      offsetX: clientX - rect.left,
      offsetY: clientY - rect.top,
      initialLeft: rect.left,
      initialTop: rect.top,
      panel: panel
    };

    // Set dragging styles immediately
    panel.style.transition = 'none';
    panel.style.cursor = 'grabbing';
    panel.style.zIndex = '99999';
    panel.style.userSelect = 'none';
    panel.style.pointerEvents = 'none'; // Prevent iframe interference
    document.body.style.userSelect = 'none';
    document.body.style.touchAction = 'none';
    document.body.style.overflow = 'hidden'; // Prevent scrolling while dragging

    const handleMove = (moveEvent) => {
      if (!previewDragRef.current.isDragging) return;

      moveEvent.preventDefault();
      moveEvent.stopPropagation();

      const isTouch = moveEvent.type === 'touchmove';
      const currentX = isTouch ? moveEvent.touches[0].clientX : moveEvent.clientX;
      const currentY = isTouch ? moveEvent.touches[0].clientY : moveEvent.clientY;

      // Calculate movement delta from start position
      const deltaX = currentX - previewDragRef.current.startX;
      const deltaY = currentY - previewDragRef.current.startY;

      // Calculate new position based on initial position + delta
      const newX = previewDragRef.current.initialLeft + deltaX;
      const newY = previewDragRef.current.initialTop + deltaY;

      // Get current panel dimensions
      const panelWidth = panel.offsetWidth;
      const panelHeight = panel.offsetHeight;

      // Calculate viewport boundaries with small buffer
      const buffer = 10;
      const minX = -buffer;
      const minY = -buffer;
      const maxX = window.innerWidth - panelWidth + buffer;
      const maxY = window.innerHeight - panelHeight + buffer;

      // Apply strict boundaries
      const boundedX = Math.max(minX, Math.min(newX, maxX));
      const boundedY = Math.max(minY, Math.min(newY, maxY));

      // Apply position directly without transform
      panel.style.left = `${boundedX}px`;
      panel.style.top = `${boundedY}px`;
      panel.style.transform = 'none';
    };

    const handleEnd = (endEvent) => {
      if (!previewDragRef.current.isDragging) return;

      previewDragRef.current.isDragging = false;

      // Restore styles
      panel.style.transition = 'all 0.2s ease-out';
      panel.style.cursor = 'move';
      panel.style.zIndex = showAIAssistant ? '99999' : '50';
      panel.style.userSelect = '';
      panel.style.pointerEvents = '';
      document.body.style.userSelect = '';
      document.body.style.touchAction = '';
      document.body.style.overflow = '';

      // Ensure final position is within bounds
      const rect = panel.getBoundingClientRect();
      const panelWidth = panel.offsetWidth;
      const panelHeight = panel.offsetHeight;
      const buffer = 10;
      
      const minX = -buffer;
      const minY = -buffer;
      const maxX = window.innerWidth - panelWidth + buffer;
      const maxY = window.innerHeight - panelHeight + buffer;
      
      const finalX = Math.max(minX, Math.min(rect.left, maxX));
      const finalY = Math.max(minY, Math.min(rect.top, maxY));
      
      panel.style.left = `${finalX}px`;
      panel.style.top = `${finalY}px`;

      // Cleanup listeners
      document.removeEventListener('mousemove', handleMove, { passive: false });
      document.removeEventListener('mouseup', handleEnd);
      document.removeEventListener('touchmove', handleMove, { passive: false });
      document.removeEventListener('touchend', handleEnd);
    };

    // Add listeners with proper options
    if (isTouch) {
      document.addEventListener('touchmove', handleMove, { passive: false });
      document.addEventListener('touchend', handleEnd);
    } else {
      document.addEventListener('mousemove', handleMove, { passive: false });
      document.addEventListener('mouseup', handleEnd);
    }
  };

  // Smooth resize handler for preview
  const handlePreviewResizeStart = (event) => {
    event.stopPropagation();
    event.preventDefault();

    const isTouch = event.type === 'touchstart';
    const panel = event.currentTarget.closest('#draggable-preview');
    const startX = isTouch ? event.touches[0].clientX : event.clientX;
    const startY = isTouch ? event.touches[0].clientY : event.clientY;
    const startWidth = panel.offsetWidth;
    const startHeight = panel.offsetHeight;

    const handleResize = (moveEvent) => {
      const currentX = isTouch ? moveEvent.touches[0].clientX : moveEvent.clientX;
      const currentY = isTouch ? moveEvent.touches[0].clientY : moveEvent.clientY;

      const newWidth = Math.max(160, Math.min(800, startWidth + (currentX - startX)));
      const newHeight = Math.max(200, Math.min(600, startHeight + (currentY - startY)));

      panel.style.width = `${newWidth}px`;
      panel.style.height = `${newHeight}px`;
    };

    const handleResizeEnd = () => {
      document.removeEventListener('mousemove', handleResize);
      document.removeEventListener('mouseup', handleResizeEnd);
      document.removeEventListener('touchmove', handleResize);
      document.removeEventListener('touchend', handleResizeEnd);
    };

    if (isTouch) {
      document.addEventListener('touchmove', handleResize, { passive: false });
      document.addEventListener('touchend', handleResizeEnd);
    } else {
      document.addEventListener('mousemove', handleResize);
      document.addEventListener('mouseup', handleResizeEnd);
    }
  };

  // Enhanced drag handler for other panels
  const handleDragStart = (event, isTouch = false) => {
    if (event.target.tagName === 'BUTTON' || event.target.closest('button')) {
      return;
    }

    event.preventDefault();
    event.stopPropagation();

    const clientX = isTouch ? event.touches[0].clientX : event.clientX;
    const clientY = isTouch ? event.touches[0].clientY : event.clientY;
    const panel = event.currentTarget;
    const rect = panel.getBoundingClientRect();

    dragRef.current = {
      isDragging: true,
      startX: clientX,
      startY: clientY,
      offsetX: clientX - rect.left,
      offsetY: clientY - rect.top,
      initialTransform: panel.style.transform
    };

    panel.style.transition = 'none';
    panel.style.cursor = 'grabbing';
    panel.style.zIndex = '9999';
    document.body.style.userSelect = 'none';
    document.body.style.touchAction = 'none';

    const handleMove = (moveEvent) => {
      if (!dragRef.current.isDragging) return;

      moveEvent.preventDefault();

      const currentX = isTouch ? moveEvent.touches[0].clientX : moveEvent.clientX;
      const currentY = isTouch ? moveEvent.touches[0].clientY : moveEvent.clientY;

      const x = currentX - dragRef.current.offsetX;
      const y = currentY - dragRef.current.offsetY;

      const buffer = 20;
      const maxX = window.innerWidth - panel.offsetWidth + buffer;
      const maxY = window.innerHeight - panel.offsetHeight + buffer;

      const boundedX = Math.max(-buffer, Math.min(x, maxX));
      const boundedY = Math.max(-buffer, Math.min(y, maxY));

      panel.style.left = `${boundedX}px`;
      panel.style.top = `${boundedY}px`;
      panel.style.transform = 'none';
    };

    const handleEnd = () => {
      dragRef.current.isDragging = false;
      panel.style.transition = 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)';
      panel.style.cursor = 'move';
      panel.style.zIndex = '50';
      document.body.style.userSelect = '';
      document.body.style.touchAction = '';

      document.removeEventListener('mousemove', handleMove);
      document.removeEventListener('mouseup', handleEnd);
      document.removeEventListener('touchmove', handleMove);
      document.removeEventListener('touchend', handleEnd);
    };

    if (isTouch) {
      document.addEventListener('touchmove', handleMove, { passive: false });
      document.addEventListener('touchend', handleEnd, { passive: true });
    } else {
      document.addEventListener('mousemove', handleMove, { passive: false });
      document.addEventListener('mouseup', handleEnd, { passive: true });
    }
  };

  // Initialize webview URL and run button
  useEffect(() => {
    const hostname = window.location.hostname;
    const port = window.location.port || '5000';
    if (hostname.includes('replit') || hostname.includes('repl.co')) {
      setWebviewUrl(`https://${hostname}`);
    } else {
      setWebviewUrl(`http://0.0.0.0:${port}`);
    }
  }, []);

  // File icon helper
  const getFileIcon = (fileName) => {
    const ext = fileName.split('.').pop()?.toLowerCase();
    const iconMap = {
      html: '🌐', htm: '🌐',
      css: '🎨', scss: '🎨', sass: '🎨', less: '🎨',
      js: '⚡', jsx: '⚛️', ts: '🔷', tsx: '⚛️',
      json: '📋', xml: '📄',
      py: '🐍', java: '☕', cpp: '⚙️', c: '⚙️',
      php: '🐘', rb: '💎', go: '🐹', rs: '🦀',
      sql: '🗃️', db: '🗃️', sqlite: '🗃️',
      yml: '⚙️', yaml: '⚙️', toml: '⚙️', ini: '⚙️',
      env: '🔐', gitignore: '🚫',
      md: '📝', txt: '📄', pdf: '📕',
      png: '🖼️', jpg: '🖼️', jpeg: '🖼️', gif: '🖼️', svg: '🎨',
      zip: '📦', tar: '📦', gz: '📦',
      sh: '🔧', bat: '🔧', cmd: '🔧'
    };

    return iconMap[ext] || '📄';
  };

  // Load project files structure
  const loadProjectFiles = async () => {
    try {
      setIsLoading(true);
      const response = await fetch('/api/files/structure');
      const structure = await response.json();

      if (!response.ok) {
        throw new Error(structure.error || 'Failed to load files');
      }

      setFileStructure(structure);
    } catch (error) {
      console.error('Error loading files:', error);
      addToTerminal(`❌ Error loading project files: ${error.message}`, 'error');

      // Fallback to demo structure
      const demoStructure = {
        'client/': {
          'src/': {
            'components/': {
              'CodeEditor.jsx': { type: 'file', size: '25KB' },
              'AuthModal.jsx': { type: 'file', size: '8KB' },
              'PostCard.jsx': { type: 'file', size: '12KB' },
              'Toast.jsx': { type: 'file', size: '3KB' },
              'RichTextEditor.jsx': { type: 'file', size: '9KB' },
              'CustomCodeInjector.jsx': { type: 'file', size: '3KB' },
              'StoryMode.jsx': { type: 'file', size: '7KB' }
            },
            'contexts/': {
              'AuthContext.jsx': { type: 'file', size: '4KB' }
            },
            'utils/': {
              'imageUpload.js': { type: 'file', size: '2KB' },
              'profileUtils.js': { type: 'file', size: '3KB' }
            },
            'App.jsx': { type: 'file', size: '45KB' },
            'main.jsx': { type: 'file', size: '1KB' },
            'index.css': { type: 'file', size: '8KB' },
            'firebase.js': { type: 'file', size: '2KB' }
          },
          'public/': {
            'favicon.svg': { type: 'file', size: '1KB' },
            'robots.txt': { type: 'file', size: '500B' },
            'sitemap.xml': { type: 'file', size: '1KB' }
          },
          'index.html': { type: 'file', size: '2KB' }
        },
        'server/': {
          'index.js': { type: 'file', size: '3KB' },
          'routes.js': { type: 'file', size: '8KB' },
          'vite.js': { type: 'file', size: '4KB' },
          'brevo.js': { type: 'file', size: '2KB' }
        },
        'data/': {
          'posts.json': { type: 'file', size: '5KB' },
          'comments.json': { type: 'file', size: '2KB' },
          'reviews.json': { type: 'file', size: '3KB' }
        },
        'package.json': { type: 'file', size: '2KB' },
        'vite.config.js': { type: 'file', size: '1KB' },
        'tailwind.config.js': { type: 'file', size: '2KB' },
        'README.md': { type: 'file', size: '12KB' },
        '.replit': { type: 'file', size: '500B' },
        'firestore.rules': { type: 'file', size: '1KB' }
      };
      setFileStructure(demoStructure);
    } finally {
      setIsLoading(false);
    }
  };

  // Load file content
  const loadFileContent = async (filePath) => {
    try {
      const response = await fetch(`/api/files/content?path=${encodeURIComponent(filePath)}`);
      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to load file');
      }

      setFiles(prev => ({ ...prev, [filePath]: data.content }));
      addToTerminal(`📂 Loaded: ${filePath}`, 'success');
      return data.content;
    } catch (error) {
      console.error('Error loading file content:', error);
      addToTerminal(`❌ Error loading ${filePath}: ${error.message}`, 'error');

      const demoContent = getDemoContent(filePath);
      setFiles(prev => ({ ...prev, [filePath]: demoContent }));
      return demoContent;
    }
  };

  // Get demo content for files
  const getDemoContent = (filePath) => {
    const demoContents = {
      'package.json': `{
  "name": "lushivie",
  "version": "1.0.0",
  "description": "Luxury Beauty Blog by Maanya Arora",
  "scripts": {
    "dev": "NODE_ENV=development node server/index.js",
    "build": "vite build",
    "start": "node server/index.js",
    "preview": "vite preview"
  },
  "dependencies": {
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "express": "^4.18.2",
    "vite": "^5.0.0",
    "tailwindcss": "^3.3.6"
  }
}`,
      'README.md': `# Lushivie - Luxury Beauty Blog

A premium, full-stack beauty blog platform created by **Maanya Arora** featuring luxury design, comprehensive content management, and SEO optimization.

## ✨ Features

- **Professional IDE**: Replit-style development environment
- **Live Preview**: Real-time webview updates
- **Code Editor**: Syntax highlighting and auto-save
- **Terminal Integration**: Built-in command execution
- **File Management**: Complete file tree with operations

## 🚀 Getting Started

\`\`\`bash
npm install
npm run dev
\`\`\`

## 📧 Contact

- **Email**: Help@lushivie.com
- **Author**: Maanya Arora
`,
      'client/src/App.jsx': `import { Switch, Route } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { useState, useEffect } from "react";
import { AuthProvider } from "./contexts/AuthContext";
import { ToastProvider } from "./components/Toast";
import CustomCodeInjector from "./components/CustomCodeInjector";

const queryClient = new QueryClient();

const App = () => {
  const [theme, setTheme] = useState('light');

  useEffect(() => {
    if (import.meta.hot) {
      import.meta.hot.accept(() => {
        console.log('🔄 Hot reload triggered');
      });
    }
  }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <ToastProvider>
          <CustomCodeInjector />
          <div className="min-h-screen bg-white dark:bg-gray-900">
            <h1 className="text-4xl font-bold text-center py-12">
              Lushivie - Luxury Beauty Blog
            </h1>
            <Switch>
              <Route path="/" component={HomePage} />
              <Route path="/admin" component={AdminPage} />
              <Route component={NotFoundPage} />
            </Switch>
          </div>
        </ToastProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
};

export default App;`
    };

    return demoContents[filePath] || `// ${filePath}\n\n// Professional IDE ready for development\n// Live reload enabled\n// Auto-save configured\n\nconsole.log('Welcome to Lushivie IDE!');`;
  };

  // Console and terminal functions
  const addToConsole = (message, type = 'log') => {
    const timestamp = new Date().toLocaleTimeString();
    setConsoleOutput(prev => [...prev, { message, type, timestamp }]);
  };

  const addToTerminal = (message, type = 'info') => {
    const timestamp = new Date().toLocaleTimeString();
    setTerminalOutput(prev => [...prev, { message, type, timestamp }]);
  };

  // Function to handle running the application
  const runApplication = () => {
    setIsRunning(true);
    setShowWebview(true);
    setWebviewLoading(true);
    addToTerminal('🚀 Starting development server...', 'info');
    addToConsole('Development server starting...', 'log');
    
    // Force preview window to show above assistant when running
    setTimeout(() => {
      addToTerminal('✅ Server running on port 5000', 'success');
      addToConsole('Server ready at http://0.0.0.0:5000', 'success');
      setWebviewLoading(false);
      
      // Position preview window properly when run from assistant
      const previewPanel = document.getElementById('draggable-preview');
      if (previewPanel && showAIAssistant) {
        previewPanel.style.top = '80px';
        previewPanel.style.left = '20px';
        previewPanel.style.width = '400px';
        previewPanel.style.height = '300px';
        previewPanel.style.zIndex = '99999';
      }
    }, 2000);
  };

  // Execute commands
  const executeCommand = async (command) => {
    if (!command.trim()) return;

    addToTerminal(`$ ${command}`, 'command');

    try {
      const parts = command.trim().split(' ');
      const cmd = parts[0];

      if (command.startsWith('npm ') || command.startsWith('node ') || command.startsWith('python ')) {
        addToTerminal('⚡ Running command...', 'info');
        setIsRunning(true);
        setTimeout(() => {
          addToTerminal('✅ Command completed successfully', 'success');
          setIsRunning(false);
        }, 2000);
      } else if (cmd === 'ls' || cmd === 'dir') {
        const files = Object.keys(fileStructure).join('  ');
        addToTerminal(files, 'output');
      } else if (cmd === 'pwd') {
        addToTerminal('/home/runner/lushivie', 'output');
      } else if (cmd === 'clear') {
        setTerminalOutput([]);
        return;
      } else if (cmd === 'help') {
        addToTerminal('🔧 Lushivie IDE Commands:', 'info');
        addToTerminal('npm run dev - Start development server', 'output');
        addToTerminal('npm run build - Build for production', 'output');
        addToTerminal('ls/dir - List files', 'output');
        addToTerminal('clear - Clear terminal', 'output');
        addToTerminal('reload - Refresh webview', 'output');
      } else if (cmd === 'reload') {
        triggerLiveReload();
      } else {
        addToTerminal(`Command not found: ${command}. Type 'help' for available commands.`, 'error');
      }
    } catch (error) {
      addToTerminal(`Error: ${error.message}`, 'error');
    }

    setCurrentCommand('');
  };

  // File tree rendering
  const renderFileTree = (structure, path = '', level = 0) => {
    return Object.entries(structure).map(([name, item]) => {
      const fullPath = path ? `${path}/${name}` : name;
      const isFolder = name.endsWith('/') || (typeof item === 'object' && item.type !== 'file');
      const folderName = name.replace('/', '');
      const isExpanded = expandedFolders.has(fullPath);

      if (isFolder) {
        return (
          <div key={fullPath}>
            <div
              className="flex items-center space-x-2 px-2 py-1 hover:bg-blue-50 dark:hover:bg-gray-800 cursor-pointer rounded group"
              style={{ paddingLeft: `${8 + level * 16}px` }}
              onClick={() => {
                const newExpanded = new Set(expandedFolders);
                if (isExpanded) {
                  newExpanded.delete(fullPath);
                } else {
                  newExpanded.add(fullPath);
                }
                setExpandedFolders(newExpanded);
              }}
            >
              {isExpanded ? <ChevronDown size={14} className="text-gray-500" /> : <ChevronRight size={14} className="text-gray-500" />}
              <Folder size={14} className="text-blue-500" />
              <span className="text-sm font-medium text-gray-700 dark:text-gray-300">{folderName}</span>
            </div>
            {isExpanded && (
              <div>
                {renderFileTree(item, fullPath, level + 1)}
              </div>
            )}
          </div>
        );
      } else {
        return (
          <div
            key={fullPath}
            className={`flex items-center space-x-2 px-2 py-1 hover:bg-blue-50 dark:hover:bg-gray-800 cursor-pointer rounded group ${
              currentFile === fullPath ? 'bg-blue-100 dark:bg-blue-900/30 border-l-2 border-blue-500' : ''
            }`}
            style={{ paddingLeft: `${24 + level * 16}px` }}
            onClick={() => openFile(fullPath)}
          >
            <span className="text-xs">{getFileIcon(name)}</span>
            <span className="text-sm text-gray-700 dark:text-gray-300">{name}</span>
            {item.size && <span className="text-xs text-gray-400 ml-auto">{item.size}</span>}
          </div>
        );
      }
    });
  };

  // Open file in editor - Replit style
  const openFile = async (filePath) => {
    setCurrentFile(filePath);
    setIsFullScreen(true); // Auto open full screen when file is selected
    setFileManagerOpen(false); // Close file manager modal
    setShowFileManagerIcon(false); // Hide the floating icon
    setFileManagerCollapsed(false); // Show file manager in full IDE

    if (!openTabs.find(tab => tab.path === filePath)) {
      const fileName = filePath.split('/').pop();
      setOpenTabs(prev => [...prev, { path: filePath, name: fileName, modified: false }]);
    }

    if (!files[filePath]) {
      await loadFileContent(filePath);
    }

    addToConsole(`📂 Opened: ${filePath}`, 'log');
    addToTerminal(`📂 File opened: ${filePath}`, 'success');
  };

  // Close tab
  const closeTab = (filePath) => {
    setOpenTabs(prev => prev.filter(tab => tab.path !== filePath));
    if (currentFile === filePath) {
      const remainingTabs = openTabs.filter(tab => tab.path !== filePath);
      setCurrentFile(remainingTabs.length > 0 ? remainingTabs[remainingTabs.length - 1].path : null);
    }
  };

  // Save file content
  const saveFileContent = async (filePath, content, isAutoSave = false) => {
    try {
      const response = await fetch('/api/files/save', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ path: filePath, content }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to save file');
      }

      setFiles(prev => ({ ...prev, [filePath]: content }));
      setLastSaved(new Date());

      if (!isAutoSave) {
        addToTerminal(`💾 Saved: ${filePath} (${data.size || 'unknown size'})`, 'success');
        addToConsole(`File saved: ${filePath}`, 'log');
      }

      setOpenTabs(prev => prev.map(tab => 
        tab.path === filePath 
          ? { ...tab, modified: false }
          : tab
      ));

      triggerLiveReload(filePath);

      const savedFiles = JSON.parse(localStorage.getItem('lushivie-editor-files') || '{}');
      savedFiles[filePath] = content;
      localStorage.setItem('lushivie-editor-files', JSON.stringify(savedFiles));
    } catch (error) {
      console.error('Error saving file:', error);
      if (!isAutoSave) {
        addToTerminal(`❌ Error saving ${filePath}: ${error.message}`, 'error');
        addToConsole(`Save error: ${error.message}`, 'error');
      }
    }
  };

  // Live reload functionality
  const triggerLiveReload = (filePath) => {
    if (showWebview && webviewRef.current) {
      addToConsole('🔄 Live reload triggered', 'info');
      addToTerminal('🔄 Reloading preview...', 'info');

      const indicator = document.createElement('div');
      indicator.className = 'live-reload-indicator';
      indicator.textContent = '🔄 Reloading...';
      document.body.appendChild(indicator);

      setTimeout(() => {
        if (webviewRef.current) {
          webviewRef.current.src = webviewRef.current.src;
        }
        if (indicator.parentNode) {
          indicator.parentNode.removeChild(indicator);
        }
        addToConsole('✅ Preview updated', 'success');
      }, 800);
    }
  };

  // Update file content
  const updateFileContent = (content) => {
    if (currentFile) {
      setFiles(prev => ({ ...prev, [currentFile]: content }));

      setOpenTabs(prev => prev.map(tab => 
        tab.path === currentFile 
          ? { ...tab, modified: true }
          : tab
      ));

      if (autoSaveEnabled) {
        clearTimeout(window.autoSaveTimeout);
        window.autoSaveTimeout = setTimeout(() => {
          saveFileContent(currentFile, content, true);
        }, 2000);
      }
    }
  };

  // Save current file
  const saveCurrentFile = () => {
    if (currentFile && files[currentFile]) {
      saveFileContent(currentFile, files[currentFile]);
    }
  };

  // Enhanced AI Assistant with Gemini API integration
  const sendAIMessage = async () => {
    if (!aiInput.trim()) return;

    const newMessage = { 
      sender: 'user', 
      content: aiInput, 
      timestamp: new Date().toLocaleTimeString() 
    };

    setAiMessages(prev => [...prev, newMessage]);
    setAiLoading(true);
    const userInput = aiInput;
    setAiInput('');

    try {
      let assistantResponse = {
        sender: 'assistant',
        content: '',
        timestamp: new Date().toLocaleTimeString(),
        code: null,
        filePath: currentFile,
        actions: []
      };

      // Analyze current file context
      const currentCode = currentFile && files[currentFile] ? files[currentFile] : '';
      const fileExtension = currentFile ? currentFile.split('.').pop() : '';

      // Handle specific IDE actions first
      if (userInput.toLowerCase().includes('run') || userInput.toLowerCase().includes('start')) {
        runApplication();
        assistantResponse.content = `🚀 **Application Started Successfully!**\n\nI've started your development server on port 5000. Here's what's happening:\n\n✅ **Server Status**: Running and ready\n✅ **Live Preview**: Opening above this window\n✅ **Hot Reload**: Enabled for instant updates\n✅ **Console Monitoring**: Active\n\nYour Lushivie beauty blog is now live at http://0.0.0.0:5000\n\n**Quick Actions Available:**\n- Edit files in real-time with auto-save\n- View changes instantly in preview\n- Use terminal for additional commands\n- Access file manager for project navigation`;
        assistantResponse.actions = ['server_started', 'preview_opened'];
      } else if (userInput.toLowerCase().includes('file manager') || userInput.toLowerCase().includes('files')) {
        setFileManagerCollapsed(false);
        setIsFullScreen(true);
        assistantResponse.content = `📁 **File Manager Activated**\n\nI've opened the full file manager for you. Here's what you can do:\n\n**Available Actions:**\n• 📂 Browse all project files\n• ✏️ Edit files directly\n• 🔍 Search through files\n• 📝 Create new files/folders\n• 🗑️ Delete unnecessary files\n• 💾 Auto-save enabled\n\n**Current Project Structure:**\n• \`client/src/components/\` - React components\n• \`server/\` - Backend API routes\n• \`data/\` - JSON data files\n• \`README.md\` - Documentation\n\n**Pro Tips:**\n- Click any file to open in editor\n- Use Ctrl+S to save changes\n- Files auto-save after 2 seconds of inactivity`;
        assistantResponse.actions = ['file_manager_opened', 'full_ide_activated'];
      } else if (userInput.toLowerCase().includes('minimize') || userInput.toLowerCase().includes('hide')) {
        assistantResponse.content = `🔄 **Minimize Options Available**\n\nI can be minimized in several ways:\n\n**Option 1: Minimize to File Manager Icon**\n- Click the minimize button (−) in my header\n- I'll become a floating file manager icon\n- Click the icon to reopen full IDE\n\n**Option 2: Close Completely**\n- Click the close button (×) in my header\n- Use Ctrl+Shift+A to reopen anytime\n\n**Option 3: Switch to Compact Mode**\n- I'll shrink to a smaller window\n- Still functional but takes less space\n\nWhich option would you prefer?`;
        assistantResponse.actions = ['minimize_options_explained'];
      } else {
        // Use Gemini AI for general queries
        if (geminiModel) {
          try {
            // Build context for Gemini
            const contextPrompt = `
You are Lushivie Assistant, an AI coding companion integrated into a luxury beauty blog development environment. 

**Current Context:**
- Project: Lushivie - Luxury beauty blog by Maanya Arora
- Framework: React + Express.js
- Current File: ${currentFile || 'None'}
- File Extension: ${fileExtension || 'N/A'}
- Running Status: ${isRunning ? 'Development server running' : 'Stopped'}
- Loaded Files: ${Object.keys(files).length}

**Current Code Context:**
${currentCode ? `\`\`\`${fileExtension}\n${currentCode.slice(0, 2000)}${currentCode.length > 2000 ? '\n... (truncated)' : ''}\n\`\`\`` : 'No file currently open'}

**Your Role:**
- Provide helpful, specific coding assistance
- Analyze code for improvements and bugs
- Suggest React/JavaScript/Node.js solutions
- Help with beauty blog features and UI/UX
- Keep responses focused and actionable
- Format responses in markdown with clear sections

**User Query:** ${userInput}

Please provide a helpful, technical response that addresses the user's request while considering the Lushivie beauty blog context.
            `;

            console.log('🤖 Sending query to Gemini AI...');
            const result = await geminiModel.generateContent(contextPrompt);
            const response = await result.response;
            const geminiResponse = response.text();

            assistantResponse.content = `🤖 **Gemini AI Response**\n\n${geminiResponse}`;
            assistantResponse.actions = ['gemini_ai_response'];

            // Check if response contains code and extract it
            const codeMatch = geminiResponse.match(/```[\s\S]*?```/g);
            if (codeMatch && codeMatch.length > 0) {
              // Extract the first code block
              const codeBlock = codeMatch[0].replace(/```[\w]*\n?/, '').replace(/```$/, '');
              assistantResponse.code = codeBlock;
              assistantResponse.actions.push('code_generated');
            }

            console.log('✅ Gemini AI response received');
          } catch (geminiError) {
            console.error('❌ Gemini AI Error:', geminiError);
            
            // Fallback to predefined responses if Gemini fails
            if (userInput.toLowerCase().includes('help') || userInput.toLowerCase().includes('what can you do')) {
              assistantResponse.content = `🤖 **Lushivie Assistant - Gemini AI Powered**\n\nI'm your AI-powered development companion with Google Gemini integration:\n\n**🛠️ Code Development:**\n• Analyze and optimize React components\n• Fix JavaScript/JSX errors and bugs\n• Generate production-ready code\n• Add TypeScript support\n• Implement best practices\n\n**📁 File Management:**\n• Create/edit/delete project files\n• Navigate project structure\n• Search across codebase\n• Backup and restore files\n\n**🚀 Development Tools:**\n• Start/stop development server\n• Control live preview window\n• Execute terminal commands\n• Monitor application performance\n• Handle hot reloading\n\n**🎨 UI/UX Enhancement:**\n• Design responsive components\n• Implement accessibility features\n• Add animations and interactions\n• Optimize for mobile devices\n\n**🔧 Advanced Features:**\n• Debug complex issues\n• Performance optimization\n• SEO improvements\n• Database integration\n• API endpoint creation\n\n**Powered by Google Gemini AI for:**\n• Natural language understanding\n• Context-aware responses\n• Advanced code analysis\n• Creative problem solving\n\n**Quick Commands:**\n- "Run app" - Start development server\n- "Fix this code" - Debug current file\n- "Create component" - Generate new React component\n- "Open files" - Access file manager\n- "Minimize" - Hide assistant window\n\n**How to use:** Just tell me what you want to do in plain English!`;
            } else {
              // Generic fallback response
              let contextResponse = '';
              
              if (currentFile) {
                contextResponse = `I can see you're working on **${currentFile.split('/').pop()}**. `;
              }
              
              contextResponse += `I understand you're asking about: "${userInput}"\n\n`;
              
              if (userInput.toLowerCase().includes('error') || userInput.toLowerCase().includes('bug')) {
                contextResponse += `🔍 **Error Analysis Mode**\n\nLet me help debug this issue:\n\n1. **Check the browser console** for error messages\n2. **Verify imports** - Make sure all components are properly imported\n3. **Check syntax** - Look for missing semicolons, brackets, or quotes\n4. **Validate props** - Ensure all required props are passed\n\nShare the specific error message and I'll provide a targeted solution!`;
              } else if (userInput.toLowerCase().includes('style') || userInput.toLowerCase().includes('css')) {
                contextResponse += `🎨 **Styling Assistant**\n\nI can help with:\n• Tailwind CSS classes\n• Responsive design\n• Animations and transitions\n• Dark mode implementation\n• Component styling\n\nDescribe what visual changes you want and I'll provide the exact CSS/Tailwind classes!`;
              } else if (userInput.toLowerCase().includes('api') || userInput.toLowerCase().includes('backend')) {
                contextResponse += `⚙️ **Backend Development**\n\nI can assist with:\n• Creating API endpoints\n• Database integration\n• Authentication setup\n• File upload handling\n• Error handling middleware\n\nWhat specific backend functionality do you need?`;
              } else {
                contextResponse += `💡 **I'm here to help with your Lushivie project!**\n\n**Current Context:**\n• Project: Luxury beauty blog platform\n• Framework: React + Express\n• Status: ${isRunning ? 'Running' : 'Stopped'}\n• Files: ${Object.keys(files).length} loaded\n• Powered by: Google Gemini AI\n\n**What I can do:**\n• Fix code issues and bugs\n• Create new components\n• Optimize performance\n• Add new features\n• Handle file operations\n• Debug problems\n\n**Try specific requests like:**\n- "Add a contact form component"\n- "Fix the navigation menu"\n- "Create a product gallery"\n- "Optimize the homepage"\n- "Add search functionality"\n\n*Note: Gemini AI is temporarily unavailable. Using fallback responses.*`;
              }
              
              assistantResponse.content = contextResponse;
              assistantResponse.actions = ['fallback_response', 'context_analysis'];
            }
          }
        } else {
          // No Gemini model available
          assistantResponse.content = `🤖 **Lushivie Assistant**\n\n⚠️ **Gemini AI Initializing...**\n\nI'm still setting up the Google Gemini integration. Please try again in a moment, or ask me about:\n\n• Starting the development server\n• Opening file manager\n• Basic code assistance\n• Project navigation help\n\n**Your question:** "${userInput}"\n\nI'll have full AI capabilities available shortly!`;
          assistantResponse.actions = ['gemini_initializing'];
        }
      }

      // Add response with delay to simulate processing
      await new Promise(resolve => setTimeout(resolve, Math.random() * 1000 + 500));
      setAiMessages(prev => [...prev, assistantResponse]);
      
      // Log AI actions
      if (assistantResponse.actions?.length) {
        assistantResponse.actions.forEach(action => {
          addToConsole(`🤖 AI Action: ${action}`, 'success');
        });
      }
      
    } catch (error) {
      console.error('AI Assistant Error:', error);
      addToConsole(`AI Error: ${error.message}`, 'error');
      setAiMessages(prev => [...prev, { 
        sender: 'assistant', 
        content: `❌ **Error Occurred**\n\nI encountered an issue: ${error.message}\n\nPlease try again or rephrase your request. I'm here to help!`, 
        timestamp: new Date().toLocaleTimeString() 
      }]);
    } finally {
      setAiLoading(false);
    }
  };

  // Apply AI code suggestions
  const applyAICode = (code, filePath) => {
    if (filePath && files[filePath] !== undefined) {
      setFiles(prev => ({ ...prev, [filePath]: code }));
      setCurrentFile(filePath);
      addToConsole(`AI suggestion applied to ${filePath}`, 'success');
      setOpenTabs(prev => prev.map(tab => 
        tab.path === filePath 
          ? { ...tab, modified: true }
          : tab
      ));
      saveFileContent(filePath, code);
    } else {
      addToConsole('Could not apply AI suggestion: File not open or found.', 'warning');
    }
  };

  // Initialize
  useEffect(() => {
    loadProjectFiles();

    const savedFiles = JSON.parse(localStorage.getItem('lushivie-editor-files') || '{}');
    if (Object.keys(savedFiles).length > 0) {
      setFiles(savedFiles);
    }

    addToTerminal('🚀 Welcome to Lushivie Professional IDE', 'info');
    addToTerminal('⚡ Live reload enabled', 'success');
    addToConsole('IDE initialized successfully', 'log');

    setAiMessages([{
      sender: 'assistant',
      content: '🤖 **Lushivie Assistant - Gemini AI Powered** ✨\n\nWelcome! I\'m your AI development companion powered by Google Gemini:\n\n**🎯 Core Capabilities:**\n• **Gemini AI Integration** - Advanced natural language understanding\n• **Real Code Analysis** - Deep understanding of your codebase\n• **Smart Debugging** - Context-aware problem solving\n• **File Operations** - Create, edit, delete files with real results\n• **Live Development** - Run apps, control previews, manage workflows\n• **Intelligent Responses** - Powered by Google\'s most advanced AI\n\n**🚀 Immediate Actions Available:**\n• **"Run app"** - Start your Lushivie beauty blog instantly\n• **"Open files"** - Access full file manager with all project files\n• **"Fix this code"** - AI-powered debugging and optimization\n• **"Create component"** - Generate production-ready React components\n• **"Explain this code"** - Get detailed explanations of any code\n• **"Optimize performance"** - AI-driven performance improvements\n\n**💡 Gemini AI Features:**\n• Natural conversation about your code\n• Context-aware suggestions\n• Creative problem solving\n• Advanced code generation\n• Intelligent error analysis\n\n**✅ Status:** Gemini API connected and ready\n**🔑 API Key:** Configured and authenticated\n\n**Ready to code with AI?** Try asking me anything about your Lushivie project!\n\nWhat would you like to work on first?',
      timestamp: new Date().toLocaleTimeString()
    }]);

    // Initialize file manager state properly
    if (!fileManagerCollapsed && !showFileManagerIcon) {
      setShowFileManagerIcon(false);
    }
  }, []);

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeydown = (e) => {
      if (e.ctrlKey || e.metaKey) {
        if (e.key === 's') {
          e.preventDefault();
          saveCurrentFile();
        } else if (e.key === 'f') {
          e.preventDefault();
          setShowSearch(true);
        } else if (e.key === '`') {
          e.preventDefault();
          setShowTerminal(prev => !prev);
        } else if (e.key === 'r') {
          e.preventDefault();
          triggerLiveReload();
        } else if (e.key === 'a' && e.shiftKey) {
          e.preventDefault();
          setShowAIAssistant(prev => !prev);
        }
      }
    };

    window.addEventListener('keydown', handleKeydown);
    return () => window.removeEventListener('keydown', handleKeydown);
  }, [currentFile, files]);

  const editorContent = currentFile && files[currentFile] ? files[currentFile] : '';

  if (isFullScreen) {
    return (
      <div className="fixed inset-0 z-[9999] bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-white flex flex-col">
        {/* Professional header */}
        <div className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 p-3 flex items-center justify-between shadow-sm">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
                <Code size={16} className="text-white" />
              </div>
              <h1 className="text-lg font-bold">Lushivie IDE</h1>
            </div>
            <div className="flex items-center space-x-1">
              <button
                onClick={() => {
                  if (!isRunning) {
                    runApplication();
                  } else {
                    setIsRunning(false);
                    addToTerminal('⏹️ Stopping server...', 'info');
                  }
                }}
                className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${
                  isRunning 
                    ? 'bg-red-100 text-red-700 hover:bg-red-200' 
                    : 'bg-green-100 text-green-700 hover:bg-green-200'
                }`}
              >
                {isRunning ? <Square size={14} /> : <Play size={14} />}
                <span>{isRunning ? 'Stop' : 'Run'}</span>
              </button>
              <button
                onClick={() => setShowTerminal(!showTerminal)}
                className="flex items-center space-x-1.5 px-3 py-1.5 bg-gray-100 hover:bg-gray-200 dark:bg-gray-700 dark:hover:bg-gray-600 rounded-lg text-sm"
              >
                <Terminal size={14} />
                <span>Terminal</span>
              </button>
              <button
                onClick={() => setShowAIAssistant(prev => !prev)}
                className="flex items-center space-x-1.5 px-3 py-1.5 bg-purple-100 hover:bg-purple-200 dark:bg-purple-700 dark:hover:bg-purple-600 rounded-lg text-sm text-purple-700 dark:text-purple-300"
              >
                <Zap size={14} />
                <span>Lushivie Assistant</span>
              </button>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <div className="text-xs px-2 py-1 bg-green-100 text-green-700 rounded-full">
              Live
            </div>
            <button
              onClick={() => setIsFullScreen(false)}
              className="flex items-center space-x-1 px-2 py-1 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg text-sm"
              title="Exit Fullscreen"
            >
              <Minimize2 size={14} />
              <span className="hidden sm:inline">Exit</span>
            </button>
          </div>
        </div>

        <div className="flex-1 flex overflow-hidden">
          {/* File Explorer */}
          <div className={`${fileManagerCollapsed ? 'w-12' : 'w-64'} bg-white dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700 flex flex-col flex-shrink-0 transition-all duration-300`}>
            <div className="p-3 border-b border-gray-200 dark:border-gray-700">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => setFileManagerCollapsed(!fileManagerCollapsed)}
                    className="p-1.5 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
                    title={fileManagerCollapsed ? "Expand Files" : "Collapse Files"}
                  >
                    {fileManagerCollapsed ? <ChevronRight size={14} /> : <Folder size={14} />}
                  </button>
                  {!fileManagerCollapsed && (
                    <h3 className="text-sm font-semibold text-gray-700 dark:text-gray-300">FILES</h3>
                  )}
                </div>
                {!fileManagerCollapsed && (
                  <div className="flex space-x-1">
                    <button className="p-1 hover:bg-gray-100 dark:hover:bg-gray-700 rounded" title="New File">
                      <FilePlus size={12} />
                    </button>
                    <button className="p-1 hover:bg-gray-100 dark:hover:bg-gray-700 rounded" title="New Folder">
                      <FolderPlus size={12} />
                    </button>
                  </div>
                )}
              </div>
              {!fileManagerCollapsed && (
                <div className="relative">
                  <Search size={12} className="absolute left-2 top-2 text-gray-400" />
                  <input
                    type="text"
                    placeholder="Search files..."
                    className="w-full pl-7 pr-3 py-1.5 bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-lg text-xs"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
              )}
            </div>

            <div className="flex-1 overflow-y-auto py-2">
              {fileManagerCollapsed ? (
                <div className="flex flex-col items-center space-y-3 pt-4">
                  <button
                    onClick={() => {
                      setFileManagerCollapsed(false);
                      setShowFileManagerIcon(false); // Hide icon when expanding
                    }}
                    className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
                    title="Expand Files"
                  >
                    <Folder size={16} className="text-blue-500" />
                  </button>
                  <div className="w-6 h-px bg-gray-300 dark:bg-gray-600"></div>
                  <File size={14} className="text-gray-400" />
                  <Code size={14} className="text-green-400" />
                  <Search size={14} className="text-purple-400" />
                </div>
              ) : isLoading ? (
                <div className="flex items-center justify-center py-8">
                  <div className="animate-spin w-5 h-5 border-2 border-blue-500 border-t-transparent rounded-full"></div>
                </div>
              ) : (
                renderFileTree(fileStructure)
              )}
            </div>
          </div>

          {/* Main Content Area */}
          <div className="flex-1 flex min-w-0 overflow-hidden">
            {/* Editor Section */}
            <div className={`${showWebview ? 'w-3/4' : 'w-full'} flex flex-col min-w-0`}>
              {/* Tabs */}
              {openTabs.length > 0 && (
                <div className="bg-gray-50 dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 flex overflow-x-auto">
                  {openTabs.map(tab => (
                    <div
                      key={tab.path}
                      className={`flex items-center space-x-2 px-3 py-2 border-r border-gray-200 dark:border-gray-700 cursor-pointer hover:bg-white dark:hover:bg-gray-700 min-w-0 ${
                        currentFile === tab.path ? 'bg-white dark:bg-gray-900 border-t-2 border-t-blue-500' : ''
                      }`}
                      onClick={() => setCurrentFile(tab.path)}
                    >
                      <span className="text-xs">{getFileIcon(tab.name)}</span>
                      <span className="text-xs truncate max-w-24">{tab.name}</span>
                      {tab.modified && <div className="w-1.5 h-1.5 bg-orange-500 rounded-full flex-shrink-0"></div>}
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          closeTab(tab.path);
                        }}
                        className="ml-1 hover:bg-gray-200 dark:hover:bg-gray-600 rounded p-0.5 flex-shrink-0"
                      >
                        <X size={10} />
                      </button>
                    </div>
                  ))}
                </div>
              )}

              {/* Editor */}
              <div className="flex-1 relative">
                {currentFile ? (
                  <div className="h-full flex flex-col">
                    {/* Editor toolbar */}
                    <div className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 px-3 py-2 flex items-center justify-between text-xs">
                      <div className="flex items-center space-x-3">
                        <span className="text-gray-500 dark:text-gray-400 truncate max-w-48">{currentFile}</span>
                        <div className="flex items-center space-x-1">
                          <button
                            onClick={saveCurrentFile}
                            className="flex items-center space-x-1 px-2 py-1 bg-blue-500 hover:bg-blue-600 text-white rounded text-xs"
                          >
                            <Save size={10} />
                            <span>Save</span>
                          </button>
                          <button
                            onClick={() => setAutoSaveEnabled(!autoSaveEnabled)}
                            className={`flex items-center space-x-1 px-2 py-1 rounded text-xs ${
                              autoSaveEnabled ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700'
                            }`}
                          >
                            <Zap size={10} />
                            <span>{autoSaveEnabled ? 'Auto' : 'Manual'}</span>
                          </button>
                        </div>
                      </div>
                      <div className="flex items-center space-x-3 text-gray-500">
                        {lastSaved && (
                          <span className="text-xs text-green-600">
                            Saved: {lastSaved.toLocaleTimeString()}
                          </span>
                        )}
                        <span className="text-xs">
                          UTF-8 • LF • JavaScript
                        </span>
                      </div>
                    </div>

                    {/* Code editor */}
                    <div className="flex-1 overflow-hidden">
                      <textarea
                        ref={editorRef}
                        value={editorContent}
                        onChange={(e) => updateFileContent(e.target.value)}
                        className="w-full h-full p-4 bg-white dark:bg-gray-900 text-gray-900 dark:text-white font-mono text-sm resize-none focus:outline-none overflow-auto border-none"
                        style={{ 
                          fontFamily: 'JetBrains Mono, Monaco, Menlo, "Ubuntu Mono", Consolas, monospace',
                          lineHeight: '1.6',
                          tabSize: 2,
                          whiteSpace: 'pre',
                          wordWrap: 'off'
                        }}
                        spellCheck={false}
                        placeholder="Start coding..."
                      />
                    </div>
                  </div>
                ) : (
                  <div className="h-full flex items-center justify-center bg-white dark:bg-gray-900">
                    <div className="text-center">
                      <Code size={48} className="text-gray-400 mx-auto mb-4" />
                      <h3 className="text-xl text-gray-600 dark:text-gray-400 mb-2">Welcome to Lushivie IDE</h3>
                      <p className="text-gray-500">Select a file to start editing with live reload</p>
                      <div className="mt-4 flex justify-center space-x-2 text-xs">
                        <kbd className="px-2 py-1 bg-gray-100 dark:bg-gray-800 rounded">⌘+S</kbd>
                        <span className="text-gray-400">to save</span>
                        <kbd className="px-2 py-1 bg-gray-100 dark:bg-gray-800 rounded">⌘+R</kbd>
                        <span className="text-gray-400">to reload</span>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Preview Window - Enhanced Draggable */}
            {showWebview && (
              <div 
                id="draggable-preview"
                className="fixed bg-white dark:bg-gray-800 rounded-lg shadow-2xl border border-gray-200 dark:border-gray-700 
                  flex flex-col overflow-hidden transition-shadow duration-300 hover:shadow-3xl cursor-move"
                style={{
                  top: showAIAssistant ? '80px' : '50%',
                  left: showAIAssistant ? '20px' : '50%',
                  transform: showAIAssistant ? 'none' : 'translate(-50%, -50%)',
                  width: showAIAssistant ? '280px' : '160px',
                  height: showAIAssistant ? '220px' : '200px',
                  minWidth: '160px',
                  minHeight: '200px',
                  maxWidth: '800px',
                  maxHeight: '600px',
                  willChange: 'transform',
                  touchAction: 'none',
                  zIndex: showAIAssistant ? '99999' : '50'
                }}
                onMouseDown={handlePreviewDragStart}
                onTouchStart={handlePreviewDragStart}
              >
                {/* Draggable Header */}
                <div className="bg-gradient-to-r from-blue-500 to-purple-600 text-white p-1.5 flex items-center justify-between cursor-move select-none rounded-t-lg">
                  <div className="flex items-center space-x-1">
                    <div className="flex space-x-0.5">
                      <div className="w-1.5 h-1.5 bg-red-400 rounded-full"></div>
                      <div className="w-1.5 h-1.5 bg-yellow-400 rounded-full"></div>
                      <div className="w-1.5 h-1.5 bg-green-400 rounded-full animate-pulse"></div>
                    </div>
                    <h3 className="text-xs font-semibold">
                      {showAIAssistant ? 'Lushivie Preview' : 'Preview'}
                    </h3>
                    {showAIAssistant && (
                      <div className="flex items-center space-x-1">
                        <div className="w-1 h-1 bg-green-400 rounded-full animate-pulse"></div>
                        <span className="text-xs text-green-200 font-medium">Live</span>
                      </div>
                    )}
                  </div>
                  <div className="flex items-center space-x-0.5">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setShowDevtools(!showDevtools);
                      }}
                      className={`p-0.5 hover:bg-white/20 rounded text-xs ${showDevtools ? 'bg-white/20' : ''}`}
                      title="Console"
                    >
                      <Terminal size={8} />
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        const panel = document.getElementById('draggable-preview');
                        const currentWidth = parseInt(panel.style.width) || (showAIAssistant ? 280 : 160);
                        const isSmall = currentWidth <= (showAIAssistant ? 280 : 160);
                        if (showAIAssistant) {
                          panel.style.width = isSmall ? '400px' : '280px';
                          panel.style.height = isSmall ? '300px' : '220px';
                        } else {
                          panel.style.width = isSmall ? '320px' : '160px';
                          panel.style.height = isSmall ? '240px' : '200px';
                        }
                      }}
                      className="p-0.5 hover:bg-white/20 rounded"
                      title="Resize"
                    >
                      <Maximize2 size={8} />
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        triggerLiveReload();
                      }}
                      className="p-0.5 hover:bg-white/20 rounded"
                      title="Refresh"
                    >
                      <RefreshCw size={8} />
                    </button>
                    {showAIAssistant && (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          window.open(webviewUrl, '_blank');
                        }}
                        className="p-0.5 hover:bg-white/20 rounded"
                        title="Open in New Tab"
                      >
                        <ExternalLink size={8} />
                      </button>
                    )}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setShowWebview(false);
                      }}
                      className="p-0.5 hover:bg-white/20 rounded"
                      title="Close"
                    >
                      <X size={8} />
                    </button>
                  </div>
                </div>

                {/* URL Bar */}
                <div className="bg-gray-50 dark:bg-gray-700 border-b border-gray-200 dark:border-gray-600 px-2 py-1 cursor-default">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-1">
                      <div className="flex items-center space-x-0.5">
                        <div className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse"></div>
                        <span className="text-xs text-green-600 dark:text-green-400 font-medium">Live</span>
                      </div>
                      {isRunning && (
                        <span className="text-xs px-1.5 py-0.5 bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300 rounded-full font-medium">
                          Running
                        </span>
                      )}
                    </div>
                    {showAIAssistant && (
                      <div className="flex items-center space-x-1">
                        <span className="text-xs text-gray-500 dark:text-gray-400 font-mono">
                          :5000
                        </span>
                        <div className="w-2 h-2 bg-gradient-to-r from-purple-400 to-blue-400 rounded-full animate-pulse"></div>
                      </div>
                    )}
                  </div>
                </div>

                {/* Content Area */}
                <div className="flex-1 relative overflow-hidden">
                  <iframe
                    ref={webviewRef}
                    src={webviewUrl}
                    className="w-full h-full border-0 pointer-events-auto"
                    onLoad={() => {
                      setWebviewLoading(false);
                      addToConsole('Preview loaded successfully', 'success');
                    }}
                    title="Live Preview"
                    style={{ pointerEvents: 'auto' }}
                  />

                  {webviewLoading && (
                    <div className="absolute inset-0 bg-white dark:bg-gray-900 flex items-center justify-center">
                      <div className="flex flex-col items-center space-y-2">
                        <div className="animate-spin w-6 h-6 border-2 border-blue-500 border-t-transparent rounded-full"></div>
                        <span className="text-xs text-gray-500">Loading preview...</span>
                      </div>
                    </div>
                  )}

                  {showDevtools && (
                    <div className="absolute bottom-0 left-0 right-0 h-16 bg-gray-900 border-t border-gray-700 text-white text-xs overflow-y-auto">
                      <div className="p-1 space-y-0.5">
                        {consoleOutput.slice(-5).map((log, index) => (
                          <div key={index} className={`font-mono text-xs ${
                            log.type === 'error' ? 'text-red-400' :
                            log.type === 'warning' ? 'text-yellow-400' :
                            log.type === 'success' ? 'text-green-400' :
                            'text-gray-300'
                          }`}>
                            <span className="text-gray-500">[{log.timestamp.split(':').slice(-2).join(':')}]</span> {log.message.slice(0, 20)}...
                          </div>
                        ))}
                        {consoleOutput.length === 0 && (
                          <div className="text-gray-500 italic text-xs">Console...</div>
                        )}
                      </div>
                    </div>
                  )}
                </div>

                {/* Resize Handle */}
                <div 
                  className="absolute bottom-0 right-0 w-4 h-4 cursor-se-resize opacity-60 hover:opacity-100 transition-opacity z-10"
                  style={{ 
                    background: 'linear-gradient(-45deg, transparent 30%, #6b7280 30%, #6b7280 40%, transparent 40%, transparent 60%, #6b7280 60%, #6b7280 70%, transparent 70%)'
                  }}
                  onMouseDown={handlePreviewResizeStart}
                  onTouchStart={handlePreviewResizeStart}
                ></div>
              </div>
            )}
          </div>
        </div>

        {/* Terminal */}
        {showTerminal && (
          <div className="h-56 bg-gray-900 border-t border-gray-700 flex flex-col flex-shrink-0">
            <div className="bg-gray-800 px-4 py-2 flex items-center justify-between border-b border-gray-700">
              <div className="flex items-center space-x-2">
                <Terminal size={14} className="text-green-400" />
                <h3 className="text-sm font-semibold text-white">Terminal</h3>
                <div className="text-xs px-2 py-0.5 bg-green-600 text-white rounded">
                  Ready
                </div>
              </div>
              <button
                onClick={() => setShowTerminal(false)}
                className="p-1 hover:bg-gray-700 rounded text-white"
              >
                <X size={14} />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto p-3 font-mono text-sm">
              {terminalOutput.map((output, index) => (
                <div
                  key={index}
                  className={`mb-1 ${
                    output.type === 'error' ? 'text-red-400' :
                    output.type === 'success' ? 'text-green-400' :
                    output.type === 'command' ? 'text-blue-300' :
                    'text-gray-300'
                  }`}
                >
                  <span className="text-gray-500 text-xs mr-2">{output.timestamp}</span>
                  {output.message}
                </div>
              ))}
            </div>
            <div className="bg-gray-800 p-3 flex items-center border-t border-gray-700">
              <span className="text-green-400 mr-2 font-mono">$</span>
              <input
                type="text"
                value={currentCommand}
                onChange={(e) => setCurrentCommand(e.target.value)}
                onKeyPress={(e) => {
                  if (e.key === 'Enter') {
                    executeCommand(currentCommand);
                  }
                }}
                className="flex-1 bg-transparent text-white focus:outline-none font-mono"
                placeholder="Type a command..."
              />
            </div>
          </div>
        )}
      </div>
    );
  }

  // Regular embedded view with minimizable options
  return (
    <div className="bg-white dark:bg-gray-900 rounded-3xl shadow-2xl border border-gray-100 dark:border-gray-800 overflow-hidden">
      <div className="bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-600 p-6 text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-black/10"></div>
        <div className="relative z-10 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="w-14 h-14 bg-white/20 backdrop-blur-sm rounded-2xl flex items-center justify-center">
              <Code size={28} />
            </div>
            <div>
              <h2 className="text-3xl font-bold">Lushivie IDE</h2>
              <p className="text-white/90 text-lg">Professional development environment with AI assistant</p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <button
              onClick={() => setShowAIAssistant(true)}
              className="flex items-center space-x-2 px-4 py-2 bg-purple-500/20 backdrop-blur-sm hover:bg-purple-500/30 rounded-xl transition-all duration-300 text-sm font-medium"
              title="Open Lushivie Assistant"
            >
              <Zap size={16} />
              <span>Assistant</span>
            </button>
            <button
              onClick={() => {
                setFileManagerOpen(true);
                setShowFileManagerIcon(false); // Hide icon when opening the manager
              }}
              className="flex items-center space-x-2 px-4 py-2 bg-white/20 backdrop-blur-sm hover:bg-white/30 rounded-xl transition-all duration-300 text-sm font-medium"
              title="Open File Manager"
            >
              <Folder size={16} />
              <span>Files</span>
            </button>
            <button
              onClick={() => setIsFullScreen(true)}
              className="flex items-center space-x-2 px-4 py-2 bg-white/20 backdrop-blur-sm hover:bg-white/30 rounded-xl transition-all duration-300 text-sm font-medium"
              title="Open Full IDE"
            >
              <Maximize2 size={16} />
              <span>Launch IDE</span>
            </button>
          </div>
        </div>
      </div>

      <div className="p-8">
        {/* Feature grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          <div className="bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-950/20 dark:to-emerald-950/20 p-6 rounded-2xl border border-green-100 dark:border-green-800">
            <div className="flex items-center space-x-3 mb-4">
              <div className="p-2 bg-green-500 rounded-lg">
                <Globe size={20} className="text-white" />
              </div>
              <h3 className="font-bold text-green-800 dark:text-green-300">Live Preview</h3>
            </div>
            <p className="text-green-700 dark:text-green-400 text-sm">Real-time webview updates with smooth dragging</p>
          </div>

          <div className="bg-gradient-to-br from-purple-50 to-violet-50 dark:from-purple-950/20 dark:to-violet-950/20 p-6 rounded-2xl border border-purple-100 dark:border-purple-800">
            <div className="flex items-center space-x-3 mb-4">
              <div className="p-2 bg-purple-500 rounded-lg">
                <Zap size={20} className="text-white" />
              </div>
              <h3 className="font-bold text-purple-800 dark:text-purple-300">Lushivie Assistant</h3>
            </div>
            <p className="text-purple-700 dark:text-purple-400 text-sm">AI-powered coding assistant for real-time help</p>
          </div>

          <div className="bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-blue-950/20 dark:to-indigo-950/20 p-6 rounded-2xl border border-blue-100 dark:border-blue-800">
            <div className="flex items-center space-x-3 mb-4">
              <div className="p-2 bg-blue-500 rounded-lg">
                <Folder size={20} className="text-white" />
              </div>
              <h3 className="font-bold text-blue-800 dark:text-blue-300">Smart File Manager</h3>
            </div>
            <p className="text-blue-700 dark:text-blue-400 text-sm">Minimizable file browser with quick access</p>
          </div>

          <div className="bg-gradient-to-br from-orange-50 to-red-50 dark:from-orange-950/20 dark:to-red-950/20 p-6 rounded-2xl border border-orange-100 dark:border-orange-800">
            <div className="flex items-center space-x-3 mb-4">
              <div className="p-2 bg-orange-500 rounded-lg">
                <Terminal size={20} className="text-white" />
              </div>
              <h3 className="font-bold text-orange-800 dark:text-orange-300">Integrated Terminal</h3>
            </div>
            <p className="text-orange-700 dark:text-orange-400 text-sm">Execute commands directly in browser</p>
          </div>

          <div className="bg-gradient-to-br from-teal-50 to-cyan-50 dark:from-teal-950/20 dark:to-cyan-950/20 p-6 rounded-2xl border border-teal-100 dark:border-teal-800">
            <div className="flex items-center space-x-3 mb-4">
              <div className="p-2 bg-teal-500 rounded-lg">
                <Code size={20} className="text-white" />
              </div>
              <h3 className="font-bold text-teal-800 dark:text-teal-300">Auto-save & Live Reload</h3>
            </div>
            <p className="text-teal-700 dark:text-teal-400 text-sm">Automatic file saving with instant preview updates</p>
          </div>

          <div className="bg-gradient-to-br from-pink-50 to-rose-50 dark:from-pink-950/20 dark:to-rose-950/20 p-6 rounded-2xl border border-pink-100 dark:border-pink-800">
            <div className="flex items-center space-x-3 mb-4">
              <div className="p-2 bg-pink-500 rounded-lg">
                <Monitor size={20} className="text-white" />
              </div>
              <h3 className="font-bold text-pink-800 dark:text-pink-300">Touch-Friendly</h3>
            </div>
            <p className="text-pink-700 dark:text-pink-400 text-sm">Optimized for mobile and tablet development</p>
          </div>
        </div>

        <div className="text-center">
          <p className="text-gray-600 dark:text-gray-300 mb-6 text-lg">
            Experience a complete development environment with Lushivie Assistant and smooth touch interactions.
          </p>
          <div className="flex flex-wrap justify-center gap-4 text-sm">
            <div className="flex items-center space-x-2 px-4 py-2 bg-gray-50 dark:bg-gray-800 rounded-full">
              <kbd className="px-2 py-1 bg-white dark:bg-gray-700 rounded shadow">⌘+S</kbd>
              <span className="text-gray-600 dark:text-gray-400">Save File</span>
            </div>
            <div className="flex items-center space-x-2 px-4 py-2 bg-gray-50 dark:bg-gray-800 rounded-full">
              <kbd className="px-2 py-1 bg-white dark:bg-gray-700 rounded shadow">⌘+Shift+A</kbd>
              <span className="text-gray-600 dark:text-gray-400">Lushivie Assistant</span>
            </div>
          </div>
        </div>
      </div>

      {/* Lushivie Assistant Panel - Full Screen by Default */}
      {showAIAssistant && (
        <div 
          id="lushivie-assistant-panel"
          className="fixed inset-0 bg-white dark:bg-gray-800 z-[9999] flex flex-col"
        >
          {/* Assistant Header */}
          <div className="bg-gradient-to-r from-purple-600 to-blue-600 text-white p-4 flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-white/20 rounded-lg flex items-center justify-center">
                <Zap size={18} />
              </div>
              <div>
                <h3 className="text-xl font-bold">Lushivie Assistant</h3>
                <p className="text-sm text-white/80">AI-powered coding companion</p>
              </div>
              <span className="text-xs px-3 py-1 bg-white/20 rounded-full">Advanced Mode</span>
            </div>
            <div className="flex items-center space-x-2">
              {/* Control Buttons */}
              <div className="flex items-center space-x-1 mr-4">
                <button
                  onClick={() => {
                    if (!isRunning) {
                      runApplication();
                      // Send confirmation message to AI chat
                      setAiMessages(prev => [...prev, {
                        sender: 'assistant',
                        content: '🚀 **Application Started!**\n\nYour development server is now running on port 5000. The live preview window should appear above this assistant.\n\n✅ **What\'s happening:**\n- Server started successfully\n- Live preview is loading\n- Hot reload is enabled\n- Console output is being captured\n\nYou can now see your application running in real-time!',
                        timestamp: new Date().toLocaleTimeString()
                      }]);
                    } else {
                      setIsRunning(false);
                      setShowWebview(false);
                      addToTerminal('⏹️ Stopping server...', 'info');
                      setAiMessages(prev => [...prev, {
                        sender: 'assistant',
                        content: '⏹️ **Application Stopped**\n\nDevelopment server has been stopped. Preview window closed.',
                        timestamp: new Date().toLocaleTimeString()
                      }]);
                    }
                  }}
                  className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${
                    isRunning 
                      ? 'bg-red-500/20 text-red-200 hover:bg-red-500/30' 
                      : 'bg-green-500/20 text-green-200 hover:bg-green-500/30'
                  }`}
                >
                  {isRunning ? <Square size={14} /> : <Play size={14} />}
                  <span>{isRunning ? 'Stop' : 'Run'}</span>
                </button>
                <button
                  onClick={() => {
                    triggerLiveReload();
                    setShowWebview(true);
                  }}
                  className="flex items-center space-x-1.5 px-3 py-1.5 bg-blue-500/20 text-blue-200 hover:bg-blue-500/30 rounded-lg text-sm"
                >
                  <RefreshCw size={14} />
                  <span>Reload</span>
                </button>
                <button
                  onClick={() => setShowTerminal(!showTerminal)}
                  className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-sm ${
                    showTerminal 
                      ? 'bg-yellow-500/20 text-yellow-200 hover:bg-yellow-500/30' 
                      : 'bg-white/10 text-white/80 hover:bg-white/20'
                  }`}
                >
                  <Terminal size={14} />
                  <span>Terminal</span>
                </button>
                <button
                  onClick={() => setShowWebview(!showWebview)}
                  className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-sm ${
                    showWebview 
                      ? 'bg-purple-500/20 text-purple-200 hover:bg-purple-500/30' 
                      : 'bg-white/10 text-white/80 hover:bg-white/20'
                  }`}
                >
                  <Globe size={14} />
                  <span>Preview</span>
                </button>
              </div>
              <button
                onClick={() => {
                  setShowAIAssistant(false);
                  setAiAssistantMinimized(true);
                  setFileManagerCollapsed(false);
                  setShowFileManagerIcon(true);
                  setIsFullScreen(true);
                  addToConsole('AI Assistant minimized to file manager icon', 'info');
                  // Send minimize confirmation to chat
                  setAiMessages(prev => [...prev, {
                    sender: 'assistant',
                    content: '📦 **Assistant Minimized**\n\nI\'m now minimized to the file manager icon in the bottom-left corner. Click the icon anytime to restore me and access the full IDE.\n\n✅ File manager is now accessible\n✅ Full IDE is open for you\n✅ I\'ll be ready when you need me!',
                    timestamp: new Date().toLocaleTimeString()
                  }]);
                }}
                className="p-2 hover:bg-white/20 rounded-lg transition-colors"
                title="Minimize to File Manager Icon"
              >
                <Minus size={16} />
              </button>
              <button
                onClick={() => setShowAIAssistant(false)}
                className="p-2 hover:bg-white/20 rounded-lg"
                title="Close Assistant"
              >
                <X size={16} />
              </button>
            </div>
          </div>

          {/* Chat Messages */}
          <div className="flex-1 overflow-y-auto p-6 space-y-4 bg-gray-50 dark:bg-gray-900">
            {aiMessages.map((message, index) => (
              <div key={index} className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-2xl px-4 py-3 rounded-lg ${
                  message.sender === 'user' 
                    ? 'bg-blue-500 text-white' 
                    : 'bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 shadow-sm'
                }`}>
                  {message.sender === 'assistant' && (
                    <div className="flex items-center space-x-2 mb-2">
                      <Zap size={14} className="text-purple-500" />
                      <span className="text-sm font-medium text-purple-600 dark:text-purple-400">Lushivie Assistant</span>
                    </div>
                  )}
                  <div className="whitespace-pre-wrap text-sm leading-relaxed">{message.content}</div>
                  {message.code && (
                    <div className="mt-3 p-3 bg-gray-100 dark:bg-gray-700 rounded-lg text-xs font-mono">
                      <pre className="whitespace-pre-wrap">{message.code}</pre>
                      <button
                        onClick={() => applyAICode(message.code, message.filePath)}
                        className="mt-3 px-3 py-2 bg-green-500 text-white rounded-lg text-xs hover:bg-green-600 transition-colors"
                      >
                        Apply Changes
                      </button>
                    </div>
                  )}
                  <div className="text-xs opacity-70 mt-2">{message.timestamp}</div>
                </div>
              </div>
            ))}
            {aiLoading && (
              <div className="flex justify-start">
                <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 px-4 py-3 rounded-lg shadow-sm">
                  <div className="flex items-center space-x-3">
                    <div className="animate-spin w-4 h-4 border-2 border-purple-500 border-t-transparent rounded-full"></div>
                    <span className="text-sm">Lushivie Assistant is thinking...</span>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Input Area */}
          <div className="border-t border-gray-200 dark:border-gray-700 p-4 bg-white dark:bg-gray-800">
            <div className="flex items-center space-x-3">
              <input
                type="text"
                value={aiInput}
                onChange={(e) => setAiInput(e.target.value)}
                onKeyPress={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    sendAIMessage();
                  }
                }}
                placeholder="Ask me anything about your code..."
                className="flex-1 px-4 py-3 border border-gray-200 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 dark:bg-gray-700"
              />
              <button
                onClick={sendAIMessage}
                disabled={!aiInput.trim() || aiLoading}
                className="px-4 py-3 bg-purple-500 text-white rounded-lg hover:bg-purple-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                <Send size={16} />
              </button>
            </div>
            <div className="flex items-center justify-between mt-3 text-xs text-gray-500">
              <span>Press Enter to send • Shift+Enter for new line</span>
              <span>Powered by Lushivie AI</span>
            </div>
          </div>
        </div>
      )}

      {/* File Manager Modal */}
      {fileManagerOpen && (
        <div 
          className="fixed inset-0 bg-black/50 backdrop-blur-sm z-[9998] flex items-center justify-center p-4"
          onClick={() => {
            setFileManagerOpen(false);
            setShowFileManagerIcon(true); // Show icon when closing the manager
          }}
        >
          <div 
            className="bg-white dark:bg-gray-800 rounded-lg shadow-2xl border border-gray-200 dark:border-gray-700 w-full max-w-2xl h-96 flex flex-col"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-4 border-b border-gray-200 dark:border-gray-700 flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Folder size={20} className="text-blue-500" />
                <h3 className="text-lg font-semibold">File Manager</h3>
              </div>
              <button
                onClick={() => {
                  setFileManagerOpen(false);
                  setShowFileManagerIcon(true); // Show icon when closing the manager
                }}
                className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg"
              >
                <X size={16} />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-4">
              {isLoading ? (
                <div className="flex items-center justify-center py-8">
                  <div className="animate-spin w-6 h-6 border-2 border-blue-500 border-t-transparent rounded-full"></div>
                </div>
              ) : (
                renderFileTree(fileStructure)
              )}
            </div>
          </div>
        </div>
      )}

      {/* Enhanced File Manager Icon - Replit Style */}
      {showFileManagerIcon && (
        <div className="fixed bottom-6 left-6 z-50">
          <div 
            className="w-16 h-16 bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 rounded-xl shadow-2xl flex flex-col items-center justify-center cursor-pointer transition-all duration-300 hover:scale-110 hover:shadow-3xl group"
            onClick={() => {
              setIsFullScreen(true);
              setFileManagerCollapsed(false);
              setShowFileManagerIcon(false);
              setFileManagerOpen(false);
              setShowAIAssistant(true);
              addToConsole('File Manager and AI Assistant restored', 'success');
            }}
            title="Restore Lushivie Assistant & File Manager"
          >
            <div className="text-center">
              <div className="flex items-center space-x-1 mb-1">
                <Folder size={14} className="text-white" />
                <Zap size={12} className="text-yellow-300 animate-pulse" />
              </div>
              <div className="text-xs text-white font-bold">Lushivie</div>
              <div className="text-xs text-white/80 font-medium">Assistant</div>
            </div>
            
            {/* Notification Badge */}
            <div className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 text-white text-xs rounded-full flex items-center justify-center animate-pulse">
              !
            </div>
          </div>
          
          {/* Tooltip */}
          <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 px-3 py-1 bg-gray-800 text-white text-xs rounded-lg opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
            Click to restore AI Assistant
          </div>
        </div>
      )}
    </div>
  );
};

export default CodeEditor;