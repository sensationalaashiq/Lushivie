
import React, { useState } from 'react';
import { X, Heart, Copy, Check, Gift } from 'lucide-react';

const TipAuthor = ({ post, isOpen, onClose }) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen || !post) return null;

  // Get UPI ID from localStorage or use default
  const getUpiId = () => {
    try {
      const savedConfig = localStorage.getItem('lushivie-upi-config');
      if (savedConfig) {
        const config = JSON.parse(savedConfig);
        return config.upiId || 'aroramaanya@okhdfcbank';
      }
    } catch (error) {
      console.error('Error loading UPI config:', error);
    }
    return 'aroramaanya@okhdfcbank';
  };

  const upiId = getUpiId();
  const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=upi://pay?pa=${upiId}&pn=Lushivie&cu=INR`;

  const copyUpiId = async () => {
    try {
      await navigator.clipboard.writeText(upiId);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy UPI ID:', err);
    }
  };

  return (
    <div 
      className="tip-modal-overlay"
      onClick={onClose}
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        backgroundColor: 'rgba(0, 0, 0, 0.5)',
        zIndex: 1000,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '20px',
        animation: 'fadeIn 0.3s ease-out'
      }}
    >
      <div 
        className="tip-modal-content"
        onClick={(e) => e.stopPropagation()}
        style={{
          backgroundColor: '#ffffff',
          borderRadius: '20px',
          padding: '24px',
          maxWidth: '350px',
          width: '100%',
          maxHeight: '85vh',
          overflowY: 'auto',
          boxShadow: '0 20px 40px rgba(0, 0, 0, 0.15)',
          position: 'relative',
          animation: 'slideUp 0.4s ease-out',
          border: '1px solid #f1f5f9'
        }}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          style={{
            position: 'absolute',
            top: '12px',
            right: '12px',
            width: '28px',
            height: '28px',
            borderRadius: '50%',
            backgroundColor: '#f8fafc',
            border: 'none',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            cursor: 'pointer',
            transition: 'all 0.2s ease',
            color: '#64748b'
          }}
          onMouseEnter={(e) => {
            e.target.style.backgroundColor = '#e2e8f0';
            e.target.style.transform = 'scale(1.1)';
          }}
          onMouseLeave={(e) => {
            e.target.style.backgroundColor = '#f8fafc';
            e.target.style.transform = 'scale(1)';
          }}
        >
          <X size={14} />
        </button>

        {/* Header */}
        <div style={{ textAlign: 'center', marginBottom: '20px' }}>
          <div
            style={{
              width: '48px',
              height: '48px',
              borderRadius: '50%',
              background: 'linear-gradient(135deg, #f59e0b, #ef4444, #ec4899)',
              margin: '0 auto 12px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              boxShadow: '0 6px 20px rgba(244, 63, 94, 0.3)'
            }}
          >
            <Gift size={22} color="white" />
          </div>
          <h2
            style={{
              fontSize: '20px',
              fontWeight: '700',
              marginBottom: '6px',
              background: 'linear-gradient(135deg, #f59e0b, #ef4444)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              backgroundClip: 'text'
            }}
          >
            Show Support & Love
          </h2>
          <p style={{ color: '#64748b', fontSize: '12px', lineHeight: '1.4' }}>
            Support the author for "{post.title.length > 30 ? post.title.substring(0, 30) + '...' : post.title}"
          </p>
        </div>

        {/* QR Code */}
        <div style={{ textAlign: 'center', marginBottom: '18px' }}>
          <div
            style={{
              display: 'inline-block',
              padding: '12px',
              backgroundColor: '#ffffff',
              borderRadius: '12px',
              boxShadow: '0 3px 15px rgba(0, 0, 0, 0.1)',
              border: '2px solid #f1f5f9'
            }}
          >
            <img
              src={qrCodeUrl}
              alt="UPI QR Code"
              style={{
                width: '140px',
                height: '140px',
                display: 'block'
              }}
            />
          </div>
          <p style={{ 
            color: '#64748b', 
            fontSize: '11px', 
            marginTop: '8px',
            fontWeight: '500'
          }}>
            Scan with any UPI app
          </p>
        </div>

        {/* UPI ID */}
        <div style={{ marginBottom: '18px' }}>
          <label style={{ 
            display: 'block', 
            fontSize: '12px', 
            fontWeight: '600', 
            color: '#374151', 
            marginBottom: '6px' 
          }}>
            UPI ID
          </label>
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              backgroundColor: '#f8fafc',
              border: '1px solid #e2e8f0',
              borderRadius: '10px',
              padding: '10px 12px',
              gap: '8px'
            }}
          >
            <input
              type="text"
              value={upiId}
              readOnly
              style={{
                flex: 1,
                backgroundColor: 'transparent',
                border: 'none',
                outline: 'none',
                fontSize: '12px',
                fontFamily: 'monospace',
                color: '#1f2937',
                fontWeight: '500'
              }}
            />
            <button
              onClick={copyUpiId}
              style={{
                padding: '4px',
                borderRadius: '6px',
                backgroundColor: copied ? '#10b981' : '#3b82f6',
                border: 'none',
                color: 'white',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                transition: 'all 0.2s ease',
                minWidth: '24px',
                height: '24px'
              }}
            >
              {copied ? <Check size={12} /> : <Copy size={12} />}
            </button>
          </div>
        </div>

        {/* Footer */}
        <div
          style={{
            textAlign: 'center',
            padding: '12px',
            backgroundColor: '#fef3f2',
            borderRadius: '10px',
            border: '1px solid #fecaca'
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px', marginBottom: '3px' }}>
            <Heart size={14} color="#ef4444" fill="#ef4444" />
            <span style={{ fontSize: '12px', fontWeight: '600', color: '#dc2626' }}>
              Thank you for showing love & support!
            </span>
          </div>
          <p style={{ fontSize: '10px', color: '#7f1d1d', margin: 0 }}>
            Your support helps us create more amazing content
          </p>
        </div>
      </div>

      <style jsx>{`
        @keyframes fadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        
        @keyframes slideUp {
          from {
            opacity: 0;
            transform: translateY(20px) scale(0.95);
          }
          to {
            opacity: 1;
            transform: translateY(0) scale(1);
          }
        }

        @media (max-width: 480px) {
          .tip-modal-content {
            margin: 16px;
            padding: 20px !important;
            max-width: none !important;
          }
        }
      `}</style>
    </div>
  );
};

export default TipAuthor;
