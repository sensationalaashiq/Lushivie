
import React, { useEffect, useState } from 'react';
import { Quote, Copy } from 'lucide-react';

const TextSelector = ({ onQuoteText, isEnabled = true, minTextLength = 10, maxTextLength = 2000 }) => {
  const [selectedText, setSelectedText] = useState('');
  const [toolbarPosition, setToolbarPosition] = useState({ x: 0, y: 0 });
  const [showToolbar, setShowToolbar] = useState(false);

  useEffect(() => {
    if (!isEnabled) return;

    const handleSelection = () => {
      // Small delay to ensure selection is complete
      setTimeout(() => {
        const selection = window.getSelection();
        const text = selection.toString().trim();
        
        if (text && text.length >= minTextLength && text.length <= maxTextLength && selection.rangeCount > 0) {
        const range = selection.getRangeAt(0);
        const rect = range.getBoundingClientRect();
        
        setSelectedText(text);
        // Ensure toolbar position is within viewport
        setToolbarPosition({
          x: Math.max(50, Math.min(window.innerWidth - 200, rect.left + rect.width / 2)),
          y: Math.max(90, rect.top - 70)
        });
        setShowToolbar(true);
      } else {
        setShowToolbar(false);
        if (text && text.length < minTextLength) {
          console.log(`Selection too short - minimum ${minTextLength} characters required`);
        } else if (text && text.length > maxTextLength) {
          console.log(`Selection too long - maximum ${maxTextLength} characters allowed`);
        }
      }
      }, 50); // Small delay to ensure selection is complete
    };

    const handleClickOutside = (e) => {
      if (!e.target.closest('.quote-toolbar')) {
        setShowToolbar(false);
        setSelectedText('');
      }
    };

    document.addEventListener('mouseup', handleSelection);
    document.addEventListener('touchend', handleSelection);
    document.addEventListener('selectionchange', handleSelection);
    document.addEventListener('click', handleClickOutside);

    return () => {
      document.removeEventListener('mouseup', handleSelection);
      document.removeEventListener('touchend', handleSelection);
      document.removeEventListener('selectionchange', handleSelection);
      document.removeEventListener('click', handleClickOutside);
    };
  }, [isEnabled]);

  const handleQuote = () => {
    onQuoteText(selectedText);
    setShowToolbar(false);
    setSelectedText('');
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(selectedText);
    setShowToolbar(false);
    setSelectedText('');
  };

  if (!showToolbar || !selectedText) return null;

  return (
    <div 
      className="quote-toolbar fixed z-[9999] bg-white dark:bg-gray-800 shadow-2xl rounded-lg px-3 py-2 flex items-center gap-2 border border-gray-200 dark:border-gray-700"
      style={{
        left: `${toolbarPosition.x}px`,
        top: `${toolbarPosition.y}px`,
        transform: 'translate(-50%, -120%)',
        pointerEvents: 'auto',
        zIndex: 10000
      }}
    >
      <button
        onClick={handleQuote}
        className="flex items-center gap-1 px-3 py-1 text-sm bg-gradient-to-r from-rose-500 to-pink-600 text-white rounded hover:from-rose-600 hover:to-pink-700 transition-all"
      >
        <Quote size={14} />
        Quote This
      </button>
      <button
        onClick={handleCopy}
        className="flex items-center gap-1 px-3 py-1 text-sm text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded transition-all"
      >
        <Copy size={14} />
        Copy
      </button>
    </div>
  );
};

export default TextSelector;
