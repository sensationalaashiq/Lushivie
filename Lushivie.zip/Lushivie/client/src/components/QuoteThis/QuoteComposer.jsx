import React, { useState, useRef, useEffect } from 'react';
import { X, Download, Share2, Image, Type, Palette, Settings, Eye, Quote } from 'lucide-react';

const QuoteComposer = ({ isOpen, onClose, initialText = '', logoUrl = 'https://i.ibb.co/zH5KTH4n/IMG-20250811-194616-255.jpg' }) => {
  const [quoteText, setQuoteText] = useState(initialText);
  const [selectedTemplate, setSelectedTemplate] = useState(0);
  const [selectedFont, setSelectedFont] = useState('Playfair Display, serif');
  const [textAlign, setTextAlign] = useState('center');
  const [textSize, setTextSize] = useState(24);
  const [lineHeight, setLineHeight] = useState(1.4);
  const [showLogo, setShowLogo] = useState(true);
  const [showAuthor, setShowAuthor] = useState(true);
  const [textColor, setTextColor] = useState('#ffffff');
  const [accentColor, setAccentColor] = useState('#E8B4A0');
  const [dropShadow, setDropShadow] = useState(true);
  const [aspectRatio, setAspectRatio] = useState('square'); // square, story, wide
  const [isGenerating, setIsGenerating] = useState(false);

  const canvasRef = useRef(null);
  const previewRef = useRef(null);

  const templates = [
    {
      name: 'Elegant Pastel',
      background: 'linear-gradient(135deg, #ffeef8 0%, #f0e6ff 100%)',
      primaryColor: '#8B5A8C'
    },
    {
      name: 'Matte Black',
      background: 'linear-gradient(135deg, #1a1a1a 0%, #2d2d2d 100%)',
      primaryColor: '#E8B4A0'
    },
    {
      name: 'Marble Gold',
      background: 'linear-gradient(135deg, #f5f5f5 0%, #e8e8e8 100%)',
      primaryColor: '#D4A574'
    },
    {
      name: 'Soft Gradient',
      background: 'linear-gradient(135deg, #ff9a9e 0%, #fecfef 50%, #fecfef 100%)',
      primaryColor: '#8B1538'
    }
  ];

  const fonts = [
    { name: 'Playfair Display', family: 'Playfair Display, serif', type: 'serif' },
    { name: 'Dancing Script', family: 'Dancing Script, cursive', type: 'cursive' },
    { name: 'Poppins', family: 'Poppins, sans-serif', type: 'sans-serif' }
  ];

  const colorPresets = [
    '#ffffff', '#000000', '#E8B4A0', '#8B1538', '#D4A574', '#F4E4BC',
    '#ff6b6b', '#4ecdc4', '#45b7d1', '#96ceb4', '#feca57', '#ff9ff3'
  ];

  const aspectRatios = {
    square: { width: 1080, height: 1080, label: 'Square (1:1)' },
    story: { width: 1080, height: 1920, label: 'Story (9:16)' },
    wide: { width: 1200, height: 630, label: 'Wide (1.91:1)' }
  };

  useEffect(() => {
    if (isOpen) {
      setQuoteText(initialText);
      // Preload fonts
      fonts.forEach(font => {
        const link = document.createElement('link');
        link.href = `https://fonts.googleapis.com/css2?family=${font.name.replace(' ', '+')}:wght@400;700&display=swap`;
        link.rel = 'stylesheet';
        document.head.appendChild(link);
      });
    }
  }, [isOpen, initialText]);

  const generateImage = async () => {
    setIsGenerating(true);

    try {
      const canvas = canvasRef.current;
      const ctx = canvas.getContext('2d');
      const ratio = window.devicePixelRatio || 1;
      const dimensions = aspectRatios[aspectRatio];

      // Set canvas size for retina
      canvas.width = dimensions.width * ratio;
      canvas.height = dimensions.height * ratio;
      canvas.style.width = dimensions.width + 'px';
      canvas.style.height = dimensions.height + 'px';
      ctx.scale(ratio, ratio);

      // Clear canvas
      ctx.clearRect(0, 0, dimensions.width, dimensions.height);

      // Draw background
      const template = templates[selectedTemplate];
      if (template.background.includes('gradient')) {
        const gradient = ctx.createLinearGradient(0, 0, dimensions.width, dimensions.height);
        if (template.name === 'Elegant Pastel') {
          gradient.addColorStop(0, '#ffeef8');
          gradient.addColorStop(1, '#f0e6ff');
        } else if (template.name === 'Matte Black') {
          gradient.addColorStop(0, '#1a1a1a');
          gradient.addColorStop(1, '#2d2d2d');
        } else if (template.name === 'Marble Gold') {
          gradient.addColorStop(0, '#f5f5f5');
          gradient.addColorStop(1, '#e8e8e8');
        } else if (template.name === 'Soft Gradient') {
          gradient.addColorStop(0, '#ff9a9e');
          gradient.addColorStop(0.5, '#fecfef');
          gradient.addColorStop(1, '#fecfef');
        }
        ctx.fillStyle = gradient;
      } else {
        ctx.fillStyle = template.background;
      }
      ctx.fillRect(0, 0, dimensions.width, dimensions.height);

      // Set text properties
      const font = fonts.find(f => f.family === selectedFont);
      const fontSize = textSize;
      ctx.font = `bold ${fontSize}px ${font.family}`;
      ctx.fillStyle = textColor;
      ctx.textAlign = textAlign;
      ctx.textBaseline = 'middle';

      // Add drop shadow if enabled
      if (dropShadow) {
        ctx.shadowColor = 'rgba(0, 0, 0, 0.3)';
        ctx.shadowBlur = 10;
        ctx.shadowOffsetX = 2;
        ctx.shadowOffsetY = 2;
      }

      // Draw text with line wrapping
      const maxWidth = dimensions.width - 120;
      const words = quoteText.split(' ');
      const lines = [];
      let currentLine = '';

      for (let word of words) {
        const testLine = currentLine + word + ' ';
        const metrics = ctx.measureText(testLine);
        if (metrics.width > maxWidth && currentLine !== '') {
          lines.push(currentLine.trim());
          currentLine = word + ' ';
        } else {
          currentLine = testLine;
        }
      }
      lines.push(currentLine.trim());

      const lineHeightPx = fontSize * lineHeight;
      const totalTextHeight = lines.length * lineHeightPx;
      const startY = (dimensions.height - totalTextHeight) / 2 + lineHeightPx / 2;

      let textX;
      switch (textAlign) {
        case 'left':
          textX = 60;
          break;
        case 'right':
          textX = dimensions.width - 60;
          break;
        default:
          textX = dimensions.width / 2;
      }

      // Draw text with stroke for better visibility
      ctx.lineWidth = 2;
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.8)';

      lines.forEach((line, index) => {
        const y = startY + index * lineHeightPx;
        ctx.strokeText(line, textX, y);
        ctx.fillText(line, textX, y);
      });

      // Reset shadow
      ctx.shadowColor = 'transparent';
      ctx.shadowBlur = 0;
      ctx.shadowOffsetX = 0;
      ctx.shadowOffsetY = 0;

      // Draw author credit if enabled
      if (showAuthor) {
        ctx.font = `16px ${fonts[2].family}`;
        ctx.fillStyle = textColor;
        ctx.textAlign = 'right';
        ctx.shadowColor = 'transparent'; // Ensure no shadow on author text
        ctx.fillText('— by Lushivie', dimensions.width - 60, dimensions.height - 120);
      }

      // Draw logo if enabled
      if (showLogo && logoUrl) {
        try {
          const logo = new Image();
          logo.crossOrigin = 'anonymous';
          await new Promise((resolve, reject) => {
            logo.onload = resolve;
            logo.onerror = reject;
            logo.src = logoUrl;
          });

          const logoSize = 60;
          const logoX = dimensions.width - logoSize - 30;
          const logoY = dimensions.height - logoSize - 30;

          // Draw circular logo
          ctx.save();
          ctx.globalAlpha = 0.8;
          ctx.beginPath();
          ctx.arc(logoX + logoSize / 2, logoY + logoSize / 2, logoSize / 2, 0, 2 * Math.PI);
          ctx.clip();
          ctx.drawImage(logo, logoX, logoY, logoSize, logoSize);
          ctx.restore();
        } catch (error) {
          console.error('Error loading logo:', error);
        }
      }

      // Add copyright
      ctx.font = `12px ${fonts[2].family}`;
      ctx.fillStyle = textColor;
      ctx.globalAlpha = 0.6;
      ctx.textAlign = 'center';
      ctx.shadowColor = 'transparent'; // Ensure no shadow on copyright text
      ctx.fillText('© 2025 Lushivie. Created with ❤️ by Maanya Arora', dimensions.width / 2, dimensions.height - 20);
      ctx.globalAlpha = 1;

    } catch (error) {
      console.error('Error generating image:', error);
    } finally {
      setIsGenerating(false);
    }
  };

  const downloadImage = () => {
    const canvas = canvasRef.current;
    const link = document.createElement('a');
    link.download = `lushivie-quote-${Date.now()}.png`;
    link.href = canvas.toDataURL('image/png');
    link.click();
  };

  const shareImage = async () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    try {
      // For mobile devices with native sharing
      if (navigator.share && 'canShare' in navigator) {
        canvas.toBlob(async (blob) => {
          if (!blob) {
            downloadImage();
            return;
          }
          
          const file = new File([blob], 'lushivie-quote.png', { type: 'image/png' });
          
          if (navigator.canShare && navigator.canShare({ files: [file] })) {
            try {
              await navigator.share({
                title: 'Beautiful Quote from Lushivie',
                text: quoteText.substring(0, 100) + (quoteText.length > 100 ? '...' : ''),
                files: [file]
              });
            } catch (shareError) {
              console.log('Share cancelled or failed:', shareError);
              // Try clipboard as fallback
              copyToClipboard(blob);
            }
          } else {
            copyToClipboard(blob);
          }
        }, 'image/png', 0.9);
      } else {
        // Fallback for desktop browsers
        canvas.toBlob((blob) => {
          if (blob) {
            copyToClipboard(blob);
          } else {
            downloadImage();
          }
        }, 'image/png', 0.9);
      }
    } catch (error) {
      console.error('Error in share function:', error);
      downloadImage();
    }
  };

  const copyToClipboard = async (blob) => {
    try {
      if (navigator.clipboard && window.ClipboardItem) {
        await navigator.clipboard.write([
          new ClipboardItem({ 'image/png': blob })
        ]);
        alert('✅ Image copied to clipboard! You can now paste it anywhere.');
      } else {
        // Fallback: create a temporary URL for sharing
        const url = URL.createObjectURL(blob);
        const tempLink = document.createElement('a');
        tempLink.href = url;
        tempLink.download = `lushivie-quote-${Date.now()}.png`;
        document.body.appendChild(tempLink);
        tempLink.click();
        document.body.removeChild(tempLink);
        URL.revokeObjectURL(url);
        alert('📱 Image downloaded! You can now share it from your downloads.');
      }
    } catch (clipboardError) {
      console.error('Clipboard failed:', clipboardError);
      downloadImage();
    }
  };

  useEffect(() => {
    if (isOpen) {
      // Small delay to ensure canvas is mounted
      setTimeout(() => {
        generateImage();
      }, 100);
    }
  }, [quoteText, selectedTemplate, selectedFont, textAlign, textSize, lineHeight, showLogo, showAuthor, textColor, accentColor, dropShadow, aspectRatio, isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[9999] flex items-center justify-center p-3 bg-black/60">
      <div className="bg-white dark:bg-gray-900 rounded-xl shadow-2xl w-full max-w-lg max-h-[85vh] overflow-hidden border border-gray-200 dark:border-gray-700">
        {/* Compact Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-700 bg-gradient-to-r from-rose-50 to-pink-50 dark:from-rose-950/20 dark:to-pink-950/20">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-gradient-to-r from-rose-500 to-pink-600 rounded-full flex items-center justify-center">
              <Quote className="text-white" size={16} />
            </div>
            <div>
              <h2 className="text-lg font-bold text-gray-900 dark:text-white">Quote This</h2>
              <p className="text-xs text-gray-600 dark:text-gray-400">Create & share</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg transition-colors"
          >
            <X size={18} className="text-gray-500 dark:text-gray-400" />
          </button>
        </div>

        {/* Compact Content */}
        <div className="p-4 space-y-4 max-h-[calc(85vh-80px)] overflow-y-auto">
          {/* Text Input */}
          <div>
            <label className="block text-sm font-medium mb-2 text-gray-700 dark:text-gray-300">Quote Text</label>
            <textarea
              value={quoteText}
              onChange={(e) => setQuoteText(e.target.value)}
              className="w-full h-24 p-3 text-sm border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white resize-none focus:ring-2 focus:ring-rose-500 focus:border-rose-500"
              placeholder="Enter your quote..."
            />
          </div>

          {/* Compact Template Selection */}
          <div>
            <label className="block text-sm font-medium mb-2 text-gray-700 dark:text-gray-300">Template</label>
            <div className="grid grid-cols-3 gap-2">
              {templates.map((template, index) => (
                <button
                  key={index}
                  onClick={() => setSelectedTemplate(index)}
                  className={`relative h-12 rounded-lg overflow-hidden border-2 transition-all ${
                    selectedTemplate === index
                      ? 'border-rose-500 ring-2 ring-rose-500/20'
                      : 'border-gray-200 dark:border-gray-700 hover:border-gray-300'
                  }`}
                  style={{ background: template.background }}
                >
                  <div className="absolute inset-0 flex items-center justify-center">
                    <span
                      className="text-[10px] font-medium px-1.5 py-0.5 rounded"
                      style={{ color: template.primaryColor, background: 'rgba(255,255,255,0.9)' }}
                    >
                      {template.name.split(' ')[0]}
                    </span>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Compact Font Selection */}
          <div>
            <label className="block text-sm font-medium mb-2 text-gray-700 dark:text-gray-300">Font</label>
            <select
              value={selectedFont}
              onChange={(e) => setSelectedFont(e.target.value)}
              className="w-full p-2 text-sm border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-rose-500 focus:border-rose-500"
            >
              {fonts.map(font => (
                <option key={font.family} value={font.family} style={{ fontFamily: font.family }}>
                  {font.name}
                </option>
              ))}
            </select>
          </div>

          {/* Typography Controls */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-sm font-medium mb-1 text-gray-700 dark:text-gray-300">Text Size</label>
              <input
                type="range"
                min="16"
                max="48"
                value={textSize}
                onChange={(e) => setTextSize(Number(e.target.value))}
                className="w-full"
              />
              <span className="text-xs text-gray-500">{textSize}px</span>
            </div>
            <div>
              <label className="block text-sm font-medium mb-1 text-gray-700 dark:text-gray-300">Line Height</label>
              <input
                type="range"
                min="1"
                max="2"
                step="0.1"
                value={lineHeight}
                onChange={(e) => setLineHeight(Number(e.target.value))}
                className="w-full"
              />
              <span className="text-xs text-gray-500">{lineHeight}</span>
            </div>
          </div>

          {/* Text Alignment */}
          <div>
            <label className="block text-sm font-medium mb-2 text-gray-700 dark:text-gray-300">Text Alignment</label>
            <div className="flex gap-2">
              {['left', 'center', 'right'].map((align) => (
                <button
                  key={align}
                  onClick={() => setTextAlign(align)}
                  className={`px-3 py-1.5 rounded-lg border text-sm transition-all capitalize ${
                    textAlign === align
                      ? 'border-rose-500 bg-rose-50 dark:bg-rose-950/20'
                      : 'border-gray-200 dark:border-gray-700'
                  }`}
                >
                  {align}
                </button>
              ))}
            </div>
          </div>

          {/* Colors */}
          <div>
            <label className="block text-sm font-medium mb-2 flex items-center gap-1 text-gray-700 dark:text-gray-300">
              <Palette size={14} />
              Colors
            </label>
            <div className="space-y-2">
              <div>
                <label className="block text-xs text-gray-500 mb-1">Text Color</label>
                <div className="flex gap-2 items-center">
                  <input
                    type="color"
                    value={textColor}
                    onChange={(e) => setTextColor(e.target.value)}
                    className="w-7 h-7 rounded border-gray-300"
                  />
                  <div className="flex gap-1 overflow-x-auto">
                    {colorPresets.map((color) => (
                      <button
                        key={color}
                        onClick={() => setTextColor(color)}
                        className="w-5 h-5 rounded border-2 border-gray-300"
                        style={{ backgroundColor: color }}
                      />
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Aspect Ratio */}
          <div>
            <label className="block text-sm font-medium mb-2 text-gray-700 dark:text-gray-300">Aspect Ratio</label>
            <div className="grid grid-cols-3 gap-1">
              {Object.entries(aspectRatios).map(([key, ratio]) => (
                <button
                  key={key}
                  onClick={() => setAspectRatio(key)}
                  className={`px-2 py-1.5 rounded-lg border text-xs transition-all ${
                    aspectRatio === key
                      ? 'border-rose-500 bg-rose-50 dark:bg-rose-950/20'
                      : 'border-gray-200 dark:border-gray-700'
                  }`}
                >
                  {ratio.label}
                </button>
              ))}
            </div>
          </div>

          {/* Toggles */}
          <div className="space-y-2 col-span-2">
            <label className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={showLogo}
                onChange={(e) => setShowLogo(e.target.checked)}
                className="w-3.5 h-3.5 text-rose-600 rounded"
              />
              <span className="text-sm text-gray-700 dark:text-gray-300">Show logo watermark</span>
            </label>
            <label className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={showAuthor}
                onChange={(e) => setShowAuthor(e.target.checked)}
                className="w-3.5 h-3.5 text-rose-600 rounded"
              />
              <span className="text-sm text-gray-700 dark:text-gray-300">Show author credit</span>
            </label>
            <label className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={dropShadow}
                onChange={(e) => setDropShadow(e.target.checked)}
                className="w-3.5 h-3.5 text-rose-600 rounded"
              />
              <span className="text-sm text-gray-700 dark:text-gray-300">Text drop shadow</span>
            </label>
          </div>

          {/* Compact Preview */}
          <div>
            <label className="block text-sm font-medium mb-2 text-gray-700 dark:text-gray-300">Preview</label>
            <div className="w-full h-48 bg-gray-100 dark:bg-gray-800 rounded-lg overflow-hidden border border-gray-200 dark:border-gray-700 flex items-center justify-center">
              <canvas
                ref={canvasRef}
                width={aspectRatios[aspectRatio].width}
                height={aspectRatios[aspectRatio].height}
                className="max-w-full max-h-full object-contain"
                style={{ 
                  display: 'block',
                  width: 'auto',
                  height: 'auto',
                  maxWidth: '100%',
                  maxHeight: '192px'
                }}
              />
            </div>
          </div>

          {/* Compact Actions */}
          <div className="flex space-x-2 pt-2">
            <button
              onClick={downloadImage}
              disabled={isGenerating}
              className="flex-1 flex items-center justify-center space-x-2 bg-gradient-to-r from-rose-500 to-pink-600 text-white px-4 py-2.5 rounded-lg text-sm font-semibold hover:from-rose-600 hover:to-pink-700 transition-all disabled:opacity-50"
            >
              <Download size={16} />
              <span>Download</span>
            </button>
            <button
              onClick={shareImage}
              disabled={isGenerating}
              className="flex-1 flex items-center justify-center space-x-2 border border-rose-500 text-rose-600 px-4 py-2.5 rounded-lg text-sm font-semibold hover:bg-rose-50 dark:hover:bg-rose-950/20 transition-all disabled:opacity-50"
            >
              <Share2 size={16} />
              <span>Share</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default QuoteComposer;