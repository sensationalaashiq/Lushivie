
import React, { useState } from 'react';
import TextSelector from './TextSelector';
import QuoteComposer from './QuoteComposer';

const QuoteThis = ({ isEnabled = true, logoUrl = 'https://i.ibb.co/zH5KTH4n/IMG-20250811-194616-255.jpg', minTextLength = 10, maxTextLength = 2000 }) => {
  const [isComposerOpen, setIsComposerOpen] = useState(false);
  const [selectedText, setSelectedText] = useState('');

  const handleQuoteText = (text) => {
    setSelectedText(text);
    setIsComposerOpen(true);
    
    // Analytics event
    if (window.gtag) {
      window.gtag('event', 'quote_composer_opened', {
        event_category: 'engagement',
        event_label: 'text_selection',
        value: text.length
      });
    } else {
      console.log('Analytics: Quote composer opened', { textLength: text.length });
    }
  };

  const handleCloseComposer = () => {
    setIsComposerOpen(false);
    setSelectedText('');
  };

  if (!isEnabled) return null;

  return (
    <>
      <TextSelector 
        onQuoteText={handleQuoteText} 
        isEnabled={isEnabled}
        minTextLength={minTextLength}
        maxTextLength={maxTextLength}
      />
      <QuoteComposer
        isOpen={isComposerOpen}
        onClose={handleCloseComposer}
        initialText={selectedText}
        logoUrl={logoUrl}
      />
    </>
  );
};

export default QuoteThis;
