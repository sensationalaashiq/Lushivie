
import { useState } from 'react';
import { X, Heart, Bookmark, Calendar } from 'lucide-react';

function SavedPostsModal({ posts, isOpen, onClose, onPostClick, onRemovePost }) {
  if (!isOpen) return null;

  // Safely parse saved posts with persistent storage fallback
  const getSavedPosts = () => {
    try {
      // Try localStorage first
      let saved = localStorage.getItem('lushivie-saved-posts');
      
      // Try backup storage if main is empty
      if ((!saved || saved === 'undefined' || saved === 'null')) {
        saved = sessionStorage.getItem('lushivie-saved-posts-backup') || 
                localStorage.getItem('lushivie-saved-posts-indexed');
      }

      if (!saved || saved === 'undefined' || saved === 'null') {
        return [];
      }

      const parsedSaved = JSON.parse(saved);
      
      // Handle both old and new format
      if (Array.isArray(parsedSaved)) {
        return parsedSaved; // Old format
      } else if (parsedSaved.postIds && Array.isArray(parsedSaved.postIds)) {
        return parsedSaved.postIds; // New format
      } else {
        return [];
      }
    } catch (error) {
      console.warn('Error parsing saved posts:', error);
      // Don't remove, might be temporary corruption
      return [];
    }
  };

  const savedPostIds = getSavedPosts();
  const savedPosts = posts ? posts.filter(post => {
    const isIncluded = savedPostIds.includes(post.id);
    return isIncluded;
  }) : [];

  console.log('SavedPostsModal - savedPostIds:', savedPostIds);
  console.log('SavedPostsModal - filtered savedPosts:', savedPosts);

  return (
    <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-black/60" onClick={onClose}>
      <div className="relative w-full max-w-4xl max-h-[85vh] bg-white dark:bg-gray-900 rounded-3xl shadow-2xl overflow-hidden p-8" onClick={e => e.stopPropagation()}>
        <button
          onClick={onClose}
          className="absolute top-6 right-6 z-10 p-3 bg-black/20 hover:bg-black/40 rounded-full transition-colors"
        >
          <X size={24} className="text-white" />
        </button>
        
        <h2 className="text-4xl font-black mb-8 bg-gradient-to-r from-rose-600 via-pink-600 to-orange-500 bg-clip-text text-transparent font-playfair text-center">
          Saved Posts
        </h2>

        {savedPosts.length === 0 ? (
          <div className="text-center py-12">
            <div className="w-24 h-24 bg-gradient-to-br from-rose-100 to-pink-100 rounded-full flex items-center justify-center mx-auto mb-6 shadow-lg">
              <Heart className="text-rose-600" size={32} />
            </div>
            <h3 className="text-3xl font-bold mb-4 text-gray-800 dark:text-white font-playfair">No Saved Posts Yet</h3>
            <p className="text-xl text-gray-600 dark:text-gray-300 mb-8">
              Save posts by clicking the heart icon to see them here!
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 overflow-y-auto max-h-[calc(85vh-12rem)]">
            {savedPosts.map(post => (
              <article 
                key={post.id} 
                className="group bg-white dark:bg-gray-800 rounded-2xl overflow-hidden shadow-lg hover:shadow-xl transition-all duration-500 border border-gray-100 dark:border-gray-700"
              >
                <div className="relative overflow-hidden aspect-video">
                  {post.featuredImage && (
                    <img
                      src={post.featuredImage}
                      alt={post.title}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                  )}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                </div>
                
                <div className="p-6">
                  <h3
                    className="font-bold text-xl mb-3 line-clamp-2 text-gray-800 dark:text-white cursor-pointer hover:text-rose-600 transition-colors"
                    onClick={() => { 
                      console.log('Title clicked, calling onPostClick with:', post);
                      if (onPostClick) {
                        onPostClick(post);
                      }
                    }}
                  >
                    {post.title}
                  </h3>
                  <p className="text-sm text-gray-600 dark:text-gray-300 mb-4 line-clamp-2">
                    {post.description || post.excerpt}
                  </p>
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center space-x-2 text-xs text-gray-500 dark:text-gray-400">
                      <Calendar size={14} />
                      <span>{new Date(post.publishedAt).toLocaleDateString()}</span>
                    </div>
                    <button
                      onClick={(e) => {
                        e.stopPropagation(); // Prevent triggering post click
                        console.log('Bookmark remove button clicked for post:', post.id);
                        if (onRemovePost) {
                          onRemovePost(post.id);
                        }
                      }}
                      className="p-2 rounded-lg hover:bg-rose-500/20 text-rose-500 transition-colors"
                      title="Remove from saved"
                    >
                      <Bookmark className="fill-rose-500" size={16} />
                    </button>
                  </div>
                  
                  {/* Action Button */}
                  <div className="mt-3">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        console.log('Read Full Post button clicked with post:', post);
                        if (onPostClick) {
                          onPostClick(post);
                        }
                      }}
                      className="w-full px-4 py-2 bg-gradient-to-r from-rose-500 to-pink-600 text-white rounded-lg font-medium hover:from-rose-600 hover:to-pink-700 transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl text-sm"
                    >
                      Read Full Post
                    </button>
                  </div>
                </div>
              </article>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export default SavedPostsModal;
