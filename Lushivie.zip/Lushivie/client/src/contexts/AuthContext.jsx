
import { createContext, useContext, useState, useEffect } from 'react';
import { auth } from '../firebase';
import { onAuthStateChanged } from 'firebase/auth';

const AuthContext = createContext({});

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [isOwner, setIsOwner] = useState(false);

  // Admin emails - normalized to lowercase for comparison
  const adminEmails = [
    'help@lushivie.com',
    'glamour.bymaanya@gmail.com'
  ];

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      // Only log in development mode
      if (process.env.NODE_ENV === 'development') {
        console.log('Auth state changed:', user ? 'User logged in' : 'User logged out');
      }
      
      setUser(user);
      
      // Check if user is admin/owner
      if (user && user.email && adminEmails.includes(user.email.toLowerCase())) {
        setIsOwner(true);
        if (process.env.NODE_ENV === 'development') {
          console.log('User is owner:', user.email);
        }
      } else {
        setIsOwner(false);
      }
      
      // Ensure user profile exists on login
      if (user && user.email) {
        // Import profileUtils dynamically to avoid circular imports
        import('../utils/profileUtils').then(({ getUserProfile, saveUserProfile }) => {
          const existingProfile = getUserProfile(user.email);
          
          if (!existingProfile) {
            // Create default profile for new/returning user
            const defaultProfile = {
              displayName: user.displayName || user.email.split('@')[0],
              bio: 'Beauty enthusiast',
              profileImage: user.photoURL || '',
              location: '',
              email: user.email,
              website: '',
              version: '2.0',
              lastUpdated: Date.now()
            };
            
            saveUserProfile(user.email, defaultProfile);
          }
        }).catch(console.error);
      }
      
      setLoading(false);
    }, (error) => {
      console.error('Auth state change error:', error);
      setLoading(false);
    });

    return unsubscribe;
  }, []);

  const value = {
    user,
    isOwner,
    loading
  };

  return (
    <AuthContext.Provider value={value}>
      {!loading && children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
