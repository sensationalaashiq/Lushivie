
// Console bridge for capturing logs in preview window
(function() {
  const originalConsole = {
    log: console.log,
    error: console.error,
    warn: console.warn,
    info: console.info
  };

  function postConsoleMessage(level, args) {
    const message = args.map(arg => 
      typeof arg === 'object' ? JSON.stringify(arg, null, 2) : String(arg)
    ).join(' ');
    
    if (window.parent && window.parent !== window) {
      window.parent.postMessage({
        type: 'console',
        level: level,
        message: message,
        timestamp: new Date().toLocaleTimeString()
      }, '*');
    }
  }

  console.log = function(...args) {
    originalConsole.log.apply(console, args);
    postConsoleMessage('log', args);
  };

  console.error = function(...args) {
    originalConsole.error.apply(console, args);
    postConsoleMessage('error', args);
  };

  console.warn = function(...args) {
    originalConsole.warn.apply(console, args);
    postConsoleMessage('warning', args);
  };

  console.info = function(...args) {
    originalConsole.info.apply(console, args);
    postConsoleMessage('info', args);
  };

  // Capture unhandled errors
  window.addEventListener('error', function(event) {
    postConsoleMessage('error', [event.error?.message || event.message]);
  });

  // Capture unhandled promise rejections
  window.addEventListener('unhandledrejection', function(event) {
    postConsoleMessage('error', ['Unhandled promise rejection:', event.reason]);
  });

  // Send ready message
  postConsoleMessage('info', ['Console bridge initialized']);
})();
