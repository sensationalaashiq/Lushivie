
import fetch from 'node-fetch';

const BREVO_API_KEY = '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';
const BREVO_API_URL = 'https://api.brevo.com/v3';

export class BrevoEmailService {
  constructor() {
    this.apiKey = BREVO_API_KEY;
    this.apiUrl = BREVO_API_URL;
  }

  async sendTransactionalEmail(to, subject, htmlContent, textContent = null) {
    try {
      const response = await fetch(`${this.apiUrl}/smtp/email`, {
        method: 'POST',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
          'api-key': this.apiKey
        },
        body: JSON.stringify({
          sender: {
            name: 'Lushivie - Maanya Arora',
            email: 'noreply@lushivie.com'
          },
          to: Array.isArray(to) ? to : [{ email: to }],
          subject,
          htmlContent,
          textContent: textContent || this.stripHtml(htmlContent)
        })
      });

      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(`Brevo API error: ${data.message || response.statusText}`);
      }

      return data;
    } catch (error) {
      console.error('Error sending email via Brevo:', error);
      throw error;
    }
  }

  async sendBulkEmail(subscribers, subject, htmlContent, textContent = null) {
    try {
      const emailAddresses = subscribers.map(sub => ({ email: sub.email }));
      
      const response = await fetch(`${this.apiUrl}/smtp/email`, {
        method: 'POST',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
          'api-key': this.apiKey
        },
        body: JSON.stringify({
          sender: {
            name: 'Lushivie - Maanya Arora',
            email: 'noreply@lushivie.com'
          },
          to: emailAddresses,
          subject,
          htmlContent,
          textContent: textContent || this.stripHtml(htmlContent)
        })
      });

      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(`Brevo API error: ${data.message || response.statusText}`);
      }

      return data;
    } catch (error) {
      console.error('Error sending bulk email via Brevo:', error);
      throw error;
    }
  }

  generateNewPostEmailTemplate(post, subscriberEmail = '') {
    return `
      <!DOCTYPE html>
      <html lang="en">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>New Post: ${post.title}</title>
        <style>
          @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600;700&family=Inter:wght@300;400;500;600&display=swap');
          
          body { 
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; 
            line-height: 1.6; 
            color: #1f2937; 
            margin: 0; 
            padding: 20px; 
            background: linear-gradient(135deg, #fdf2f8 0%, #f8fafc 100%);
            -webkit-text-size-adjust: 100%;
            -ms-text-size-adjust: 100%;
          }
          .container { 
            max-width: 650px; 
            margin: 0 auto; 
            background: white; 
            border-radius: 20px; 
            overflow: hidden; 
            box-shadow: 0 25px 50px rgba(0,0,0,0.1);
          }
          .header { 
            background: linear-gradient(135deg, #e91e63 0%, #f06292 50%, #ec4899 100%); 
            padding: 50px 30px; 
            text-align: center; 
            color: white; 
            position: relative;
            overflow: hidden;
          }
          .header::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%);
            opacity: 0.5;
          }
          .logo-container {
            position: relative;
            z-index: 2;
          }
          .circular-logo {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            background: white;
            padding: 4px;
            margin: 0 auto 20px;
            box-shadow: 0 12px 35px rgba(0,0,0,0.2);
            border: 3px solid rgba(255,255,255,0.3);
          }
          .circular-logo img {
            width: 100%;
            height: 100%;
            border-radius: 50%;
            object-fit: cover;
            display: block;
          }
          .logo { 
            font-family: 'Playfair Display', serif;
            font-size: 42px; 
            font-weight: 700; 
            margin-bottom: 10px;
            position: relative;
            z-index: 2;
            text-shadow: 0 2px 4px rgba(0,0,0,0.1);
          }
          .tagline { 
            font-size: 14px; 
            opacity: 0.95; 
            letter-spacing: 3px; 
            font-weight: 500;
            position: relative;
            z-index: 2;
            text-transform: uppercase;
          }
          .content { 
            padding: 50px 40px; 
          }
          .new-post-badge {
            background: linear-gradient(135deg, #10b981, #059669);
            color: white;
            padding: 8px 20px;
            border-radius: 25px;
            font-size: 12px;
            font-weight: 600;
            letter-spacing: 1px;
            text-transform: uppercase;
            margin-bottom: 25px;
            display: inline-block;
          }
          .post-image { 
            width: 100%; 
            height: 280px; 
            object-fit: cover; 
            border-radius: 20px; 
            margin-bottom: 30px;
            box-shadow: 0 15px 35px rgba(0,0,0,0.12);
          }
          .post-title { 
            font-family: 'Playfair Display', serif;
            font-size: 36px; 
            font-weight: 700; 
            color: #e91e63; 
            margin-bottom: 25px; 
            line-height: 1.2;
            text-align: center;
          }
          .post-excerpt { 
            font-size: 17px; 
            color: #4b5563; 
            margin-bottom: 35px; 
            line-height: 1.8;
            text-align: center;
          }
          .cta-button { 
            display: inline-block; 
            background: linear-gradient(135deg, #e91e63, #f06292, #ec4899); 
            color: white; 
            padding: 20px 40px; 
            text-decoration: none; 
            border-radius: 50px; 
            font-weight: 600; 
            margin: 30px 0; 
            box-shadow: 0 12px 30px rgba(233, 30, 99, 0.4);
            font-size: 16px;
            text-transform: uppercase;
            letter-spacing: 1px;
            transition: all 0.3s ease;
          }
          .cta-container {
            text-align: center;
            margin: 40px 0;
          }
          .author-info {
            background: linear-gradient(135deg, #fdf2f8, #f8fafc);
            padding: 25px;
            border-radius: 20px;
            margin-top: 35px;
            border-left: 5px solid #e91e63;
            text-align: center;
          }
          .author-info .author-avatar {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            margin: 0 auto 15px;
            border: 3px solid #e91e63;
          }
          .author-info .author-avatar img {
            width: 100%;
            height: 100%;
            border-radius: 50%;
            object-fit: cover;
          }
          .footer { 
            background: linear-gradient(135deg, #1f2937, #374151); 
            padding: 40px 30px; 
            text-align: center; 
            color: white;
          }
          .footer-logo {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            background: white;
            padding: 4px;
            margin: 0 auto 25px;
            box-shadow: 0 8px 20px rgba(0,0,0,0.3);
          }
          .footer-logo img {
            width: 100%;
            height: 100%;
            border-radius: 50%;
            object-fit: cover;
          }
          .social-links { 
            margin: 25px 0; 
          }
          .social-links a { 
            display: inline-block;
            background: rgba(240, 98, 146, 0.2);
            color: #f06292; 
            text-decoration: none; 
            margin: 5px 10px;
            padding: 8px 16px;
            border-radius: 20px;
            font-weight: 500;
            transition: all 0.3s ease;
            font-size: 14px;
          }
          .unsubscribe { 
            margin-top: 25px; 
            padding-top: 25px;
            border-top: 1px solid rgba(255,255,255,0.1);
          }
          .unsubscribe a { 
            color: #9ca3af; 
            text-decoration: none; 
            font-size: 12px;
            opacity: 0.8;
          }
          @media (max-width: 600px) {
            body { padding: 10px; }
            .container { margin: 0; border-radius: 15px; }
            .header { padding: 40px 20px; }
            .content { padding: 40px 25px; }
            .post-title { font-size: 28px; }
            .logo { font-size: 36px; }
            .circular-logo { width: 80px; height: 80px; }
            .cta-button { padding: 18px 30px; font-size: 15px; }
          }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <div class="logo-container">
              <div class="circular-logo">
                <img src="https://i.ibb.co/zH5KTH4n/IMG-20250811-194616-255.jpg" alt="Lushivie Logo" style="border: 0;">
              </div>
              <div class="logo">✨ Lushivie</div>
              <div class="tagline">BEAUTY & LUXURY</div>
            </div>
          </div>
          
          <div class="content">
            <div class="new-post-badge">✨ New Article Published</div>
            
            <h1 class="post-title">${post.title}</h1>
            
            ${post.featuredImage ? `<img src="${post.featuredImage}" alt="${post.title}" class="post-image" style="border: 0;">` : ''}
            
            <div class="post-excerpt">
              ${post.excerpt || this.stripHtml(post.content).substring(0, 300) + '...'}
            </div>
            
            <div class="cta-container">
              <a href="https://lushivie.com/post/${post.slug}" class="cta-button" style="color: white; text-decoration: none;">
                ✨ Read Full Article →
              </a>
            </div>
            
            <div class="author-info">
              <div class="author-avatar">
                <img src="https://i.ibb.co/zH5KTH4n/IMG-20250811-194616-255.jpg" alt="Author" style="border: 0;">
              </div>
              <p style="margin: 0; color: #6b7280; font-size: 15px; font-weight: 500;">
                Written by <strong style="color: #e91e63;">${post.author}</strong><br>
                <span style="font-size: 13px; opacity: 0.8;">${new Date(post.publishedAt).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</span>
              </p>
            </div>
          </div>
          
          <div class="footer">
            <div class="footer-logo">
              <img src="https://i.ibb.co/zH5KTH4n/IMG-20250811-194616-255.jpg" alt="Lushivie Logo" style="border: 0;">
            </div>
            
            <div class="social-links">
              <a href="https://www.instagram.com/thee_bareblend?igsh=MXUzMmhnNG04eTNlMA%3D%3D&utm_source=qr" style="color: #f06292; text-decoration: none;">📸 Instagram</a>
              <a href="https://youtube.com/@thee_bareblend?si=YZpPX69osBb9p1fK" style="color: #f06292; text-decoration: none;">🎥 YouTube</a>
            </div>
            
            <p style="margin: 15px 0; font-size: 14px; opacity: 0.9;">
              © 2025 Lushivie - Beauty & Luxury Blog by Maanya Arora
            </p>
            <p style="margin: 5px 0; font-size: 12px; opacity: 0.7;">
              📍 Lajpat Nagar, New Delhi, Delhi 110024 | 💌 Help@lushivie.com
            </p>
            
            <div class="unsubscribe">
              <a href="https://lushivie.com/api/newsletter/unsubscribe?email=${subscriberEmail}" style="color: #9ca3af; text-decoration: none;">
                Unsubscribe from these emails
              </a>
            </div>
          </div>
        </div>
      </body>
      </html>
    `;
  }

  generateContactEmailTemplate(name, email, subject, message) {
    return `
      <!DOCTYPE html>
      <html lang="en">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>New Contact Message - ${subject}</title>
        <style>
          @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Playfair+Display:wght@600&display=swap');
          
          body { 
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif; 
            line-height: 1.6; 
            color: #1f2937; 
            margin: 0; 
            padding: 20px;
            background: linear-gradient(135deg, #fdf2f8 0%, #f8fafc 100%);
            -webkit-text-size-adjust: 100%;
            -ms-text-size-adjust: 100%;
          }
          .container { 
            max-width: 650px; 
            margin: 0 auto; 
            background: white; 
            border-radius: 25px; 
            overflow: hidden; 
            box-shadow: 0 25px 50px rgba(0,0,0,0.12);
          }
          .header { 
            background: linear-gradient(135deg, #e91e63 0%, #f06292 50%, #ec4899 100%); 
            padding: 45px 35px; 
            text-align: center; 
            color: white;
            position: relative;
            overflow: hidden;
          }
          .header::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(255,255,255,0.15) 0%, transparent 60%);
            opacity: 0.8;
          }
          .circular-logo {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background: white;
            padding: 4px;
            margin: 0 auto 20px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.25);
            border: 2px solid rgba(255,255,255,0.3);
            position: relative;
            z-index: 2;
          }
          .circular-logo img {
            width: 100%;
            height: 100%;
            border-radius: 50%;
            object-fit: cover;
            display: block;
          }
          .header h1 {
            font-family: 'Playfair Display', serif;
            margin: 0; 
            font-size: 28px; 
            font-weight: 600;
            position: relative;
            z-index: 2;
            text-shadow: 0 2px 4px rgba(0,0,0,0.1);
          }
          .header p {
            margin: 8px 0 0; 
            opacity: 0.95; 
            font-size: 14px;
            position: relative;
            z-index: 2;
            font-weight: 500;
            letter-spacing: 0.5px;
          }
          .content { 
            padding: 45px 40px; 
          }
          .alert-badge {
            background: linear-gradient(135deg, #f59e0b, #d97706);
            color: white;
            padding: 8px 18px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            letter-spacing: 1px;
            text-transform: uppercase;
            margin-bottom: 25px;
            display: inline-block;
          }
          .message-card {
            background: linear-gradient(135deg, #fdf2f8, #f8fafc);
            padding: 35px;
            border-radius: 20px;
            border-left: 6px solid #e91e63;
            margin: 25px 0;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
          }
          .field {
            margin-bottom: 20px;
          }
          .field:last-child {
            margin-bottom: 0;
          }
          .field-label {
            font-weight: 600;
            color: #e91e63;
            margin-bottom: 8px;
            font-size: 14px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
          }
          .field-value {
            color: #374151;
            font-size: 16px;
            font-weight: 400;
          }
          .message-content {
            white-space: pre-line; 
            padding: 20px; 
            background: white; 
            border-radius: 15px; 
            border: 1px solid #e5e7eb;
            box-shadow: inset 0 2px 4px rgba(0,0,0,0.05);
            font-family: 'Inter', sans-serif;
            line-height: 1.7;
          }
          .priority-marker {
            background: linear-gradient(135deg, #ef4444, #dc2626);
            color: white;
            padding: 4px 12px;
            border-radius: 15px;
            font-size: 11px;
            font-weight: 600;
            letter-spacing: 1px;
            margin-left: 10px;
          }
          .timestamp {
            background: #f3f4f6;
            padding: 15px 20px;
            border-radius: 15px;
            text-align: center;
            margin-top: 30px;
            border: 1px solid #e5e7eb;
          }
          .footer {
            background: linear-gradient(135deg, #f9fafb, #f3f4f6);
            padding: 30px;
            text-align: center;
            border-top: 1px solid #e5e7eb;
          }
          .footer-logo {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: white;
            padding: 3px;
            margin: 0 auto 15px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
          }
          .footer-logo img {
            width: 100%;
            height: 100%;
            border-radius: 50%;
            object-fit: cover;
          }
          .footer p {
            margin: 5px 0;
            font-size: 12px;
            color: #6b7280;
          }
          @media (max-width: 600px) {
            body { padding: 10px; }
            .container { border-radius: 20px; }
            .header { padding: 35px 25px; }
            .content { padding: 35px 25px; }
            .message-card { padding: 25px; }
            .header h1 { font-size: 24px; }
          }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <div class="circular-logo">
              <img src="https://i.ibb.co/zH5KTH4n/IMG-20250811-194616-255.jpg" alt="Lushivie Logo" style="border: 0;">
            </div>
            <h1>📬 New Contact Message</h1>
            <p>From Lushivie Beauty Blog</p>
          </div>
          
          <div class="content">
            <div class="alert-badge">🔔 Immediate Attention</div>
            
            <div class="message-card">
              <div class="field">
                <div class="field-label">👤 Sender Name</div>
                <div class="field-value"><strong>${name}</strong></div>
              </div>
              
              ${email ? `<div class="field">
                <div class="field-label">📧 Email Address</div>
                <div class="field-value"><a href="mailto:${email}" style="color: #e91e63; text-decoration: none;">${email}</a></div>
              </div>` : `<div class="field">
                <div class="field-label">📧 Email Address</div>
                <div class="field-value" style="color: #9ca3af; font-style: italic;">No email provided</div>
              </div>`}
              
              <div class="field">
                <div class="field-label">📝 Subject</div>
                <div class="field-value">
                  <strong>${subject}</strong>
                  ${subject.toLowerCase().includes('urgent') || subject.toLowerCase().includes('important') ? '<span class="priority-marker">HIGH PRIORITY</span>' : ''}
                </div>
              </div>
              
              <div class="field">
                <div class="field-label">💬 Message Content</div>
                <div class="message-content">${message}</div>
              </div>
            </div>
            
            <div class="timestamp">
              <p style="margin: 0; color: #6b7280; font-size: 13px; font-weight: 500;">
                <strong>📅 Received:</strong> ${new Date().toLocaleString('en-IN', { 
                  dateStyle: 'full', 
                  timeStyle: 'short',
                  timeZone: 'Asia/Kolkata'
                })} (IST)
              </p>
            </div>
          </div>
          
          <div class="footer">
            <div class="footer-logo">
              <img src="https://i.ibb.co/zH5KTH4n/IMG-20250811-194616-255.jpg" alt="Lushivie" style="border: 0;">
            </div>
            <p><strong>Lushivie Contact Management System</strong></p>
            <p>© 2025 Lushivie Beauty Blog | Automated Email System</p>
            <p style="color: #9ca3af;">This email was generated automatically from the contact form at lushivie.com</p>
          </div>
        </div>
      </body>
      </html>
    `;
  }

  stripHtml(html) {
    return html.replace(/<[^>]*>/g, '');
  }

  generateWelcomeEmailTemplate(subscriberEmail) {
    return `
      <!DOCTYPE html>
      <html lang="en">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Welcome to Lushivie</title>
        <style>
          @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600;700&family=Inter:wght@300;400;500;600&display=swap');
          
          body { 
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; 
            line-height: 1.6; 
            color: #1f2937; 
            margin: 0; 
            padding: 20px; 
            background: linear-gradient(135deg, #fdf2f8 0%, #f8fafc 100%);
            -webkit-text-size-adjust: 100%;
            -ms-text-size-adjust: 100%;
          }
          .container { 
            max-width: 650px; 
            margin: 0 auto; 
            background: white; 
            border-radius: 20px; 
            overflow: hidden; 
            box-shadow: 0 25px 50px rgba(0,0,0,0.1);
          }
          .header { 
            background: linear-gradient(135deg, #e91e63 0%, #f06292 50%, #ec4899 100%); 
            padding: 50px 30px; 
            text-align: center; 
            color: white; 
            position: relative;
            overflow: hidden;
          }
          .header::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%);
            opacity: 0.5;
          }
          .logo-container {
            position: relative;
            z-index: 2;
          }
          .circular-logo {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            background: white;
            padding: 4px;
            margin: 0 auto 20px;
            box-shadow: 0 12px 35px rgba(0,0,0,0.2);
            border: 3px solid rgba(255,255,255,0.3);
          }
          .circular-logo img {
            width: 100%;
            height: 100%;
            border-radius: 50%;
            object-fit: cover;
            display: block;
          }
          .logo { 
            font-family: 'Playfair Display', serif;
            font-size: 42px; 
            font-weight: 700; 
            margin-bottom: 10px;
            position: relative;
            z-index: 2;
            text-shadow: 0 2px 4px rgba(0,0,0,0.1);
          }
          .tagline { 
            font-size: 14px; 
            opacity: 0.95; 
            letter-spacing: 3px; 
            font-weight: 500;
            position: relative;
            z-index: 2;
            text-transform: uppercase;
          }
          .content { 
            padding: 50px 40px; 
          }
          .welcome-badge {
            background: linear-gradient(135deg, #10b981, #059669);
            color: white;
            padding: 8px 20px;
            border-radius: 25px;
            font-size: 12px;
            font-weight: 600;
            letter-spacing: 1px;
            text-transform: uppercase;
            margin-bottom: 25px;
            display: inline-block;
          }
          .welcome-title { 
            font-family: 'Playfair Display', serif;
            font-size: 36px; 
            font-weight: 700; 
            color: #e91e63; 
            margin-bottom: 25px; 
            line-height: 1.2;
            text-align: center;
          }
          .welcome-message { 
            font-size: 17px; 
            color: #4b5563; 
            margin-bottom: 35px; 
            line-height: 1.8;
            text-align: center;
          }
          .cta-button { 
            display: inline-block; 
            background: linear-gradient(135deg, #e91e63, #f06292, #ec4899); 
            color: white; 
            padding: 20px 40px; 
            text-decoration: none; 
            border-radius: 50px; 
            font-weight: 600; 
            margin: 30px 0; 
            box-shadow: 0 12px 30px rgba(233, 30, 99, 0.4);
            font-size: 16px;
            text-transform: uppercase;
            letter-spacing: 1px;
            transition: all 0.3s ease;
          }
          .cta-container {
            text-align: center;
            margin: 40px 0;
          }
          .author-info {
            background: linear-gradient(135deg, #fdf2f8, #f8fafc);
            padding: 25px;
            border-radius: 20px;
            margin-top: 35px;
            border-left: 5px solid #e91e63;
            text-align: center;
          }
          .author-info .author-avatar {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            margin: 0 auto 15px;
            border: 3px solid #e91e63;
          }
          .author-info .author-avatar img {
            width: 100%;
            height: 100%;
            border-radius: 50%;
            object-fit: cover;
          }
          .footer { 
            background: linear-gradient(135deg, #1f2937, #374151); 
            padding: 40px 30px; 
            text-align: center; 
            color: white;
          }
          .footer-logo {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            background: white;
            padding: 4px;
            margin: 0 auto 25px;
            box-shadow: 0 8px 20px rgba(0,0,0,0.3);
          }
          .footer-logo img {
            width: 100%;
            height: 100%;
            border-radius: 50%;
            object-fit: cover;
          }
          .social-links { 
            margin: 25px 0; 
          }
          .social-links a { 
            display: inline-block;
            background: rgba(240, 98, 146, 0.2);
            color: #f06292; 
            text-decoration: none; 
            margin: 5px 10px;
            padding: 8px 16px;
            border-radius: 20px;
            font-weight: 500;
            transition: all 0.3s ease;
            font-size: 14px;
          }
          .unsubscribe { 
            margin-top: 25px; 
            padding-top: 25px;
            border-top: 1px solid rgba(255,255,255,0.1);
          }
          .unsubscribe a { 
            color: #9ca3af; 
            text-decoration: none; 
            font-size: 12px;
            opacity: 0.8;
          }
          @media (max-width: 600px) {
            body { padding: 10px; }
            .container { margin: 0; border-radius: 15px; }
            .header { padding: 40px 20px; }
            .content { padding: 40px 25px; }
            .welcome-title { font-size: 28px; }
            .logo { font-size: 36px; }
            .circular-logo { width: 80px; height: 80px; }
            .cta-button { padding: 18px 30px; font-size: 15px; }
          }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <div class="logo-container">
              <div class="circular-logo">
                <img src="https://i.ibb.co/zH5KTH4n/IMG-20250811-194616-255.jpg" alt="Lushivie Logo" style="border: 0;">
              </div>
              <div class="logo">✨ Lushivie</div>
              <div class="tagline">BEAUTY & LUXURY</div>
            </div>
          </div>
          
          <div class="content">
            <div class="welcome-badge">✨ Welcome to Beauty Paradise</div>
            
            <h1 class="welcome-title">Welcome to Lushivie!</h1>
            
            <div class="welcome-message">
              Thank you for joining our beautiful community! You're now part of an exclusive group that gets the latest beauty tips, luxury product reviews, and insider secrets delivered straight to your inbox.
              <br><br>
              Get ready to discover your most radiant self with our expert beauty guides, product recommendations, and weekly inspiration.
            </div>
            
            <div class="cta-container">
              <a href="https://lushivie.com" class="cta-button" style="color: white; text-decoration: none;">
                ✨ Explore Beauty Secrets →
              </a>
            </div>
            
            <div class="author-info">
              <div class="author-avatar">
                <img src="https://i.ibb.co/zH5KTH4n/IMG-20250811-194616-255.jpg" alt="Maanya Arora" style="border: 0;">
              </div>
              <p style="margin: 0; color: #6b7280; font-size: 15px; font-weight: 500;">
                Your beauty guide <strong style="color: #e91e63;">Maanya Arora</strong><br>
                <span style="font-size: 13px; opacity: 0.8;">Founder & Beauty Expert at Lushivie</span>
              </p>
            </div>
          </div>
          
          <div class="footer">
            <div class="footer-logo">
              <img src="https://i.ibb.co/zH5KTH4n/IMG-20250811-194616-255.jpg" alt="Lushivie Logo" style="border: 0;">
            </div>
            
            <div class="social-links">
              <a href="https://www.instagram.com/thee_bareblend?igsh=MXUzMmhnNG04eTNlMA%3D%3D&utm_source=qr" style="color: #f06292; text-decoration: none;">📸 Instagram</a>
              <a href="https://youtube.com/@thee_bareblend?si=YZpPX69osBb9p1fK" style="color: #f06292; text-decoration: none;">🎥 YouTube</a>
            </div>
            
            <p style="margin: 15px 0; font-size: 14px; opacity: 0.9;">
              © 2025 Lushivie - Beauty & Luxury Blog by Maanya Arora
            </p>
            <p style="margin: 5px 0; font-size: 12px; opacity: 0.7;">
              📍 Lajpat Nagar, New Delhi, Delhi 110024 | 💌 Help@lushivie.com
            </p>
            
            <div class="unsubscribe">
              <a href="https://lushivie.com/api/newsletter/unsubscribe?email=${subscriberEmail}" style="color: #9ca3af; text-decoration: none;">
                Unsubscribe from these emails
              </a>
            </div>
          </div>
        </div>
      </body>
      </html>
    `;
  }

  generateConfirmationEmailTemplate(subscriberEmail) {
    return `
      <!DOCTYPE html>
      <html lang="en">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Message Received - Lushivie</title>
        <style>
          @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600;700&family=Inter:wght@300;400;500;600&display=swap');
          
          body { 
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; 
            line-height: 1.6; 
            color: #1f2937; 
            margin: 0; 
            padding: 20px; 
            background: linear-gradient(135deg, #fdf2f8 0%, #f8fafc 100%);
            -webkit-text-size-adjust: 100%;
            -ms-text-size-adjust: 100%;
          }
          .container { 
            max-width: 650px; 
            margin: 0 auto; 
            background: white; 
            border-radius: 20px; 
            overflow: hidden; 
            box-shadow: 0 25px 50px rgba(0,0,0,0.1);
          }
          .header { 
            background: linear-gradient(135deg, #e91e63 0%, #f06292 50%, #ec4899 100%); 
            padding: 50px 30px; 
            text-align: center; 
            color: white; 
            position: relative;
            overflow: hidden;
          }
          .header::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%);
            opacity: 0.5;
          }
          .logo-container {
            position: relative;
            z-index: 2;
          }
          .circular-logo {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            background: white;
            padding: 4px;
            margin: 0 auto 20px;
            box-shadow: 0 12px 35px rgba(0,0,0,0.2);
            border: 3px solid rgba(255,255,255,0.3);
          }
          .circular-logo img {
            width: 100%;
            height: 100%;
            border-radius: 50%;
            object-fit: cover;
            display: block;
          }
          .logo { 
            font-family: 'Playfair Display', serif;
            font-size: 42px; 
            font-weight: 700; 
            margin-bottom: 10px;
            position: relative;
            z-index: 2;
            text-shadow: 0 2px 4px rgba(0,0,0,0.1);
          }
          .tagline { 
            font-size: 14px; 
            opacity: 0.95; 
            letter-spacing: 3px; 
            font-weight: 500;
            position: relative;
            z-index: 2;
            text-transform: uppercase;
          }
          .content { 
            padding: 50px 40px; 
          }
          .confirmation-badge {
            background: linear-gradient(135deg, #10b981, #059669);
            color: white;
            padding: 8px 20px;
            border-radius: 25px;
            font-size: 12px;
            font-weight: 600;
            letter-spacing: 1px;
            text-transform: uppercase;
            margin-bottom: 25px;
            display: inline-block;
          }
          .confirmation-title { 
            font-family: 'Playfair Display', serif;
            font-size: 36px; 
            font-weight: 700; 
            color: #e91e63; 
            margin-bottom: 25px; 
            line-height: 1.2;
            text-align: center;
          }
          .confirmation-message { 
            font-size: 17px; 
            color: #4b5563; 
            margin-bottom: 35px; 
            line-height: 1.8;
            text-align: center;
          }
          .cta-button { 
            display: inline-block; 
            background: linear-gradient(135deg, #e91e63, #f06292, #ec4899); 
            color: white; 
            padding: 20px 40px; 
            text-decoration: none; 
            border-radius: 50px; 
            font-weight: 600; 
            margin: 30px 0; 
            box-shadow: 0 12px 30px rgba(233, 30, 99, 0.4);
            font-size: 16px;
            text-transform: uppercase;
            letter-spacing: 1px;
            transition: all 0.3s ease;
          }
          .cta-container {
            text-align: center;
            margin: 40px 0;
          }
          .author-info {
            background: linear-gradient(135deg, #fdf2f8, #f8fafc);
            padding: 25px;
            border-radius: 20px;
            margin-top: 35px;
            border-left: 5px solid #e91e63;
            text-align: center;
          }
          .author-info .author-avatar {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            margin: 0 auto 15px;
            border: 3px solid #e91e63;
          }
          .author-info .author-avatar img {
            width: 100%;
            height: 100%;
            border-radius: 50%;
            object-fit: cover;
          }
          .footer { 
            background: linear-gradient(135deg, #1f2937, #374151); 
            padding: 40px 30px; 
            text-align: center; 
            color: white;
          }
          .footer-logo {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            background: white;
            padding: 4px;
            margin: 0 auto 25px;
            box-shadow: 0 8px 20px rgba(0,0,0,0.3);
          }
          .footer-logo img {
            width: 100%;
            height: 100%;
            border-radius: 50%;
            object-fit: cover;
          }
          .social-links { 
            margin: 25px 0; 
          }
          .social-links a { 
            display: inline-block;
            background: rgba(240, 98, 146, 0.2);
            color: #f06292; 
            text-decoration: none; 
            margin: 5px 10px;
            padding: 8px 16px;
            border-radius: 20px;
            font-weight: 500;
            transition: all 0.3s ease;
            font-size: 14px;
          }
          .unsubscribe { 
            margin-top: 25px; 
            padding-top: 25px;
            border-top: 1px solid rgba(255,255,255,0.1);
          }
          .unsubscribe a { 
            color: #9ca3af; 
            text-decoration: none; 
            font-size: 12px;
            opacity: 0.8;
          }
          @media (max-width: 600px) {
            body { padding: 10px; }
            .container { margin: 0; border-radius: 15px; }
            .header { padding: 40px 20px; }
            .content { padding: 40px 25px; }
            .confirmation-title { font-size: 28px; }
            .logo { font-size: 36px; }
            .circular-logo { width: 80px; height: 80px; }
            .cta-button { padding: 18px 30px; font-size: 15px; }
          }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <div class="logo-container">
              <div class="circular-logo">
                <img src="https://i.ibb.co/zH5KTH4n/IMG-20250811-194616-255.jpg" alt="Lushivie Logo" style="border: 0;">
              </div>
              <div class="logo">✨ Lushivie</div>
              <div class="tagline">BEAUTY & LUXURY</div>
            </div>
          </div>
          
          <div class="content">
            <div class="confirmation-badge">✅ Message Received</div>
            
            <h1 class="confirmation-title">Thank You for Reaching Out!</h1>
            
            <div class="confirmation-message">
              Your message has been received successfully! I truly appreciate you taking the time to connect with me.
              <br><br>
              I personally read every message and will get back to you within 24-48 hours. In the meantime, feel free to explore our latest beauty content and tips!
            </div>
            
            <div class="cta-container">
              <a href="https://lushivie.com" class="cta-button" style="color: white; text-decoration: none;">
                ✨ Explore More Beauty →
              </a>
            </div>
            
            <div class="author-info">
              <div class="author-avatar">
                <img src="https://i.ibb.co/zH5KTH4n/IMG-20250811-194616-255.jpg" alt="Maanya Arora" style="border: 0;">
              </div>
              <p style="margin: 0; color: #6b7280; font-size: 15px; font-weight: 500;">
                With love, <strong style="color: #e91e63;">Maanya Arora</strong><br>
                <span style="font-size: 13px; opacity: 0.8;">Founder & Beauty Expert at Lushivie</span>
              </p>
            </div>
          </div>
          
          <div class="footer">
            <div class="footer-logo">
              <img src="https://i.ibb.co/zH5KTH4n/IMG-20250811-194616-255.jpg" alt="Lushivie Logo" style="border: 0;">
            </div>
            
            <div class="social-links">
              <a href="https://www.instagram.com/thee_bareblend?igsh=MXUzMmhnNG04eTNlMA%3D%3D&utm_source=qr" style="color: #f06292; text-decoration: none;">📸 Instagram</a>
              <a href="https://youtube.com/@thee_bareblend?si=YZpPX69osBb9p1fK" style="color: #f06292; text-decoration: none;">🎥 YouTube</a>
            </div>
            
            <p style="margin: 15px 0; font-size: 14px; opacity: 0.9;">
              © 2025 Lushivie - Beauty & Luxury Blog by Maanya Arora
            </p>
            <p style="margin: 5px 0; font-size: 12px; opacity: 0.7;">
              📍 Lajpat Nagar, New Delhi, Delhi 110024 | 💌 Help@lushivie.com
            </p>
            
            <div class="unsubscribe">
              <a href="https://lushivie.com/api/newsletter/unsubscribe?email=${subscriberEmail}" style="color: #9ca3af; text-decoration: none;">
                Unsubscribe from these emails
              </a>
            </div>
          </div>
        </div>
      </body>
      </html>
    `;
  }

  async sendContactEmail(name, email, subject, message) {
    try {
      const htmlContent = this.generateContactEmailTemplate(name, email, subject, message);
      const emailSubject = `🌟 New Contact: ${subject} - From ${name}`;
      
      const result = await this.sendTransactionalEmail(
        'help@lushivie.com', // Send to admin
        emailSubject,
        htmlContent
      );
      
      console.log('Contact email sent successfully:', result);
      return result;
    } catch (error) {
      console.error('Failed to send contact email:', error);
      throw error;
    }
  }

  async sendWelcomeEmail(subscriberEmail) {
    try {
      const htmlContent = this.generateWelcomeEmailTemplate(subscriberEmail);
      const subject = '✨ Welcome to Lushivie - Your Beauty Journey Begins!';
      
      const result = await this.sendTransactionalEmail(
        subscriberEmail,
        subject,
        htmlContent
      );
      
      console.log('Welcome email sent to:', subscriberEmail);
      return result;
    } catch (error) {
      console.error('Failed to send welcome email:', error);
      throw error;
    }
  }

  async sendConfirmationEmail(subscriberEmail, name) {
    try {
      const htmlContent = this.generateConfirmationEmailTemplate(subscriberEmail);
      const subject = '✅ Message Received - Thank You for Contacting Lushivie!';
      
      const result = await this.sendTransactionalEmail(
        subscriberEmail,
        subject,
        htmlContent
      );
      
      console.log('Confirmation email sent to:', subscriberEmail);
      return result;
    } catch (error) {
      console.error('Failed to send confirmation email:', error);
      throw error;
    }
  }

  async sendNewPostNotification(post, subscribers) {
    if (!subscribers || subscribers.length === 0) {
      console.log('No subscribers to send email to');
      return;
    }

    const subject = `✨ New Post: ${post.title} - Lushivie`;
    
    try {
      console.log(`Sending new post notification to ${subscribers.length} subscribers...`);
      
      // Send individual emails with personalized unsubscribe links
      const emailPromises = subscribers.map(subscriber => {
        const htmlContent = this.generateNewPostEmailTemplate(post, subscriber.email);
        return this.sendTransactionalEmail(subscriber.email, subject, htmlContent);
      });
      
      const results = await Promise.allSettled(emailPromises);
      const successful = results.filter(r => r.status === 'fulfilled').length;
      const failed = results.filter(r => r.status === 'rejected').length;
      
      console.log(`New post emails sent: ${successful} successful, ${failed} failed`);
      return { successful, failed, total: subscribers.length };
    } catch (error) {
      console.error('Failed to send new post notification:', error);
      throw error;
    }
  }
}
