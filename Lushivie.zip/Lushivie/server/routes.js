import express from "express";
import { createServer } from "http";
import { v4 as uuidv4 } from "uuid";
import { writeFileSync, readFileSync, existsSync, readdirSync, statSync, mkdirSync, unlinkSync, rmSync } from "fs";
import { join, dirname, basename, extname, relative } from "path";
import { fileURLToPath } from "url";
import { BrevoEmailService } from "./brevo.js";
import fs from 'fs'; // Import fs module
import path from 'path'; // Import path module
import crypto from 'crypto'; // Import crypto for UUID generation

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const PROJECT_ROOT = join(__dirname, '..');

// Data file paths
const POSTS_FILE = './data/posts.json';
const COMMENTS_FILE = './data/comments.json';
const SUBSCRIBERS_FILE = './data/subscribers.json';

// Initialize data directory
if (!existsSync('./data')) {
  mkdirSync('./data');
}

// Load data from files or use defaults
let posts = [];
let comments = [];
let subscribers = [];

// Load posts
if (existsSync(POSTS_FILE)) {
  try {
    posts = JSON.parse(readFileSync(POSTS_FILE, 'utf8'));
  } catch (error) {
    console.error('Error loading posts:', error);
    posts = [];
  }
}

// If no posts exist, create default posts
if (posts.length === 0) {
  posts = [
    {
      id: "60afc013-273c-4ff4-8fff-3d998b4207f0",
      title: "The Ultimate Guide to Luxury Skincare",
      slug: "ultimate-guide-luxury-skincare",
      content: "<h2>Introduction to Luxury Skincare</h2><p>Luxury skincare is more than just expensive products—it's about understanding your skin's unique needs and investing in quality formulations that deliver real results.</p><h3>Key Ingredients to Look For</h3><ul><li>Retinol for anti-aging</li><li>Hyaluronic acid for hydration</li><li>Vitamin C for brightening</li><li>Niacinamide for pore control</li></ul><p>Remember, the most expensive product isn't always the best for your skin type. It's about finding the right balance of ingredients that work harmoniously with your skin.</p>",
      excerpt: "Discover the secrets of luxury skincare and learn how to build an effective routine that delivers real results.",
      author: "Maanya Arora",
      authorImage: "https://i.ibb.co/zH5KTH4n/IMG-20250811-194616-255.jpg",
      publishedAt: new Date().toISOString(),
      featuredImage: "https://images.unsplash.com/photo-1570194065650-d99fb4bedf0a?w=800&h=400&fit=crop",
      views: 523,
      likes: 42,
      shares: 18,
      saves: 35
    },
    {
      id: "2b5e7f8a-9c3d-4e6f-8a1b-2c3d4e5f6a7b",
      title: "Mastering the Perfect Winged Eyeliner",
      slug: "mastering-perfect-winged-eyeliner",
      content: "<h2>Step-by-Step Winged Eyeliner Tutorial</h2><p>Creating the perfect winged eyeliner can seem daunting, but with the right technique and practice, you'll master this timeless look.</p><h3>What You'll Need</h3><ul><li>Liquid or gel eyeliner</li><li>Angled brush (for gel liner)</li><li>Cotton swabs</li><li>Micellar water</li></ul><h3>The Technique</h3><ol><li>Start with a clean, primed eyelid</li><li>Draw a line from the outer corner of your eye upward</li><li>Connect the tip back to your upper lash line</li><li>Fill in the triangle created</li><li>Clean up any mistakes with a cotton swab</li></ol>",
      excerpt: "Learn the professional techniques for creating flawless winged eyeliner that complements your eye shape.",
      author: "Maanya Arora",
      authorImage: "https://i.ibb.co/zH5KTH4n/IMG-20250811-194616-255.jpg",
      publishedAt: new Date(Date.now() - 86400000).toISOString(),
      featuredImage: "https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?w=800&h=400&fit=crop",
      views: 687,
      likes: 58,
      shares: 23,
      saves: 47
    }
  ];
  savePostsToFile();
}

// Load comments
if (existsSync(COMMENTS_FILE)) {
  try {
    comments = JSON.parse(readFileSync(COMMENTS_FILE, 'utf8'));
  } catch (error) {
    console.error('Error loading comments:', error);
    comments = [];
  }
}

// Load subscribers
if (existsSync(SUBSCRIBERS_FILE)) {
  try {
    const subscribersData = JSON.parse(readFileSync(SUBSCRIBERS_FILE, 'utf8'));
    // Handle both old format (array) and new format (object with subscribers array)
    subscribers = Array.isArray(subscribersData) ? subscribersData : (subscribersData.subscribers || []);
  } catch (error) {
    console.error('Error loading subscribers:', error);
    subscribers = [];
  }
} else {
  subscribers = [];
}

// Helper functions to save data
function savePostsToFile() {
  try {
    writeFileSync(POSTS_FILE, JSON.stringify(posts, null, 2));
  } catch (error) {
    console.error('Error saving posts:', error);
  }
}

function saveCommentsToFile() {
  try {
    writeFileSync(COMMENTS_FILE, JSON.stringify(comments, null, 2));
  } catch (error) {
    console.error('Error saving comments:', error);
  }
}

function saveSubscribersToFile() {
  try {
    writeFileSync(SUBSCRIBERS_FILE, JSON.stringify(subscribers, null, 2));
  } catch (error) {
    console.error('Error saving subscribers:', error);
  }
}

// Initialize Brevo email service
const emailService = new BrevoEmailService();

// File system helper functions
function isPathSafe(filePath) {
  const resolvedPath = join(PROJECT_ROOT, filePath);
  return resolvedPath.startsWith(PROJECT_ROOT);
}

function getFileType(filePath) {
  try {
    const stats = statSync(filePath);
    return stats.isDirectory() ? 'directory' : 'file';
  } catch (error) {
    return null;
  }
}

function getDirectoryStructure(dirPath, basePath = '') {
  const structure = {};

  try {
    const items = readdirSync(dirPath);

    for (const item of items) {
      // Skip hidden files, node_modules, and other unnecessary directories
      if (item.startsWith('.') && item !== '.replit' || 
          item === 'node_modules' || 
          item === 'dist' || 
          item === '.git') {
        continue;
      }

      const fullPath = join(dirPath, item);
      const relativePath = basePath ? join(basePath, item) : item;
      const stats = statSync(fullPath);

      if (stats.isDirectory()) {
        structure[item + '/'] = getDirectoryStructure(fullPath, relativePath);
      } else {
        structure[item] = {
          type: 'file',
          size: formatFileSize(stats.size),
          modified: stats.mtime.toISOString(),
          path: relativePath
        };
      }
    }
  } catch (error) {
    console.error('Error reading directory:', error);
  }

  return structure;
}

function formatFileSize(bytes) {
  if (bytes === 0) return '0B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + sizes[i];
}

// Function to generate unique IDs (can be replaced with a more robust solution if needed)
function generateUniqueId() {
  return uuidv4();
}

export async function registerRoutes(app) {
  const server = createServer(app);

  // Add quote saving routes
  await addQuoteRoutes(app);

  // File System API Routes

  // Get project file structure
  app.get("/api/files/structure", (req, res) => {
    try {
      const structure = getDirectoryStructure(PROJECT_ROOT);
      res.json(structure);
    } catch (error) {
      console.error('Error getting file structure:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // Get file content
  app.get("/api/files/content", (req, res) => {
    try {
      const filePath = req.query.path;

      if (!filePath) {
        return res.status(400).json({ error: 'File path is required' });
      }

      if (!isPathSafe(filePath)) {
        return res.status(403).json({ error: 'Access denied to this path' });
      }

      const fullPath = join(PROJECT_ROOT, filePath);

      if (!existsSync(fullPath)) {
        return res.status(404).json({ error: 'File not found' });
      }

      const stats = statSync(fullPath);
      if (stats.isDirectory()) {
        return res.status(400).json({ error: 'Path is a directory, not a file' });
      }

      // Check if file is binary
      const ext = extname(filePath).toLowerCase();
      const binaryExtensions = ['.jpg', '.jpeg', '.png', '.gif', '.pdf', '.zip', '.exe', '.bin'];

      if (binaryExtensions.includes(ext)) {
        return res.status(400).json({ error: 'Cannot read binary file' });
      }

      const content = readFileSync(fullPath, 'utf8');
      res.json({ 
        content,
        path: filePath,
        size: formatFileSize(stats.size),
        modified: stats.mtime.toISOString()
      });
    } catch (error) {
      console.error('Error reading file:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // Save file content
  app.post("/api/files/save", (req, res) => {
    try {
      const { path, content } = req.body;

      if (!path || content === undefined) {
        return res.status(400).json({ error: 'Path and content are required' });
      }

      if (!isPathSafe(path)) {
        return res.status(403).json({ error: 'Access denied to this path' });
      }

      const fullPath = join(PROJECT_ROOT, path);

      // Create directory if it doesn't exist
      const dir = dirname(fullPath);
      if (!existsSync(dir)) {
        mkdirSync(dir, { recursive: true });
      }

      writeFileSync(fullPath, content, 'utf8');

      const stats = statSync(fullPath);
      res.json({ 
        success: true,
        path,
        size: formatFileSize(stats.size),
        modified: stats.mtime.toISOString()
      });
    } catch (error) {
      console.error('Error saving file:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // Create new file
  app.post("/api/files/create", (req, res) => {
    try {
      const { path, type, content = '' } = req.body;

      if (!path || !type) {
        return res.status(400).json({ error: 'Path and type are required' });
      }

      if (!isPathSafe(path)) {
        return res.status(403).json({ error: 'Access denied to this path' });
      }

      const fullPath = join(PROJECT_ROOT, path);

      if (existsSync(fullPath)) {
        return res.status(409).json({ error: 'File or directory already exists' });
      }

      if (type === 'directory') {
        mkdirSync(fullPath, { recursive: true });
      } else {
        // Create directory if it doesn't exist
        const dir = dirname(fullPath);
        if (!existsSync(dir)) {
          mkdirSync(dir, { recursive: true });
        }

        writeFileSync(fullPath, content, 'utf8');
      }

      res.json({ 
        success: true,
        path,
        type,
        created: new Date().toISOString()
      });
    } catch (error) {
      console.error('Error creating file/directory:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // Delete file or directory
  app.delete("/api/files/delete", (req, res) => {
    try {
      const { path } = req.body;

      if (!path) {
        return res.status(400).json({ error: 'Path is required' });
      }

      if (!isPathSafe(path)) {
        return res.status(403).json({ error: 'Access denied to this path' });
      }

      const fullPath = join(PROJECT_ROOT, path);

      if (!existsSync(fullPath)) {
        return res.status(404).json({ error: 'File or directory not found' });
      }

      // Protect important files
      const protectedFiles = ['package.json', '.replit', 'server/index.js'];
      if (protectedFiles.includes(path)) {
        return res.status(403).json({ error: 'Cannot delete protected file' });
      }

      const stats = statSync(fullPath);
      if (stats.isDirectory()) {
        rmSync(fullPath, { recursive: true, force: true });
      } else {
        unlinkSync(fullPath);
      }

      res.json({ 
        success: true,
        path,
        deleted: new Date().toISOString()
      });
    } catch (error) {
      console.error('Error deleting file:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // Rename/move file or directory
  app.post("/api/files/rename", (req, res) => {
    try {
      const { oldPath, newPath } = req.body;

      if (!oldPath || !newPath) {
        return res.status(400).json({ error: 'Old path and new path are required' });
      }

      if (!isPathSafe(oldPath) || !isPathSafe(newPath)) {
        return res.status(403).json({ error: 'Access denied to one or both paths' });
      }

      const oldFullPath = join(PROJECT_ROOT, oldPath);
      const newFullPath = join(PROJECT_ROOT, newPath);

      if (!existsSync(oldFullPath)) {
        return res.status(404).json({ error: 'Source file or directory not found' });
      }

      if (existsSync(newFullPath)) {
        return res.status(409).json({ error: 'Destination already exists' });
      }

      // Create destination directory if needed
      const newDir = dirname(newFullPath);
      if (!existsSync(newDir)) {
        mkdirSync(newDir, { recursive: true });
      }

      // Read and write (for cross-device compatibility)
      const stats = statSync(oldFullPath);
      if (stats.isDirectory()) {
        // For directories, we need to recursively copy
        const copyDirectory = (src, dest) => {
          mkdirSync(dest, { recursive: true });
          const items = readdirSync(src);
          for (const item of items) {
            const srcPath = join(src, item);
            const destPath = join(dest, item);
            const itemStats = statSync(srcPath);
            if (itemStats.isDirectory()) {
              copyDirectory(srcPath, destPath);
            } else {
              const content = readFileSync(srcPath);
              writeFileSync(destPath, content);
            }
          }
        };
        copyDirectory(oldFullPath, newFullPath);
        rmSync(oldFullPath, { recursive: true, force: true });
      } else {
        const content = readFileSync(oldFullPath);
        writeFileSync(newFullPath, content);
        unlinkSync(oldFullPath);
      }

      res.json({ 
        success: true,
        oldPath,
        newPath,
        moved: new Date().toISOString()
      });
    } catch (error) {
      console.error('Error renaming file:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // Search files
  app.get("/api/files/search", (req, res) => {
    try {
      const { query, type = 'all' } = req.query;

      if (!query) {
        return res.status(400).json({ error: 'Search query is required' });
      }

      const results = [];

      const searchDirectory = (dirPath, basePath = '') => {
        try {
          const items = readdirSync(dirPath);

          for (const item of items) {
            if (item.startsWith('.') && item !== '.replit' || 
                item === 'node_modules' || 
                item === 'dist') {
              continue;
            }

            const fullPath = join(dirPath, item);
            const relativePath = basePath ? join(basePath, item) : item;
            const stats = statSync(fullPath);

            // Check if filename matches query
            if (item.toLowerCase().includes(query.toLowerCase())) {
              results.push({
                path: relativePath,
                name: item,
                type: stats.isDirectory() ? 'directory' : 'file',
                size: stats.isDirectory() ? null : formatFileSize(stats.size),
                modified: stats.mtime.toISOString()
              });
            }

            if (stats.isDirectory()) {
              searchDirectory(fullPath, relativePath);
            }
          }
        } catch (error) {
          // Skip directories we can't read
        }
      };

      searchDirectory(PROJECT_ROOT);

      // Filter by type if specified
      const filteredResults = type === 'all' ? results : 
        results.filter(item => item.type === type);

      res.json({ 
        query,
        results: filteredResults.slice(0, 50) // Limit results
      });
    } catch (error) {
      console.error('Error searching files:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // Posts routes
  app.get("/api/posts", (req, res) => {
    res.json(posts);
  });

  app.get("/api/posts/:slug", (req, res) => {
    const post = posts.find(p => p.slug === req.params.slug || p.id === req.params.slug);
    if (!post) {
      return res.status(404).json({ message: "Post not found" });
    }
    res.json(post);
  });

  app.post("/api/posts", async (req, res) => {
    const { title, content, excerpt, featuredImage, author } = req.body;

    if (!title || !content) {
      return res.status(400).json({ message: "Title and content are required" });
    }

    const slug = title.toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '');

    const newPost = {
      id: uuidv4(),
      title,
      slug,
      content,
      excerpt: excerpt || content.replace(/<[^>]*>/g, '').substring(0, 150) + "...",
      author: author || "Maanya Arora",
      publishedAt: new Date().toISOString(),
      featuredImage: featuredImage || null,
      views: 0, // Initialize views
      likes: 0, // Initialize likes
      shares: 0 // Initialize shares
    };

    posts.unshift(newPost);
    savePostsToFile(); // Save to file

    // Send email to all subscribers about the new post
    if (subscribers.length > 0) {
      try {
        console.log(`Sending new post notification to ${subscribers.length} subscribers...`);
        await emailService.sendNewPostNotification(newPost, subscribers);
        console.log('New post email notifications sent successfully!');
      } catch (error) {
        console.error('Failed to send new post notifications:', error);
        // Don't fail the post creation if email fails
      }
    }

    res.status(201).json(newPost);
  });

  app.put("/api/posts/:id", (req, res) => {
    const postIndex = posts.findIndex(p => p.id === req.params.id);
    if (postIndex === -1) {
      return res.status(404).json({ message: "Post not found" });
    }

    const { title, content, excerpt, featuredImage, author } = req.body;

    if (!title || !content) {
      return res.status(400).json({ message: "Title and content are required" });
    }

    const slug = title.toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '');

    posts[postIndex] = {
      ...posts[postIndex],
      title,
      slug,
      content,
      excerpt: excerpt || content.replace(/<[^>]*>/g, '').substring(0, 150) + "...",
      author: author || posts[postIndex].author,
      featuredImage: featuredImage || posts[postIndex].featuredImage
    };

    savePostsToFile(); // Save to file
    res.json(posts[postIndex]);
  });

  app.delete("/api/posts/:id", (req, res) => {
    const postIndex = posts.findIndex(p => p.id === req.params.id);
    if (postIndex === -1) {
      return res.status(404).json({ message: "Post not found" });
    }

    posts.splice(postIndex, 1);
    savePostsToFile(); // Save to file
    res.status(204).send();
  });

  // Get all posts
  app.get('/api/posts', (req, res) => {
    res.json(posts);
  });

  // Increment post views (real-time tracking)
  app.post('/api/posts/:id/views', (req, res) => {
    const postId = req.params.id;
    const post = posts.find(p => p.id === postId);
    if (!post) {
      return res.status(404).json({ error: 'Post not found' });
    }

    // Initialize views if not exists, otherwise increment
    if (!post.views) {
      post.views = 500; // Start from 500+ as mentioned
    } else {
      post.views += 1;
    }

    savePostsToFile(); // Save to file immediately
    res.json({ views: post.views });
  });

  // Get post views (without incrementing)
  app.get('/api/posts/:id/views', (req, res) => {
    const postId = req.params.id;
    const post = posts.find(p => p.id === postId);
    if (!post) {
      return res.status(404).json({ error: 'Post not found' });
    }

    res.json({ views: post.views || 500 });
  });

  // Get post comments
  app.get('/api/posts/:id/comments', (req, res) => {
    const postId = req.params.id;
    const postComments = comments.filter(c => c.postId === postId);
    res.json(postComments);
  });

  // Get post rating
  app.get('/api/posts/:id/rating', (req, res) => {
    const postId = req.params.id;
    // For now, return default rating. You can connect to a real database later
    const rating = {
      averageRating: 4.5, // This would be calculated from real ratings
      totalRatings: 24
    };
    res.json(rating);
  });

  // Save/Unsave post
  app.post('/api/posts/:id/save', (req, res) => {
    const postId = req.params.id;
    const { userId, userEmail, userProfile, action } = req.body; // action: 'save' or 'unsave'

    const post = posts.find(p => p.id === postId);
    if (!post) {
      return res.status(404).json({ error: 'Post not found' });
    }

    // Initialize saves count and savedBy array if not exists
    if (typeof post.saves !== 'number') post.saves = 0;
    if (!Array.isArray(post.savedBy)) post.savedBy = [];

    console.log(`${action} request for post ${postId} by user ${userId}`);

    if (action === 'save') {
      // Store user profile data with the save
      const saveData = {
        userId: userId,
        userEmail: userEmail,
        userProfile: userProfile,
        savedAt: new Date().toISOString()
      };

      // Remove existing save by same user if exists
      const existingIndex = post.savedBy.findIndex(save => save.userId === userId);
      if (existingIndex === -1) {
        post.saves += 1;
        post.savedBy.push(saveData);
      } else {
        // Update existing save data
        post.savedBy[existingIndex] = saveData;
      }

    } else if (action === 'unsave') {
      // Remove user from savedBy array
      const existingIndex = post.savedBy.findIndex(save => save.userId === userId);
      if (existingIndex !== -1) {
        post.savedBy.splice(existingIndex, 1);
        if (post.saves > 0) {
          post.saves -= 1;
        }
      }
    }

    savePostsToFile();

    console.log(`Post ${postId} now has ${post.saves} saves`);

    res.json({ 
      success: true, 
      saves: post.saves, 
      action, 
      savedBy: post.savedBy.length,
      postId: postId
    });
  });

  // Share post (increment share count)
  app.post('/api/posts/:id/share', (req, res) => {
    const postId = req.params.id;
    const { platform } = req.body; // platform: 'facebook', 'twitter', 'whatsapp', etc.

    const post = posts.find(p => p.id === postId);
    if (!post) {
      return res.status(404).json({ error: 'Post not found' });
    }

    // Initialize shares count if not exists
    if (!post.shares) post.shares = 0;
    post.shares += 1;

    savePostsToFile();
    res.json({ shares: post.shares, platform });
  });

  // Get post stats
  app.get('/api/posts/:id/stats', (req, res) => {
    const postId = req.params.id;
    const post = posts.find(p => p.id === postId);
    if (!post) {
      return res.status(404).json({ error: 'Post not found' });
    }

    res.json({
      views: post.views || 500,
      likes: post.likes || 0,
      shares: post.shares || 0,
      saves: post.saves || 0,
      comments: comments.filter(c => c.postId === postId).length
    });
  });

  // Comments routes
  app.get("/api/posts/:postId/comments", (req, res) => {
    const postComments = comments.filter(c => c.postId === req.params.postId);
    res.json(postComments);
  });

  app.post("/api/posts/:postId/comments", (req, res) => {
    const { author, content, userId, userPhoto, upvotes, downvotes, score } = req.body;

    if (!author || !content) {
      return res.status(400).json({ message: "Author and content are required" });
    }

    const newComment = {
      id: uuidv4(),
      postId: req.params.postId,
      author,
      content,
      userId: userId || null,
      userPhoto: userPhoto || null,
      upvotes: upvotes || 0,
      downvotes: downvotes || 0,
      score: score || 0,
      votes: {}, // Track individual user votes
      createdAt: new Date().toISOString()
    };

    comments.push(newComment);
    saveCommentsToFile(); // Save to file
    res.status(201).json(newComment);
  });

  // Vote on comment
  app.post("/api/posts/:postId/comments/:commentId/vote", (req, res) => {
    const { commentId } = req.params;
    const { voteType, userId } = req.body; // voteType: 'upvote', 'downvote', or null

    if (!userId) {
      return res.status(400).json({ message: "User ID is required" });
    }

    const commentIndex = comments.findIndex(c => c.id === commentId);
    if (commentIndex === -1) {
      return res.status(404).json({ message: "Comment not found" });
    }

    const comment = comments[commentIndex];

    // Initialize votes object if it doesn't exist
    if (!comment.votes) comment.votes = {};
    if (!comment.upvotes) comment.upvotes = 0;
    if (!comment.downvotes) comment.downvotes = 0;

    // Remove previous vote if exists
    const previousVote = comment.votes[userId];
    if (previousVote === 'upvote') comment.upvotes--;
    if (previousVote === 'downvote') comment.downvotes--;

    // Add new vote
    if (voteType === 'upvote') {
      comment.upvotes++;
      comment.votes[userId] = 'upvote';
    } else if (voteType === 'downvote') {
      comment.downvotes++;
      comment.votes[userId] = 'downvote';
    } else {
      // Remove vote
      delete comment.votes[userId];
    }

    // Update score
    comment.score = comment.upvotes - comment.downvotes;

    comments[commentIndex] = comment;
    saveCommentsToFile();

    res.json({
      upvotes: comment.upvotes,
      downvotes: comment.downvotes,
      score: comment.score,
      userVote: comment.votes[userId] || null
    });
  });

  // Delete comment (owner only)
  app.delete("/api/posts/:postId/comments/:commentId", (req, res) => {
    const { commentId } = req.params;
    const { userId } = req.body;

    if (!userId) {
      return res.status(400).json({ message: "User ID is required" });
    }

    const commentIndex = comments.findIndex(c => c.id === commentId);
    if (commentIndex === -1) {
      return res.status(404).json({ message: "Comment not found" });
    }

    // Remove comment from array
    comments.splice(commentIndex, 1);
    saveCommentsToFile();

    res.json({ message: "Comment deleted successfully" });
  });

  // Newsletter subscription
  app.post('/api/newsletter/subscribe', async (req, res) => {
    try {
      const { email } = req.body;

      if (!email || !email.includes('@')) {
        return res.status(400).json({ error: 'Valid email is required' });
      }

      // Ensure subscribers are loaded
      const subscribers = loadSubscribers();

      // Check if already subscribed
      const existingSubscriber = subscribers.find(sub => sub.email.toLowerCase() === email.toLowerCase());
      if (existingSubscriber) {
        return res.status(400).json({ error: 'Email already subscribed' });
      }

      // Add new subscriber
      const newSubscriber = {
        id: crypto.randomUUID(),
        email: email.toLowerCase(),
        subscribedAt: new Date().toISOString()
      };

      subscribers.push(newSubscriber);
      saveSubscribers(subscribers);

      // Send welcome email
      try {
        await emailService.sendWelcomeEmail(email);
      } catch (emailError) {
        console.error('Failed to send welcome email:', emailError);
        // Don't fail the subscription if email fails
      }

      res.status(201).json({ message: 'Successfully subscribed to newsletter' });
    } catch (error) {
      console.error('Newsletter subscription error:', error);
      res.status(500).json({ error: 'Failed to subscribe' });
    }
  });

  // Fixed contact email route
  app.post('/api/contact', async (req, res) => {
    try {
      const { name, email, subject, message } = req.body;

      // Validate required fields
      if (!name || !subject || !message) {
        return res.status(400).json({
          success: false,
          error: 'Name, subject, and message are required'
        });
      }

      // Validate email format if provided
      if (email && !email.includes('@')) {
        return res.status(400).json({
          success: false,
          error: 'Please enter a valid email address'
        });
      }

      console.log('📧 Processing contact form submission:', { name, email: email || 'No email', subject });

      try {
        // Send email to admin using Brevo
        await emailService.sendContactEmail(name, email || '', subject, message);
        console.log('✅ Contact email sent to admin successfully');

        // Send confirmation email to sender if email provided
        if (email && email.includes('@')) {
          try {
            await emailService.sendConfirmationEmail(email, name);
            console.log('✅ Confirmation email sent to sender');
          } catch (confirmationError) {
            console.error('❌ Failed to send confirmation email:', confirmationError);
            // Don't fail the main request if confirmation email fails
          }
        }

        res.json({
          success: true,
          message: email ? 
            'Your message has been sent! Check your email for confirmation.' : 
            'Your message has been sent successfully! We\'ll get back to you soon.'
        });

      } catch (emailError) {
        console.error('❌ Email sending failed:', emailError);

        res.status(500).json({
          success: false,
          error: 'Failed to send email. Please try again or contact help@lushivie.com directly.',
          details: emailError.message
        });
      }

    } catch (error) {
      console.error('❌ Contact form error:', error);
      res.status(500).json({
        success: false,
        error: 'Server error. Please try again later.'
      });
    }
  });

  // Ultra-fast subscriber removal endpoint
  app.delete('/api/newsletter/subscribers/:id', (req, res) => {
    try {
      const subscriberId = req.params.id;

      // Find and remove subscriber in one operation
      const originalLength = subscribers.length;
      subscribers = subscribers.filter(sub => sub.id !== subscriberId);

      if (subscribers.length === originalLength) {
        return res.status(404).json({ 
          success: false, 
          message: 'Subscriber not found' 
        });
      }

      // Immediate response - don't wait for file save
      res.json({ 
        success: true, 
        message: 'Subscriber removed successfully',
        total: subscribers.length,
        removedId: subscriberId
      });

      // Save file asynchronously after response
      process.nextTick(() => {
        try {
          saveSubscribersToFile();
        } catch (saveError) {
          console.error('Background save error:', saveError);
        }
      });

    } catch (error) {
      console.error('Error removing subscriber:', error);
      res.status(500).json({ 
        success: false, 
        message: 'Failed to remove subscriber' 
      });
    }
  });

  // Get newsletter subscribers (admin only)
  app.get("/api/newsletter/subscribers", (req, res) => {
    // Ensure subscribers is always an array
    const subscribersList = Array.isArray(subscribers) ? subscribers : [];
    res.json({
      total: subscribersList.length,
      subscribers: subscribersList.map(sub => ({
        id: sub.id,
        email: sub.email,
        subscribedAt: sub.subscribedAt
      }))
    });
  });

  // Review Management API Routes
  const REVIEWS_FILE = './data/reviews.json';

  // Load reviews from file
  let reviews = [];
  if (existsSync(REVIEWS_FILE)) {
    try {
      reviews = JSON.parse(readFileSync(REVIEWS_FILE, 'utf8'));
    } catch (error) {
      console.error('Error loading reviews:', error);
      reviews = [];
    }
  }

  // If no reviews exist, create default review
  if (reviews.length === 0) {
    reviews = [
      {
        id: "review-1",
        name: "Maanya Arora",
        email: "help@lushivie.com",
        rating: 5,
        reviewText: "Lushivie has such classy, elegant vibes - feels luxe but still so approachable.",
        profileImage: "https://i.ibb.co/zH5KTH4n/IMG-20250811-194616-255.jpg", // Added Maanya's DP
        approved: true,
        createdAt: new Date().toISOString()
      }
    ];
    saveReviewsToFile();
  }

  // Helper function to save reviews
  function saveReviewsToFile() {
    try {
      writeFileSync(REVIEWS_FILE, JSON.stringify(reviews, null, 2));
    } catch (error) {
      console.error('Error saving reviews:', error);
    }
  }

  // Get all reviews (admin only)
  app.get("/api/reviews", (req, res) => {
    try {
      const approved = reviews.filter(r => r.approved === true);
      const pending = reviews.filter(r => !r.approved);
      const totalRating = reviews.length > 0 
        ? reviews.reduce((sum, review) => sum + review.rating, 0) / reviews.length 
        : 0;

      res.json({
        reviews: reviews,
        stats: {
          total: reviews.length,
          pending: pending.length,
          approved: approved.length,
          averageRating: totalRating
        }
      });
    } catch (error) {
      console.error('Error fetching reviews:', error);
      res.status(500).json({ error: 'Failed to fetch reviews' });
    }
  });

  // Get public reviews (only approved ones)
  app.get("/api/reviews/public", (req, res) => {
    try {
      const approvedReviews = reviews.filter(r => r.approved === true);
      const totalRating = approvedReviews.length > 0 
        ? approvedReviews.reduce((sum, review) => sum + review.rating, 0) / approvedReviews.length 
        : 0;

      res.json({
        reviews: approvedReviews,
        stats: {
          total: approvedReviews.length,
          averageRating: totalRating
        }
      });
    } catch (error) {
      console.error('Error fetching public reviews:', error);
      res.status(500).json({ error: 'Failed to fetch reviews' });
    }
  });

  // Submit new review
  app.post("/api/reviews", (req, res) => {
    try {
      const { name, email, rating, reviewText, profileImage, userPhoto } = req.body;

      if (!name || !email || !rating || !reviewText) {
        return res.status(400).json({ error: 'All fields are required' });
      }

      if (rating < 1 || rating > 5) {
        return res.status(400).json({ error: 'Rating must be between 1 and 5' });
      }

      const newReview = {
        id: generateUniqueId(),
        name,
        email,
        rating,
        reviewText,
        profileImage: profileImage || null, // Store user profile image
        userPhoto: userPhoto || null, // Alternative field name
        approved: false, // New reviews need approval
        createdAt: new Date().toISOString()
      };

      reviews.unshift(newReview);
      saveReviewsToFile();

      res.status(201).json({ 
        success: true, 
        message: 'Review submitted successfully! It will be published after approval.',
        review: newReview
      });
    } catch (error) {
      console.error('Error submitting review:', error);
      res.status(500).json({ error: 'Failed to submit review' });
    }
  });

  // Approve/Hide review
  app.put("/api/reviews/:id/approve", (req, res) => {
    try {
      const reviewId = req.params.id;
      const { approved } = req.body;

      const reviewIndex = reviews.findIndex(r => r.id === reviewId);
      if (reviewIndex === -1) {
        return res.status(404).json({ error: 'Review not found' });
      }

      reviews[reviewIndex].approved = approved;
      saveReviewsToFile();

      res.json({ 
        success: true, 
        message: approved ? 'Review approved successfully' : 'Review hidden successfully',
        approved 
      });
    } catch (error) {
      console.error('Error updating review:', error);
      res.status(500).json({ error: 'Failed to update review' });
    }
  });

  // Delete review
  app.delete("/api/reviews/:id", (req, res) => {
    try {
      const reviewId = req.params.id;

      const reviewIndex = reviews.findIndex(r => r.id === reviewId);
      if (reviewIndex === -1) {
        return res.status(404).json({ error: 'Review not found' });
      }

      reviews.splice(reviewIndex, 1);
      saveReviewsToFile();

      res.json({ 
        success: true, 
        message: 'Review deleted successfully' 
      });
    } catch (error) {
      console.error('Error deleting review:', error);
      res.status(500).json({ error: 'Failed to delete review' });
    }
  });

  // Contact form submission
  app.post('/api/contact', async (req, res) => {
    try {
      const { name, email, subject, message } = req.body;

      if (!name || !subject || !message) {
        return res.status(400).json({ 
          success: false, 
          message: 'Name, subject, and message are required' 
        });
      }

      // Validate email format if provided
      if (email && !email.includes('@')) {
        return res.status(400).json({
          success: false,
          error: 'Please enter a valid email address'
        });
      }

      console.log('📧 Processing contact form submission:', { name, email: email || 'No email', subject });

      // Send email to admin
      try {
        await emailService.sendContactEmail(name, email || '', subject, message);
        console.log('✅ Contact email sent to admin successfully');
      } catch (emailError) {
        console.error('❌ Failed to send contact email to admin:', emailError);
        return res.status(500).json({ 
          success: false, 
          message: 'Failed to send email to admin' 
        });
      }

      // Send confirmation email to sender if email provided
      if (email && email.includes('@')) {
        try {
          await emailService.sendConfirmationEmail(email, name);
          console.log('✅ Confirmation email sent to sender');
        } catch (confirmationError) {
          console.error('❌ Failed to send confirmation email:', confirmationError);
          // Don't fail the main request if confirmation email fails
        }
      }

      res.json({ 
        success: true, 
        message: email ? 
          'Your message has been sent! Check your email for confirmation.' : 
          'Your message has been sent successfully. We\'ll get back to you soon.'
      });
    } catch (error) {
      console.error('❌ Contact form error:', error);
      res.status(500).json({ 
        success: false, 
        message: 'Server error. Please try again later.'
      });
    }
  });

  // Manual newsletter sending (admin only)
  app.post("/api/newsletter/send", async (req, res) => {
    const { subject, content, postId } = req.body;

    if (!subject || !content) {
      return res.status(400).json({ message: "Subject and content are required" });
    }

    if (subscribers.length === 0) {
      return res.status(400).json({ message: "No subscribers to send email to" });
    }

    try {
      let htmlContent;

      if (postId) {
        // Send specific post
        const post = posts.find(p => p.id === postId);
        if (!post) {
          return res.status(404).json({ message: "Post not found" });
        }

        await emailService.sendNewPostNotification(post, subscribers);
        res.json({ 
          message: `Post notification sent to ${subscribers.length} subscribers!`,
          recipientCount: subscribers.length 
        });
      } else {
        // Send custom newsletter
        htmlContent = `
          <!DOCTYPE html>
          <html lang="en">
          <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>${subject}</title>
            <style>
              body { font-family: 'Arial', sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 0; }
              .container { max-width: 600px; margin: 0 auto; padding: 20px; }
              .header { background: linear-gradient(135deg, #e91e63, #f06292); padding: 30px; text-align: center; color: white; border-radius: 10px 10px 0 0; }
              .logo { font-size: 32px; font-weight: bold; margin-bottom: 10px; }
              .tagline { font-size: 14px; opacity: 0.9; letter-spacing: 1px; }
              .content { background: white; padding: 30px; border: 1px solid #e0e0e0; }
              .footer { background: #f5f5f5; padding: 20px; text-align: center; font-size: 12px; color: #888; border-radius: 0 0 10px 10px; }
            </style>
          </head>
          <body>
            <div class="container">
              <div class="header">
                <div class="logo">✨ Lushivie</div>
                <div class="tagline">BEAUTY & LUXURY</div>
              </div>
              <div class="content">
                ${content}
              </div>
              <div class="footer">
                <p>© 2025 Lushivie - Beauty & Luxury Blog by Maanya Arora</p>
                <p>Lajpat Nagar, New Delhi, Delhi 110024</p>
                <div style="margin-top: 10px;">
                  <a href="https://lushivie.com/api/newsletter/unsubscribe?email={{email}}" style="color: #888; text-decoration: none; font-size: 12px;">Unsubscribe</a>
                </div>
              </div>
            </div>
          </body>
          </html>
        `;

        // Send individual emails with personalized unsubscribe links
        const emailPromises = subscribers.map(subscriber => {
          const personalizedContent = htmlContent.replace('{{email}}', subscriber.email);
          return emailService.sendTransactionalEmail(subscriber.email, subject, personalizedContent);
        });

        await Promise.allSettled(emailPromises);
        res.json({ 
          message: `Custom newsletter sent to ${subscribers.length} subscribers!`,
          recipientCount: subscribers.length 
        });
      }
    } catch (error) {
      console.error('Failed to send newsletter:', error);
      res.status(500).json({ message: "Failed to send newsletter: " + error.message });
    }
  });

  // Unsubscribe endpoint
  app.get('/api/newsletter/unsubscribe', (req, res) => {
    try {
      const { email } = req.query;

      if (!email) {
        return res.status(400).send(`
          <div style="font-family: Arial, sans-serif; max-width: 500px; margin: 50px auto; padding: 40px; text-align: center; background: #fef2f2; border-radius: 20px;">
            <h2 style="color: #dc2626;">Invalid Request</h2>
            <p>Email parameter is missing.</p>
          </div>
        `);
      }

      // Load current subscribers
      const dataPath = path.join(__dirname, '../data/subscribers.json');
      let currentSubscribers = [];

      if (fs.existsSync(dataPath)) {
        const data = fs.readFileSync(dataPath, 'utf8');
        currentSubscribers = JSON.parse(data).subscribers || [];
      }

      // Find and remove subscriber
      const initialCount = currentSubscribers.length;
      const updatedSubscribers = currentSubscribers.filter(sub => sub.email !== email);

      if (initialCount === updatedSubscribers.length) {
        return res.send(`
          <div style="font-family: Arial, sans-serif; max-width: 500px; margin: 50px auto; padding: 40px; text-align: center; background: #fef3c7; border-radius: 20px;">
            <h2 style="color: #d97706;">Already Unsubscribed</h2>
            <p>The email ${email} is not in our subscriber list.</p>
            <a href="/" style="color: #ec4899; text-decoration: none; font-weight: bold;">← Back to Lushivie</a>
          </div>
        `);
      }

      // Save updated subscribers
      const updatedData = {
        subscribers: updatedSubscribers,
        lastUpdated: new Date().toISOString()
      };

      fs.writeFileSync(dataPath, JSON.stringify(updatedData, null, 2));

      res.send(`
        <div style="font-family: Arial, sans-serif; max-width: 500px; margin: 50px auto; padding: 40px; text-align: center; background: #f0fdf4; border-radius: 20px;">
          <div style="width: 60px; height: 60px; background: #10b981; border-radius: 50%; margin: 0 auto 20px; display: flex; align-items: center; justify-content: center;">
            <span style="color: white; font-size: 24px;">✓</span>
          </div>
          <h2 style="color: #065f46;">Successfully Unsubscribed</h2>
          <p style="color: #374151;">You have been unsubscribed from Lushivie newsletter.</p>
          <p style="color: #6b7280; font-size: 14px;">We're sorry to see you go! If you change your mind, you can always subscribe again on our website.</p>
          <div style="margin-top: 30px;">
            <a href="/" style="background: #ec4899; color: white; padding: 12px 24px; text-decoration: none; border-radius: 25px; font-weight: bold;">Back to Lushivie</a>
          </div>
        </div>
      `);
    } catch (error) {
      console.error('Error unsubscribing:', error);
      res.status(500).send(`
        <div style="font-family: Arial, sans-serif; max-width: 500px; margin: 50px auto; padding: 40px; text-align: center; background: #fef2f2; border-radius: 20px;">
          <h2 style="color: #dc2626;">Error</h2>
          <p>Failed to unsubscribe. Please try again later or contact support.</p>
        </div>
      `);
    }
  });

  // Google Translate API endpoint
  app.post('/api/google-translate', async (req, res) => {
    try {
      const { text, from = 'en', to } = req.body;

      if (!text || !to) {
        return res.status(400).json({ 
          success: false, 
          error: 'Text and target language are required' 
        });
      }

      if (from === to || to === 'en') {
        return res.json({ 
          success: true, 
          translatedText: text 
        });
      }

      // Mock translation responses for demo
      // In production, you would integrate with Google Translate API or Microsoft Translator
      const mockTranslations = {
        'hi': {
          'Lushivie Beauty Blog': 'लुशिवी ब्यूटी ब्लॉग',
          'Beauty Reviews': 'सौंदर्य समीक्षा',
          'Read More': 'और पढ़ें',
          'Premium': 'प्रीमियम',
          'Featured Posts': 'फीचर्ड पोस्ट्स',
          'Discover the latest in luxury beauty': 'लक्जरी ब्यूटी में नवीनतम की खोज करें',
          'Expert reviews, premium insights, and exclusive beauty secrets': 'विशेषज्ञ समीक्षा, प्रीमियम अंतर्दृष्टि, और विशेष सौंदर्य रहस्य'
        },
        'ta': {
          'Lushivie Beauty Blog': 'லுஷிவி அழகு வலைப்பதிவு',
          'Beauty Reviews': 'அழகு மதிப்புரைகள்',
          'Read More': 'மேலும் படிக்க',
          'Premium': 'பிரீமியம்',
          'Featured Posts': 'சிறப்பு இடுகைகள்',
          'Discover the latest in luxury beauty': 'ஆடம்பர அழகில் சமீபத்தியதைக் கண்டறியுங்கள்',
          'Expert reviews, premium insights, and exclusive beauty secrets': 'நிபுணர் மதிப்புரைகள், பிரீமியம் நுண்ணறிவுகள் மற்றும் பிரத்தியேக அழகு ரகசியங்கள்'
        },
        'te': {
          'Lushivie Beauty Blog': 'లుషివి బ్యూటీ బ్లాగ్',
          'Beauty Reviews': 'అందం సమీక్షలు',
          'Read More': 'మరింత చదవండి',
          'Premium': 'ప్రీమియం',
          'Featured Posts': 'ఫీచర్డ్ పోస్ట్‌లు',
          'Discover the latest in luxury beauty': 'లగ్జరీ బ్యూటీలో తాజాదనిని కనుగొనండి',
          'Expert reviews, premium insights, and exclusive beauty secrets': 'నిపుణుల సమీక్షలు, ప్రీమియం అంతర్దృష్టులు మరియు ప్రత్యేక అందం రహస్యాలు'
        }
      };

      // Simple mock translation
      let translatedText = text;
      if (mockTranslations[to] && mockTranslations[to][text]) {
        translatedText = mockTranslations[to][text];
      } else {
        // For demo purposes, just add language prefix
        const langPrefixes = {
          'hi': '[HI] ',
          'ta': '[TA] ',
          'te': '[TE] ',
          'bn': '[BN] ',
          'mr': '[MR] ',
          'gu': '[GU] ',
          'kn': '[KN] ',
          'ml': '[ML] ',
          'pa': '[PA] ',
          'ur': '[UR] '
        };
        translatedText = (langPrefixes[to] || '') + text;
      }

      res.json({ translatedText });

    } catch (error) {
      console.error('Translation error:', error);
      res.status(500).json({ error: 'Translation failed' });
    }
  });

  // MyMemory Translation API proxy endpoint
  app.post('/api/google-translate', async (req, res) => {
    try {
      const { text, from, to } = req.body;

      if (!text || !from || !to) {
        return res.status(400).json({ 
          error: 'Missing required parameters',
          translatedText: text || '',
          success: false 
        });
      }

      // If translating to same language, return original text
      if (from === to) {
        return res.json({ 
          translatedText: text,
          success: true 
        });
      }

      // Use MyMemory Translation API
      const fetch = (await import('node-fetch')).default;

      const encodedText = encodeURIComponent(text);
      const langPair = `${from}|${to}`;
      const translateUrl = `https://api.mymemory.translated.net/get?q=${encodedText}&langpair=${langPair}`;

      const response = await fetch(translateUrl, {
        method: 'GET',
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        },
        timeout: 10000 // 10 second timeout
      });

      if (!response.ok) {
        throw new Error(`Translation API responded with status: ${response.status}`);
      }

      const data = await response.json();

      // Parse MyMemory response
      let translatedText = text;
      if (data && data.responseData && data.responseData.translatedText) {
        translatedText = data.responseData.translatedText.trim();
      }

      res.json({ 
        translatedText: translatedText || text,
        success: true 
      });

    } catch (error) {
      console.error('MyMemory Translation API error:', error);

      // Return fallback translation or original text
      res.json({ 
        translatedText: req.body.text || '',
        success: false,
        error: 'Translation service unavailable',
        fallback: true
      });
    }
  });

  // Admin profile cache for visitors
  let adminProfileCache = {
    'help@lushivie.com': {
      displayName: 'Maanya Arora',
      profileImage: 'https://i.ibb.co/zH5KTH4n/IMG-20250811-194616-255.jpg',
      bio: 'Beauty Expert & Content Creator at Lushivie',
      email: 'help@lushivie.com',
      location: 'Delhi, India',
      lastUpdated: Date.now()
    },
    'glamour.bymaanya@gmail.com': {
      displayName: 'Maanya Arora',
      profileImage: 'https://i.ibb.co/zH5KTH4n/IMG-20250811-194616-255.jpg',
      bio: 'Beauty Expert & Content Creator at Lushivie',
      email: 'glamour.bymaanya@gmail.com',
      location: 'Delhi, India',
      lastUpdated: Date.now()
    }
  };

  // Health check endpoint
  app.get('/health', (req, res) => {
    res.json({ status: 'OK', timestamp: new Date().toISOString() });
  });

  // Get admin profile for visitors (fallback when Firebase is not accessible)
  app.get('/admin-profile/:email', (req, res) => {
    try {
      const { email } = req.params;
      const adminEmails = ['help@lushivie.com', 'glamour.bymaanya@gmail.com'];

      if (!adminEmails.includes(email)) {
        return res.status(404).json({ error: 'Admin profile not found' });
      }

      const profile = adminProfileCache[email];
      if (!profile) {
        return res.status(404).json({ error: 'Profile not found' });
      }

      res.json({
        success: true,
        profile: profile,
        source: 'server-cache'
      });
    } catch (error) {
      console.error('Error getting admin profile:', error);
      res.status(500).json({ error: 'Failed to get admin profile' });
    }
  });

  // Update admin profile cache (when Firebase updates occur)
  app.post('/admin-profile/:email', (req, res) => {
    try {
      const { email } = req.params;
      const adminEmails = ['help@lushivie.com', 'glamour.bymaanya@gmail.com'];

      if (!adminEmails.includes(email)) {
        return res.status(404).json({ error: 'Admin profile not found' });
      }

      const updatedProfile = {
        ...adminProfileCache[email],
        ...req.body,
        lastUpdated: Date.now(),
        source: 'server-update'
      };

      adminProfileCache[email] = updatedProfile;

      console.log(`✅ Admin profile cache updated for ${email}:`, updatedProfile.profileImage);

      res.json({
        success: true,
        profile: updatedProfile,
        message: 'Admin profile cache updated'
      });
    } catch (error) {
      console.error('Error updating admin profile cache:', error);
      res.status(500).json({ error: 'Failed to update admin profile cache' });
    }
  });

      return server;
}

// Quote saving routes function
async function addQuoteRoutes(app) {
  // Quote saving endpoint
  app.post("/api/save-quote", async (req, res) => {
    try {
      const { imageBlob, metadata = {} } = req.body;

      if (!imageBlob) {
        return res.status(400).json({ error: "Image blob required" });
      }

      // Rate limiting check (simple in-memory store)
      const clientIp = req.ip || req.connection.remoteAddress;
      const now = Date.now();
      const quotesDir = join(__dirname, "../data/quotes");

      if (!existsSync(quotesDir)) {
        mkdirSync(quotesDir, { recursive: true });
      }

      // Generate unique filename
      const timestamp = Date.now();
      const filename = `quote-${timestamp}.png`;
      const filepath = join(quotesDir, filename);

      // Convert base64 to buffer and save
      const base64Data = imageBlob.replace(/^data:image\/png;base64,/, "");
      const buffer = Buffer.from(base64Data, 'base64');
      writeFileSync(filepath, buffer);

      // Save metadata
      const metadataFile = join(quotesDir, `${timestamp}-metadata.json`);
      const quoteMetadata = {
        id: timestamp,
        filename,
        createdAt: new Date().toISOString(),
        ip: clientIp,
        ...metadata
      };
      writeFileSync(metadataFile, JSON.stringify(quoteMetadata, null, 2));

      // Return public URL (adjust based on your server setup)
      const publicUrl = `/api/quotes/${filename}`;

      res.json({ 
        success: true, 
        url: publicUrl,
        id: timestamp 
      });

    } catch (error) {
      console.error("Error saving quote:", error);
      res.status(500).json({ error: "Failed to save quote" });
    }
  });

  // Serve saved quotes
  app.get("/api/quotes/:filename", (req, res) => {
    try {
      const { filename } = req.params;
      const filepath = join(__dirname, "../data/quotes", filename);

      if (existsSync(filepath)) {
        res.sendFile(filepath);
      } else {
        res.status(404).json({ error: "Quote not found" });
      }
    } catch (error) {
      console.error("Error serving quote:", error);
      res.status(500).json({ error: "Failed to serve quote" });
    }
  });
}