
# Quote This Feature - Documentation

## Overview
The "Quote This" feature allows users to select any text on the Lushivie blog and generate beautiful, shareable quote images instantly.

## How to Use

### For Users
1. **Select Text**: Highlight any text on the blog (20-1200 characters)
2. **Quote This**: Click the "Quote This" button in the floating toolbar
3. **Customize**: Use the composer to customize fonts, colors, templates
4. **Export**: Download as PNG or share directly

### For Admins
Access admin panel to:
- Enable/disable the feature globally
- Update default logo URL
- Manage templates
- View analytics

## Configuration

### Default Settings
```javascript
const defaultConfig = {
  isEnabled: true,
  logoUrl: 'https://i.ibb.co/zH5KTH4n/IMG-20250811-194616-255.jpg',
  minTextLength: 20,
  maxTextLength: 1200
};
```

### Changing Default Logo
Update the `logoUrl` prop in the `QuoteThis` component:
```jsx
<QuoteThis logoUrl="your-new-logo-url.jpg" />
```

### Adding New Templates
Edit `client/src/components/QuoteThis/QuoteComposer.jsx`:
```javascript
const templates = [
  // Add new template
  {
    name: 'Your Template',
    background: 'linear-gradient(135deg, #color1 0%, #color2 100%)',
    primaryColor: '#textcolor'
  }
];
```

### Backend Configuration
The backend quote saving is optional. To enable:
1. Ensure `/api/save-quote` endpoint is available
2. Creates `data/quotes/` directory automatically
3. Stores images and metadata

### Disabling the Feature
Set `isEnabled={false}` in the `QuoteThis` component or remove it entirely.

## File Structure
```
client/src/components/QuoteThis/
├── index.jsx           # Main component
├── TextSelector.jsx    # Selection handling
└── QuoteComposer.jsx   # Image generation & UI
```

## Analytics Events
- `quote_composer_opened`: When user opens composer
- `quote_image_generated`: When image is created
- `quote_image_downloaded`: When user downloads
- `quote_image_shared`: When user shares

## Browser Support
- Chrome: Full support
- Firefox: Full support  
- Safari: Full support
- Mobile: Touch selection supported

## Performance
- Fonts preloaded on first use
- Canvas generation optimized for retina displays
- Lazy loading of heavy components

## QA Checklist
- [ ] Text selection works on mobile/desktop
- [ ] Toolbar appears within viewport
- [ ] All templates render correctly
- [ ] Fonts load properly in generated images
- [ ] Logo appears circular in bottom-right
- [ ] Download saves correct filename
- [ ] Share works on supported devices
- [ ] Feature can be disabled cleanly
- [ ] No interference with existing selection/copy
- [ ] Responsive design works on all screen sizes

## Testing Instructions
1. Select 2-3 lines of text on mobile and desktop
2. Open composer and test all customization options
3. Generate 1080x1080 PNG with logo enabled
4. Download and verify text/logo readability
5. Test share functionality if available
6. Verify feature can be disabled via admin panel

## Troubleshooting

### Fonts Not Loading
- Check Google Fonts connectivity
- Verify font names in the fonts array
- Clear browser cache

### Logo Not Appearing
- Verify logo URL is accessible
- Check CORS settings for external images
- Test with different image formats

### Canvas Issues
- Ensure browser supports Canvas API
- Check for JavaScript errors in console
- Verify device has sufficient memory

## Future Enhancements
- Video quote generation
- More template options
- Social media direct posting
- Batch quote generation
- Custom font uploads
