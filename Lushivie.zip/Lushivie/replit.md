# Lushivie - Luxury Beauty Blog Platform

## Overview

Lushivie is a modern, full-stack beauty blog platform designed to elevate beauty standards through expert insights, luxury product reviews, and inclusive community building. The application features a sophisticated UI with a luxury aesthetic, complete content management system, user engagement features, and SEO optimization.

The platform combines a React-based frontend with an Express.js backend, utilizing PostgreSQL for data persistence and modern web technologies to deliver a premium user experience focused on beauty content, tutorials, and community interaction.

## User Preferences

Preferred communication style: Simple, everyday language.

## Site Owner Information
- **Owner/Author**: Maanya Arora
- **Email**: Help@lushivie.com
- **Location**: Delhi, Delhi, India
- **Brand**: Lushivie - Luxury Beauty Blog

## Recent Production Updates (January 2025)
- ✅ Custom SVG logo with luxury gradient design
- ✅ Updated contact information with owner details
- ✅ Enhanced SEO with structured data and meta tags
- ✅ Production-ready favicon and branding
- ✅ Comprehensive README for deployment
- ✅ Author attribution throughout the site
- ✅ Professional team profiles with founder highlight

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript for type safety and modern development practices
- **Routing**: Wouter for lightweight client-side routing without the overhead of React Router
- **State Management**: TanStack Query (React Query) for server state management and caching
- **UI Framework**: Radix UI primitives with shadcn/ui components for accessible, customizable design system
- **Styling**: Tailwind CSS with custom luxury-themed color palette and design tokens
- **Build Tool**: Vite for fast development and optimized production builds

### Backend Architecture
- **Runtime**: Node.js with Express.js framework for REST API endpoints
- **Language**: TypeScript throughout the entire stack for consistency and type safety
- **API Design**: RESTful endpoints for posts, comments, newsletter subscriptions, and admin operations
- **Error Handling**: Centralized error handling middleware with structured error responses
- **Development Setup**: Hot reload with Vite integration for seamless full-stack development

### Data Storage Solutions
- **Database**: PostgreSQL as the primary relational database
- **ORM**: Drizzle ORM for type-safe database operations and schema management
- **Schema Design**: Well-structured tables for users, posts, comments, and newsletter subscriptions
- **Development Storage**: In-memory storage implementation for development/testing environments
- **Migrations**: Drizzle Kit for database schema migrations and version control

### Authentication and Authorization
- **Session Management**: Express sessions with PostgreSQL session store (connect-pg-simple)
- **Role-Based Access**: Admin and user roles with protected admin routes
- **Security**: Basic authentication patterns with session-based user management

### Design System and Theming
- **Color Palette**: Custom luxury beauty theme with rose gold, deep burgundy, and cream tones
- **Typography**: Playfair Display for headings and Poppins for body text
- **Component Library**: Comprehensive UI component system built on Radix UI primitives
- **Dark/Light Mode**: Full theme switching capability with CSS custom properties
- **Responsive Design**: Mobile-first approach with Tailwind's responsive utilities

## External Dependencies

### Core Framework Dependencies
- **@tanstack/react-query**: Server state management and caching layer
- **wouter**: Lightweight React routing solution
- **drizzle-orm**: Type-safe ORM for database operations
- **@neondatabase/serverless**: PostgreSQL database connectivity (Neon optimized)

### UI and Styling Dependencies
- **@radix-ui/**: Complete suite of accessible UI primitives (accordion, dialog, dropdown, etc.)
- **tailwindcss**: Utility-first CSS framework with custom design system
- **class-variance-authority**: Component variant management for design consistency
- **cmdk**: Command palette functionality for enhanced user experience

### Development and Build Tools
- **vite**: Modern build tool and development server
- **tsx**: TypeScript execution for server-side development
- **esbuild**: Fast JavaScript bundler for production builds
- **@replit/vite-plugin-runtime-error-modal**: Development error handling integration

### Form and Data Handling
- **react-hook-form**: Form state management and validation
- **@hookform/resolvers**: Form validation resolvers
- **drizzle-zod**: Schema validation integration between Drizzle and Zod
- **date-fns**: Date manipulation and formatting utilities

### External Services Integration
- **Unsplash**: Image service for featured images and backgrounds (via URLs)
- **Google Fonts**: Typography loading for Playfair Display and Poppins fonts
- **Replit**: Development environment integration with specialized plugins and error handling