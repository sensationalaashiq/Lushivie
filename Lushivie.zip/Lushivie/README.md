
# Lushivie Beauty Blog - Netlify Deployment Guide

A luxury beauty blog built with React + Vite frontend and Express.js backend, optimized for Netlify deployment.

## 🚀 Quick Deployment to Netlify

### 1. Push to GitHub
```bash
git add .
git commit -m "Prepare for Netlify deployment"
git push origin main
```

### 2. Connect to Netlify
1. Go to [Netlify](https://netlify.com) and sign up/login
2. Click "New site from Git"
3. Connect your GitHub repository
4. Use these build settings:
   - **Build command**: `npm run build:netlify`
   - **Publish directory**: `dist`
   - **Functions directory**: `netlify/functions`

### 3. Environment Variables
In Netlify dashboard → Site settings → Environment variables, add:

#### Frontend Variables (VITE_*)
```
VITE_FIREBASE_API_KEY=your_firebase_api_key
VITE_FIREBASE_AUTH_DOMAIN=your_project.firebaseapp.com
VITE_FIREBASE_PROJECT_ID=your_project_id
VITE_FIREBASE_STORAGE_BUCKET=your_project.appspot.com
VITE_FIREBASE_MESSAGING_SENDER_ID=your_sender_id
VITE_FIREBASE_APP_ID=your_app_id
VITE_IMGBB_API_KEY=your_imgbb_key
VITE_BREVO_PUBLIC_ID=your_brevo_public_id
```

#### Server Variables (SERVER_*)
```
SERVER_BREVO_API_KEY=your_brevo_api_key
SERVER_IMGBB_API_KEY=your_imgbb_api_key
SERVER_FIREBASE_PRIVATE_KEY=your_firebase_private_key
SERVER_FIREBASE_PROJECT_ID=your_project_id
SERVER_FIREBASE_CLIENT_EMAIL=your_firebase_client_email
```

### 4. Deploy
Click "Deploy site" - Netlify will automatically build and deploy your site!

## 🛠 Local Development

```bash
npm install
npm run dev
```
Visit: http://localhost:5000

## 📦 Manual Build Test

Test the Netlify build process locally:
```bash
npm run build:netlify
```

This will:
1. Build the React frontend
2. Move build to `/dist`
3. Copy `/data` to `/dist/data`
4. Create Netlify Functions in `/netlify/functions`

## 🔧 Architecture

- **Frontend**: React + Vite (builds to `/dist`)
- **Backend**: Express.js → Netlify Functions (serverless)
- **Data**: Static JSON files copied to `/dist/data`
- **APIs**: All routes available at `/.netlify/functions/server/api/*`

## 📱 Features

- Luxury beauty blog with admin panel
- Newsletter subscription system
- Contact forms with email integration
- Image uploads (ImgBB integration)
- Firebase authentication
- Responsive design
- SEO optimized

## 🔐 Security

- All API keys are environment variables
- Frontend keys use `VITE_` prefix
- Server keys use `SERVER_` prefix
- No secrets committed to repository

---

**Production URL**: Your site will be available at `https://your-site-name.netlify.app`

For custom domains, configure DNS in Netlify dashboard.
